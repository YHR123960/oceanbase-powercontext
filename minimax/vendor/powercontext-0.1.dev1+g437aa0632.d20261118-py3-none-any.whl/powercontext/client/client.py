# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Small handwritten facade over the public HTTP contract."""

from __future__ import annotations

import asyncio
from collections.abc import Mapping
from types import TracebackType
from typing import Any, Self, TypeVar, cast
from urllib.parse import quote, urlsplit

import httpx
from pydantic import TypeAdapter, ValidationError

from powercontext.client.errors import InvalidResponseError, TransportError, server_response_error
from powercontext.client.tags import ArtifactTagSetResponse
from powercontext.client.tracing import ClientSpan
from powercontext.client.transport_policy import resolve_client_transport
from powercontext.http import (
    AccessAuditPage,
    AccessBinding,
    AccessBindingPage,
    AccessBindingReplacement,
    AccessCheckRequest,
    AccessCheckResponse,
    AccessMeResponse,
    AccessResourcePage,
    AccessRolePage,
    AcknowledgeHandoffRequest,
    ActivateHandoffRequest,
    ApproveCandidateRequest,
    ArtifactCreated,
    ArtifactHandleBinding,
    ArtifactPage,
    ArtifactPublication,
    ArtifactRevision,
    ArtifactRevisionPage,
    BindArtifactHandleRequest,
    BootstrapContext,
    BootstrapContextRequest,
    BootstrapDeliveryReceipt,
    Candidate,
    CandidateHistory,
    CandidatePage,
    Capabilities,
    CaptureContentSourceRequest,
    CaptureContentSourceResponse,
    CaptureWorkingNoteRequest,
    CheckContextRequest,
    ClearScopeBindingRequest,
    ClearScopeBindingResponse,
    CodeQueryRequest,
    CodeQueryResponse,
    CommitConnectorCheckpointRequest,
    CommitHandoffRequest,
    CommittedHandoff,
    ConnectionIdentity,
    ConnectorCheckpointState,
    ContextCheckResult,
    ContinueHandoffRequest,
    CreateAccessBindingRequest,
    CreateArtifactRequest,
    CreateDreamRunRequest,
    CreateRemoteSkillTargetRequest,
    CreateScopeRequest,
    CreateSourceRequest,
    CreateSubjectSourceRequest,
    CreateSubjectSourceResponse,
    CreateWorkContractRequest,
    DownloadRemoteSkillPackageRequest,
    DreamRun,
    DreamRunPage,
    EnrollRemoteSkillTargetRequest,
    ErrorResponse,
    ExperienceArtifact,
    ExternalSkillResolution,
    FinalizeHandoffRequest,
    FlushMemoryRequest,
    FlushMemoryResponse,
    FlushProfileRequest,
    FlushProfileResponse,
    FlushTopicMemoryRequest,
    FlushTopicMemoryResponse,
    GeneratedCandidateResponse,
    GenerateExperienceRequest,
    GeneratePromptDemonstrationsRequest,
    GenerateSkillRequest,
    GetCandidateRequest,
    GetConnectorCheckpointRequest,
    GetExperienceRequest,
    GetHandoffReportRequest,
    GetMemoryCapacityRequest,
    GetMemoryEntryRequest,
    GetSkillPackageRequest,
    GetSkillRequest,
    GetStatsRequest,
    GetTopicMemoryRequest,
    HandoffAcknowledgement,
    HandoffActivation,
    HandoffCurrentWorkRequest,
    HandoffDraft,
    HandoffReportResponse,
    HandoffResolution,
    HealthResponse,
    ImportExternalSkillRequest,
    ListAccessAuditRequest,
    ListAccessBindingsRequest,
    ListAccessResourcesRequest,
    ListAccessRolesRequest,
    ListArtifactRevisionsRequest,
    ListArtifactsRequest,
    ListCandidatesRequest,
    ListDreamRunsRequest,
    ListExternalSkillsRequest,
    ListExternalSkillsResponse,
    ListManagedSkillsRequest,
    ListManagedSkillsResponse,
    ListMemoryChangesRequest,
    ListMemoryChangesResponse,
    ListMemoryEntriesRequest,
    ListMemoryEntriesResponse,
    ListRemoteSkillTargetsRequest,
    ListRemoteSkillTargetsResponse,
    ListScopesRequest,
    ListSourcesRequest,
    MemoryCapacity,
    MemoryMutationResponse,
    PrepareContextRequest,
    PreparedContext,
    PreparedContextWithReuse,
    PreparedHandoff,
    PreparedWorkHandoff,
    PrepareHandoffHintRequest,
    PrepareHandoffRequest,
    ProfilePolicyResponse,
    PromptConfiguration,
    PromptDemonstrationResult,
    ProposeExperienceRequest,
    ProposeSkillPackageRequest,
    ProposeSkillRequest,
    PublishArtifactRequest,
    PublishRemoteSkillRequest,
    PutProfilePolicyRequest,
    ReadinessResponse,
    ReconcileRemoteSkillsRequest,
    ReconcileRemoteSkillsResponse,
    RecordBootstrapDeliveryRequest,
    RecordRemoteSkillReceiptRequest,
    RecordSkillUsageRequest,
    RecordTaskOutcomeRequest,
    RegisterSourceDefinitionRequest,
    RejectCandidateRequest,
    RememberMemoryRequest,
    RemoteSkillPublication,
    RemoteSkillReceiptResponse,
    RemoteSkillTarget,
    RemoteSkillTargetCredential,
    RemoteSkillTargetEnrollment,
    RenameRemoteSkillTargetRequest,
    ReplaceAccessBindingRequest,
    ReplaceArtifactRequest,
    ResolveExternalSkillRequest,
    ResolveScopeBindingRequest,
    ResolveScopeSelectionRequest,
    RetireMemoryEntryRequest,
    ReviseCandidateRequest,
    ReviseMemoryEntryRequest,
    RevokeAccessBindingRequest,
    RevokeRemoteSkillTargetRequest,
    ScanExternalSkillsRequest,
    ScanExternalSkillsResponse,
    ScopeBinding,
    ScopeDescriptor,
    ScopedStats,
    ScopePage,
    ScopeQueryField,
    SearchArtifactsRequest,
    SearchArtifactsResponse,
    SearchMemoryRequest,
    SearchMemoryResponse,
    SearchTopicMemoryRequest,
    SearchTopicMemoryResponse,
    ServerInfo,
    SetDefaultScopeRequest,
    SetScopeBindingRequest,
    SkillArtifact,
    SkillGovernance,
    SkillPackageDownload,
    SkillPackageManifest,
    SourceDefinitionManifest,
    SourceObservationReceipt,
    SourcePage,
    SourceRecord,
    SubmitSourceObservationRequest,
    TopicMemoryArtifact,
    UnpublishRemoteSkillRequest,
    UpdateScopeRequest,
    UpdateSkillLifecycleRequest,
    WorkSourceReceipt,
)
from powercontext.http._generated import models as atomic_models
from powercontext.http._generated import operations as atomic_operations
from powercontext.http._generated.models import (
    ArtifactTagPage,
    ArtifactTagSet,
    GetTopicMemoryProcessingBlockRequest,
    QueryArtifactTagsRequest,
    ReplaceArtifactTagsRequest,
    RetryTopicMemoryProcessingRequest,
    RetryTopicMemoryProcessingResponse,
    TopicMemoryProcessingBlock,
    TopicMemoryProcessingStatus,
    TopicMemoryProcessingStatusRequest,
)
from powercontext.http._generated.operations import (
    ACKNOWLEDGE_HANDOFF,
    ACTIVATE_HANDOFF,
    APPROVE_CANDIDATE,
    BIND_ARTIFACT_HANDLE,
    CAPTURE_CONTENT_SOURCE,
    CAPTURE_WORKING_NOTE,
    CHECK_ACCESS,
    CHECK_CONTEXT,
    CLEAR_SCOPE_BINDING,
    COMMIT_CONNECTOR_CHECKPOINT,
    COMMIT_HANDOFF,
    CONTINUE_HANDOFF,
    CREATE_ACCESS_BINDING,
    CREATE_ARTIFACT,
    CREATE_DREAM_RUN,
    CREATE_REMOTE_SKILL_TARGET,
    CREATE_SCOPE,
    CREATE_SOURCE,
    CREATE_SUBJECT_SOURCE,
    CREATE_WORK_CONTRACT,
    DOWNLOAD_REMOTE_SKILL_PACKAGE,
    DOWNLOAD_SKILL_PACKAGE,
    ENROLL_REMOTE_SKILL_TARGET,
    FINALIZE_HANDOFF,
    FLUSH_MEMORY,
    FLUSH_PROFILE,
    FLUSH_TOPIC_MEMORY,
    GENERATE_EXPERIENCE,
    GENERATE_PROMPT_DEMONSTRATIONS,
    GENERATE_SKILL,
    GET_ACCESS_PRINCIPAL,
    GET_ARTIFACT,
    GET_ARTIFACT_REVISION,
    GET_ARTIFACT_TAGS,
    GET_CANDIDATE,
    GET_CANDIDATE_HISTORY,
    GET_CAPABILITIES,
    GET_CONNECTION_IDENTITY,
    GET_CONNECTOR_CHECKPOINT,
    GET_DEFAULT_SCOPE,
    GET_DREAM_RUN,
    GET_EXPERIENCE,
    GET_HANDOFF_REPORT,
    GET_LIVENESS,
    GET_MEMORY_CAPACITY,
    GET_MEMORY_ENTRY,
    GET_MEMORY_ENTRY_TAGS,
    GET_PROFILE_POLICY,
    GET_PROMPT_CONFIGURATION,
    GET_READINESS,
    GET_SCOPE,
    GET_SERVER_INFO,
    GET_SKILL,
    GET_SKILL_PACKAGE_MANIFEST,
    GET_SOURCE,
    GET_STATS,
    GET_TOPIC_MEMORY,
    GET_TOPIC_MEMORY_PROCESSING_BLOCK,
    GET_TOPIC_MEMORY_PROCESSING_STATUS,
    HANDOFF_CURRENT_WORK,
    IMPORT_EXTERNAL_SKILL,
    LIST_ACCESS_AUDIT,
    LIST_ACCESS_BINDINGS,
    LIST_ACCESS_RESOURCES,
    LIST_ACCESS_ROLES,
    LIST_ARTIFACT_REVISIONS,
    LIST_ARTIFACTS,
    LIST_CANDIDATES,
    LIST_DREAM_RUNS,
    LIST_EXTERNAL_SKILLS,
    LIST_MANAGED_SKILLS,
    LIST_MEMORY_CHANGES,
    LIST_MEMORY_ENTRIES,
    LIST_REMOTE_SKILL_TARGETS,
    LIST_SCOPES,
    LIST_SOURCES,
    PREPARE_BOOTSTRAP_CONTEXT,
    PREPARE_CONTEXT,
    PREPARE_HANDOFF,
    PREPARE_HANDOFF_HINT,
    PROPOSE_EXPERIENCE,
    PROPOSE_SKILL,
    PROPOSE_SKILL_PACKAGE,
    PUBLISH_ARTIFACT,
    PUBLISH_REMOTE_SKILL,
    PUT_PROFILE_POLICY,
    QUERY_ARTIFACT_TAGS,
    QUERY_CODE,
    RECONCILE_REMOTE_SKILLS,
    RECORD_BOOTSTRAP_DELIVERY,
    RECORD_REMOTE_SKILL_RECEIPT,
    RECORD_SKILL_USAGE,
    RECORD_TASK_OUTCOME,
    REGISTER_SOURCE_DEFINITION,
    REJECT_CANDIDATE,
    REMEMBER_MEMORY,
    RENAME_REMOTE_SKILL_TARGET,
    REPLACE_ACCESS_BINDING,
    REPLACE_ARTIFACT,
    REPLACE_ARTIFACT_TAGS,
    REPLACE_MEMORY_ENTRY_TAGS,
    RESOLVE_ARTIFACT_HANDLE,
    RESOLVE_EXTERNAL_SKILL,
    RESOLVE_SCOPE_BINDING,
    RESOLVE_SCOPE_SELECTION,
    RETIRE_MEMORY_ENTRY,
    RETRY_TOPIC_MEMORY_PROCESSING,
    REVISE_CANDIDATE,
    REVISE_MEMORY_ENTRY,
    REVOKE_ACCESS_BINDING,
    REVOKE_REMOTE_SKILL_TARGET,
    SCAN_EXTERNAL_SKILLS,
    SEARCH_ARTIFACTS,
    SEARCH_MEMORY,
    SEARCH_TOPIC_MEMORY,
    SET_DEFAULT_SCOPE,
    SET_SCOPE_BINDING,
    SUBMIT_SOURCE_OBSERVATION,
    UNPUBLISH_REMOTE_SKILL,
    UPDATE_SCOPE,
    UPDATE_SKILL_LIFECYCLE,
    Operation,
)
from powercontext.transport import is_loopback_host, is_plaintext_non_loopback

REQUEST_ID_HEADER = "X-PowerContext-Request-ID"
_RequestT = TypeVar("_RequestT")
_ResponseT = TypeVar("_ResponseT")


class PowerContextClient:
    """Async Python facade for transport-level Server operations."""

    def __init__(
        self,
        base_url: str | None = None,
        *,
        token: str | None = None,
        timeout: float = 10.0,
        http_client: httpx.AsyncClient | None = None,
        trust_transport_security: bool = False,
        allow_insecure_http: bool | None = None,
    ) -> None:
        self._base_url, allow_insecure_http = resolve_client_transport(
            "client", server_url=base_url, allow_insecure_http=allow_insecure_http
        )
        # Plaintext HTTP is only trusted on loopback -- for *any* request, not just an authenticated
        # one. The request body itself carries Memory content, so a missing bearer token does not make
        # an unencrypted non-loopback request safe. When this facade opens the transport itself,
        # ``base_url``'s scheme accurately reflects what crosses the wire. A caller-supplied
        # ``http_client`` *may* instead own a transport whose ``http://`` label is only a routing
        # token -- an in-process ASGI app, a Unix socket, or a TLS-terminating proxy -- but a plain
        # pooling ``httpx.AsyncClient`` (e.g. the shared client the LangGraph adapter installs) is
        # exactly as exposed as one we would open ourselves. Supplying a transport is therefore not
        # evidence of safety: the guard stays on for caller-supplied transports too, and a caller that
        # knows its transport is secure must say so explicitly via ``trust_transport_security`` rather
        # than have safety inferred from the argument being set. ``allow_insecure_http`` is the
        # separate, explicit cleartext opt-in; it does not claim that the transport is secure.
        transport_trusted = http_client is not None and trust_transport_security
        if not transport_trusted and not allow_insecure_http and is_plaintext_non_loopback(self._base_url):
            raise ValueError("refusing to send requests over unencrypted non-loopback HTTP")  # noqa: TRY003
        self._headers = {"X-PowerContext-Dream-Contract": "2"}
        if token:
            self._headers["Authorization"] = f"Bearer {token}"
        self._owned_http_client: httpx.AsyncClient | None = None
        if http_client is None:
            # Loopback traffic must not leave the machine through environment or OS-level proxy
            # discovery. An explicit transport bypasses proxies while still honoring HTTPX's
            # SSL_CERT_FILE/SSL_CERT_DIR handling; remote targets keep normal proxy behavior.
            transport = httpx.AsyncHTTPTransport() if is_loopback_host(urlsplit(self._base_url).hostname) else None
            self._owned_http_client = httpx.AsyncClient(timeout=timeout, transport=transport)
            self._http_client = self._owned_http_client
        else:
            self._http_client = http_client

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        """Close only the HTTP client created by this facade."""

        if self._owned_http_client is not None:
            await self._owned_http_client.aclose()

    async def get_liveness(self) -> HealthResponse:
        """Read process liveness."""

        return await self._request(GET_LIVENESS)

    async def get_readiness(self) -> ReadinessResponse:
        """Read deployment readiness checks."""

        return await self._request(GET_READINESS)

    async def get_capabilities(self) -> Capabilities:
        """Read behavior enabled by the assembled runtime."""

        return await self._request(GET_CAPABILITIES)

    async def get_server_info(self) -> ServerInfo:
        """Read stable deployment identity and protocol compatibility metadata."""

        return await self._request(GET_SERVER_INFO)

    async def list_scopes(
        self,
        query: str | None = None,
        *,
        query_field: ScopeQueryField | None = None,
        parent_scope_id: str | None = None,
        external_reference_kind: str | None = None,
        binding_integration: str | None = None,
        binding_kind: str | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> ScopePage:
        """List or discover durable Scope descriptors."""

        if (
            query is None
            and query_field is None
            and parent_scope_id is None
            and external_reference_kind is None
            and binding_integration is None
            and binding_kind is None
            and limit is None
            and cursor is None
        ):
            return await self._request(LIST_SCOPES)
        return await self._request(
            LIST_SCOPES,
            ListScopesRequest(
                query=query,
                query_field=query_field,
                parent_scope_id=parent_scope_id,
                external_reference_kind=external_reference_kind,
                binding_integration=binding_integration,
                binding_kind=binding_kind,
                limit=50 if limit is None else limit,
                cursor=cursor,
            ),
        )

    async def create_scope(self, request: CreateScopeRequest) -> ScopeDescriptor:
        """Create one independent Scope boundary."""

        return await self._request(CREATE_SCOPE, request)

    async def get_scope(self, scope_id: str) -> ScopeDescriptor:
        """Read one exact Scope descriptor."""

        return await self._request(GET_SCOPE, path_parameters={"scope_id": scope_id})

    async def update_scope(self, scope_id: str, request: UpdateScopeRequest) -> ScopeDescriptor:
        """Replace mutable Scope metadata and relationships."""

        return await self._request(UPDATE_SCOPE, request, path_parameters={"scope_id": scope_id})

    async def get_default_scope(self) -> ScopeDescriptor:
        """Read the host's default Scope target."""

        return await self._request(GET_DEFAULT_SCOPE)

    async def set_default_scope(self, request: SetDefaultScopeRequest) -> ScopeDescriptor:
        """Change the host's default Scope target."""

        return await self._request(SET_DEFAULT_SCOPE, request)

    async def resolve_scope_selection(self, request: ResolveScopeSelectionRequest) -> ScopePage:
        """Resolve all, exact, or subtree into exact Scope descriptors."""

        return await self._request(RESOLVE_SCOPE_SELECTION, request)

    async def resolve_scope_binding(self, request: ResolveScopeBindingRequest) -> ScopeDescriptor:
        """Resolve explicit and external host bindings to one Scope."""

        return await self._request(RESOLVE_SCOPE_BINDING, request)

    async def set_scope_binding(self, request: SetScopeBindingRequest) -> ScopeBinding:
        """Bind one external integration identity to a Scope."""

        return await self._request(SET_SCOPE_BINDING, request)

    async def clear_scope_binding(self, request: ClearScopeBindingRequest) -> ClearScopeBindingResponse:
        """Clear one external integration binding."""

        return await self._request(CLEAR_SCOPE_BINDING, request)

    async def publish_artifact(self, request: PublishArtifactRequest) -> ArtifactPublication:
        """Deliver one exact Artifact revision into another Scope."""

        return await self._request(PUBLISH_ARTIFACT, request)

    async def get_stats(self, request: GetStatsRequest) -> ScopedStats:
        """Read current inventory and bounded usage for one scope."""

        return await self._request(GET_STATS, request)

    async def get_handoff_report(self, request: GetHandoffReportRequest) -> HandoffReportResponse | str:
        """Generate the current canonical Handoff Report projection."""

        if request.download:
            raise ValueError("use download_handoff_report when download is true")  # noqa: TRY003
        if request.format.value == "markdown":
            return (await self._request_handoff_report_content(request)).decode("utf-8")
        return await self._request(GET_HANDOFF_REPORT, request)

    async def download_handoff_report(self, request: GetHandoffReportRequest) -> bytes:
        """Download a Markdown or canonical JSON report file."""

        prepared = request.model_copy(update={"download": True})
        return await self._request_handoff_report_content(prepared)

    async def _request_handoff_report_content(self, request: GetHandoffReportRequest) -> bytes:
        payload = TypeAdapter(GET_HANDOFF_REPORT.request_type).dump_python(
            request,
            mode="json",
            by_alias=True,
        )
        span = ClientSpan.start(GET_HANDOFF_REPORT.operation_id)
        try:
            headers = {} if self._headers is None else dict(self._headers)
            span.inject(headers)
            response = await self._http_client.request(
                GET_HANDOFF_REPORT.method,
                f"{self._base_url}{GET_HANDOFF_REPORT.path}",
                json=payload,
                headers=headers,
            )
        except asyncio.CancelledError as error:
            span.finish("cancelled", error=error)
            raise
        except httpx.HTTPError as exc:
            span.finish("failure", error=exc)
            raise TransportError(GET_HANDOFF_REPORT.path) from exc
        except BaseException as error:
            span.finish("failure", error=error)
            raise
        span.finish(
            "success" if response.status_code == GET_HANDOFF_REPORT.success_status else "failure",
            status_code=response.status_code,
        )
        if response.status_code != GET_HANDOFF_REPORT.success_status:
            error = _decode_error(response.content)
            raise server_response_error(
                status_code=response.status_code,
                request_id=response.headers.get(REQUEST_ID_HEADER),
                code=None if error is None else error.error.code,
                message=None if error is None else error.error.message,
                details=None if error is None else error.error.details,
            )
        return response.content

    async def capture_content_source(self, request: CaptureContentSourceRequest) -> CaptureContentSourceResponse:
        """Capture raw content as durable Source evidence."""

        return await self._request(CAPTURE_CONTENT_SOURCE, request)

    async def capture_working_note(self, request: CaptureWorkingNoteRequest) -> CaptureContentSourceResponse:
        """Capture explicit session-local work state as Source evidence."""

        return await self._request(CAPTURE_WORKING_NOTE, request)

    async def get_connection_identity(self) -> ConnectionIdentity:
        """Observe deployment and request identity without readiness probes."""
        return await self._request(GET_CONNECTION_IDENTITY)

    async def get_access_principal(self) -> AccessMeResponse:
        """Return the authenticated Principal and enforceable Access capabilities."""

        return await self._request(GET_ACCESS_PRINCIPAL)

    async def check_access(self, request: AccessCheckRequest) -> AccessCheckResponse:
        """Evaluate one compound requirement for the current Principal."""

        return await self._request(CHECK_ACCESS, request)

    async def list_access_resources(self, request: ListAccessResourcesRequest) -> AccessResourcePage:
        """List only relationships already visible to the current Principal."""

        return await self._request(LIST_ACCESS_RESOURCES, request)

    async def list_access_roles(self, request: ListAccessRolesRequest) -> AccessRolePage:
        """List stable built-in role definitions."""

        return await self._request(LIST_ACCESS_ROLES, request)

    async def list_access_bindings(self, request: ListAccessBindingsRequest) -> AccessBindingPage:
        """List bindings within an authorized administrative boundary."""

        return await self._request(LIST_ACCESS_BINDINGS, request)

    async def create_access_binding(self, request: CreateAccessBindingRequest) -> AccessBinding:
        """Create or idempotently return one Access Binding."""

        return await self._request(CREATE_ACCESS_BINDING, request)

    async def revoke_access_binding(self, request: RevokeAccessBindingRequest) -> AccessBinding:
        """Revoke one Access Binding using compare-and-swap."""

        return await self._request(REVOKE_ACCESS_BINDING, request)

    async def replace_access_binding(self, request: ReplaceAccessBindingRequest) -> AccessBindingReplacement:
        """Atomically replace an immutable Access Binding."""

        return await self._request(REPLACE_ACCESS_BINDING, request)

    async def list_access_audit(self, request: ListAccessAuditRequest) -> AccessAuditPage:
        """List data-minimized authorization and relationship audit events."""

        return await self._request(LIST_ACCESS_AUDIT, request)

    async def create_dream_run(self, scope_id: str, request: CreateDreamRunRequest) -> DreamRun:
        """Accept a Dream or replay its original queued/terminal result."""

        return await self._request(CREATE_DREAM_RUN, request, path_parameters={"scope_id": scope_id})

    async def get_dream_run(self, scope_id: str, run_id: str) -> DreamRun:
        """Read one durable Dream without triggering generation."""

        return await self._request(GET_DREAM_RUN, path_parameters={"scope_id": scope_id, "run_id": run_id})

    async def list_dream_runs(self, scope_id: str, request: ListDreamRunsRequest | None = None) -> DreamRunPage:
        """List a bounded page of Dream history in reverse acceptance order."""

        return await self._request(
            LIST_DREAM_RUNS,
            ListDreamRunsRequest() if request is None else request,
            path_parameters={"scope_id": scope_id},
        )

    async def create_source(self, scope_id: str, request: CreateSourceRequest) -> SourceRecord:
        """Create one durable Source without invoking generation."""

        return await self._request(CREATE_SOURCE, request, path_parameters={"scope_id": scope_id})

    async def list_sources(
        self,
        scope_id: str,
        request: ListSourcesRequest | None = None,
    ) -> SourcePage:
        """List one stable page of public Sources in a Scope."""

        return await self._request(
            LIST_SOURCES,
            ListSourcesRequest() if request is None else request,
            path_parameters={"scope_id": scope_id},
        )

    async def create_subject_source(
        self, scope_id: str, request: CreateSubjectSourceRequest
    ) -> CreateSubjectSourceResponse:
        """Resolve a subject binding and atomically write both Sources."""
        return await self._request(CREATE_SUBJECT_SOURCE, request, path_parameters={"scope_id": scope_id})

    async def get_profile_policy(self, scope_id: str) -> ProfilePolicyResponse:
        return await self._request(GET_PROFILE_POLICY, path_parameters={"scope_id": scope_id})

    async def put_profile_policy(self, scope_id: str, request: PutProfilePolicyRequest) -> ProfilePolicyResponse:
        return await self._request(PUT_PROFILE_POLICY, request, path_parameters={"scope_id": scope_id})

    async def flush_profile(self, request: FlushProfileRequest) -> FlushProfileResponse:
        return await self._request(FLUSH_PROFILE, request)

    async def get_source(self, scope_id: str, source_type: str, source_id: str) -> SourceRecord:
        """Read one exact Source in a Scope and Source type."""

        return await self._request(
            GET_SOURCE,
            path_parameters={"scope_id": scope_id, "source_type": source_type, "source_id": source_id},
        )

    async def create_artifact(self, scope_id: str, request: CreateArtifactRequest) -> ArtifactCreated:
        """Atomically commit revision one and its system provenance Source."""

        return await self._request(CREATE_ARTIFACT, request, path_parameters={"scope_id": scope_id})

    async def get_artifact(
        self,
        scope_id: str,
        family: str,
        artifact_id: str,
        *,
        if_none_match: str | None = None,
    ) -> ArtifactRevision | None:
        """Read the current visible Artifact head."""

        return await self._request(
            GET_ARTIFACT,
            path_parameters={"scope_id": scope_id, "family": family, "artifact_id": artifact_id},
            extra_headers=None if if_none_match is None else {"If-None-Match": if_none_match},
        )

    async def get_artifact_tags(
        self,
        scope_id: str,
        family: str,
        artifact_id: str,
        *,
        if_none_match: str | None = None,
    ) -> ArtifactTagSetResponse | None:
        """Read scope-local labels with the server-issued ETag; None means 304."""
        return await self._tag_request(
            GET_ARTIFACT_TAGS,
            None,
            {"scope_id": scope_id, "family": family, "artifact_id": artifact_id},
            headers={} if if_none_match is None else {"If-None-Match": if_none_match},
        )

    async def replace_artifact_tags(
        self,
        scope_id: str,
        family: str,
        artifact_id: str,
        request: ReplaceArtifactTagsRequest,
        *,
        expected_etag: str,
    ) -> ArtifactTagSetResponse:
        """Replace labels without revising content; use the ETag from a prior read."""
        result = await self._tag_request(
            REPLACE_ARTIFACT_TAGS,
            request,
            {"scope_id": scope_id, "family": family, "artifact_id": artifact_id},
            headers={"If-Match": expected_etag},
        )
        if result is None:
            raise InvalidResponseError(REPLACE_ARTIFACT_TAGS.path, request_id=None)
        return result

    async def get_memory_entry_tags(
        self,
        scope_id: str,
        artifact_id: str,
        entry_id: str,
        *,
        if_none_match: str | None = None,
    ) -> ArtifactTagSetResponse | None:
        """Read one logical entry's labels, including an inactive manifest entry."""
        return await self._tag_request(
            GET_MEMORY_ENTRY_TAGS,
            None,
            {"scope_id": scope_id, "artifact_id": artifact_id, "entry_id": entry_id},
            headers={} if if_none_match is None else {"If-None-Match": if_none_match},
        )

    async def replace_memory_entry_tags(
        self,
        scope_id: str,
        artifact_id: str,
        entry_id: str,
        request: ReplaceArtifactTagsRequest,
        *,
        expected_etag: str,
    ) -> ArtifactTagSetResponse:
        """Replace one logical entry's labels without changing its version."""
        result = await self._tag_request(
            REPLACE_MEMORY_ENTRY_TAGS,
            request,
            {"scope_id": scope_id, "artifact_id": artifact_id, "entry_id": entry_id},
            headers={"If-Match": expected_etag},
        )
        if result is None:
            raise InvalidResponseError(REPLACE_MEMORY_ENTRY_TAGS.path, request_id=None)
        return result

    async def query_artifact_tags(self, scope_id: str, request: QueryArtifactTagsRequest) -> ArtifactTagPage:
        """Find visible targets by exact tags within a Scope."""
        families = {family.root for family in request.families or ()}
        if "memory" in families or "memory_entry" in (request.target_types or ()):
            raise ValueError("legacy Memory tag queries are unsupported; use atomic-memory Artifact tags")  # noqa: TRY003
        return await self._request(QUERY_ARTIFACT_TAGS, request, path_parameters={"scope_id": scope_id})

    async def _tag_request(
        self,
        operation: Operation[Any, ArtifactTagSet],
        request: ReplaceArtifactTagsRequest | None,
        path_parameters: dict[str, str],
        *,
        headers: dict[str, str],
    ) -> ArtifactTagSetResponse | None:
        response_headers: dict[str, str] = {}
        result = await self._request(
            operation,
            request,
            path_parameters=path_parameters,
            extra_headers=headers,
            response_headers=response_headers,
        )
        if result is None:
            return None
        etag = response_headers.get("etag")
        if etag is None:
            raise InvalidResponseError(operation.path, request_id=response_headers.get(REQUEST_ID_HEADER.lower()))
        return ArtifactTagSetResponse(tag_set=result, etag=etag)

    async def get_artifact_revision(
        self,
        scope_id: str,
        family: str,
        artifact_id: str,
        revision: int,
    ) -> ArtifactRevision:
        """Read one exact immutable Artifact revision."""

        return await self._request(
            GET_ARTIFACT_REVISION,
            path_parameters={
                "scope_id": scope_id,
                "family": family,
                "artifact_id": artifact_id,
                "revision": revision,
            },
        )

    async def bind_artifact_handle(
        self,
        scope_id: str,
        family: str,
        key: str,
        request: BindArtifactHandleRequest,
    ) -> ArtifactHandleBinding:
        """Idempotently bind a scope-local handle to an exact Artifact revision."""

        return await self._request(
            BIND_ARTIFACT_HANDLE,
            request,
            path_parameters={"scope_id": scope_id, "family": family, "key": key},
        )

    async def resolve_artifact_handle(self, scope_id: str, family: str, key: str) -> ArtifactHandleBinding:
        """Resolve a scope-local handle to its exact Artifact revision."""

        return await self._request(
            RESOLVE_ARTIFACT_HANDLE,
            path_parameters={"scope_id": scope_id, "family": family, "key": key},
        )

    async def list_artifacts(self, scope_id: str, family: str, request: ListArtifactsRequest) -> ArtifactPage:
        """List current Artifact heads for one family."""

        return await self._request(
            LIST_ARTIFACTS,
            request,
            path_parameters={"scope_id": scope_id, "family": family},
        )

    async def list_artifact_revisions(
        self, scope_id: str, family: str, artifact_id: str, request: ListArtifactRevisionsRequest
    ) -> ArtifactRevisionPage:
        """List immutable revision metadata using a stable, scoped pagination snapshot."""

        return await self._request(
            LIST_ARTIFACT_REVISIONS,
            request,
            path_parameters={"scope_id": scope_id, "family": family, "artifact_id": artifact_id},
        )

    async def get_prompt_configuration(self, scope_id: str, prompt_key: str) -> PromptConfiguration:
        """Read the saved selection and Runtime defaults without creating a revision."""

        return await self._request(
            GET_PROMPT_CONFIGURATION,
            path_parameters={"scope_id": scope_id, "prompt_key": prompt_key},
        )

    async def generate_prompt_demonstrations(
        self, scope_id: str, prompt_key: str, request: GeneratePromptDemonstrationsRequest
    ) -> PromptDemonstrationResult:
        """Suggest typed demonstrations without saving or changing a Prompt."""

        return await self._request(
            GENERATE_PROMPT_DEMONSTRATIONS,
            request,
            path_parameters={"scope_id": scope_id, "prompt_key": prompt_key},
        )

    async def replace_artifact(
        self,
        scope_id: str,
        family: str,
        artifact_id: str,
        request: ReplaceArtifactRequest,
        *,
        expected_etag: str,
    ) -> ArtifactRevision:
        """Commit a complete next revision using optimistic concurrency."""

        return await self._request(
            REPLACE_ARTIFACT,
            request,
            path_parameters={"scope_id": scope_id, "family": family, "artifact_id": artifact_id},
            extra_headers={"If-Match": expected_etag},
        )

    async def register_source_definition(self, request: RegisterSourceDefinitionRequest) -> SourceDefinitionManifest:
        """Register one immutable worker-owned Source Definition manifest."""

        return await self._request(REGISTER_SOURCE_DEFINITION, request)

    async def get_connector_checkpoint(self, request: GetConnectorCheckpointRequest) -> ConnectorCheckpointState:
        """Read the current opaque checkpoint for one Connector binding."""

        return await self._request(GET_CONNECTOR_CHECKPOINT, request)

    async def submit_source_observation(self, request: SubmitSourceObservationRequest) -> SourceObservationReceipt:
        """Submit one worker-materialized Source observation."""

        return await self._request(SUBMIT_SOURCE_OBSERVATION, request)

    async def commit_connector_checkpoint(
        self,
        request: CommitConnectorCheckpointRequest,
    ) -> ConnectorCheckpointState:
        """Commit a binding checkpoint using optimistic comparison."""

        return await self._request(COMMIT_CONNECTOR_CHECKPOINT, request)

    async def create_work_contract(self, request: CreateWorkContractRequest) -> WorkSourceReceipt:
        """Create one grounded delegation baseline as durable Source evidence."""

        return await self._request(CREATE_WORK_CONTRACT, request)

    async def handoff_current_work(self, request: HandoffCurrentWorkRequest) -> PreparedWorkHandoff:
        """Capture inspected current state and prepare a temporary Handoff."""

        return await self._request(HANDOFF_CURRENT_WORK, request)

    async def acknowledge_handoff(self, request: AcknowledgeHandoffRequest) -> HandoffAcknowledgement:
        """Resolve a Handoff and durably record the receiver's acknowledgement."""

        return await self._request(ACKNOWLEDGE_HANDOFF, request)

    async def record_task_outcome(self, request: RecordTaskOutcomeRequest) -> WorkSourceReceipt:
        """Record one completion-aware attempt outcome without erasing uncertainty."""

        return await self._request(RECORD_TASK_OUTCOME, request)

    async def flush_memory(self, request: FlushMemoryRequest) -> FlushMemoryResponse:
        """Run one bounded Source-to-Memory activation."""

        return await self._request(FLUSH_MEMORY, request)

    async def flush_topic_memory(self, request: FlushTopicMemoryRequest) -> FlushTopicMemoryResponse:
        """Durably request Topic Memory processing without waiting for completion."""

        return await self._request(FLUSH_TOPIC_MEMORY, request)

    async def get_topic_memory_processing_status(
        self, request: TopicMemoryProcessingStatusRequest
    ) -> TopicMemoryProcessingStatus:
        """Inspect a frontier without granting another attempt."""
        return await self._request(GET_TOPIC_MEMORY_PROCESSING_STATUS, request)

    async def get_topic_memory_processing_block(
        self, request: GetTopicMemoryProcessingBlockRequest
    ) -> TopicMemoryProcessingBlock:
        """Read the exact retained diagnostics, including a prior accepted retry."""
        return await self._request(GET_TOPIC_MEMORY_PROCESSING_BLOCK, request)

    async def retry_topic_memory_processing(
        self, request: RetryTopicMemoryProcessingRequest
    ) -> RetryTopicMemoryProcessingResponse:
        """Idempotently request one fresh bounded allowance for an observed block."""
        return await self._request(RETRY_TOPIC_MEMORY_PROCESSING, request)

    async def get_atomic_memory_state(self, scope_id: str, artifact_id: str) -> atomic_models.AtomicMemoryStateResponse:
        """Read current state independently of an immutable content revision."""
        return await self._request(
            atomic_operations.GET_ATOMIC_MEMORY_STATE,
            path_parameters={"scope_id": scope_id, "artifact_id": artifact_id},
        )

    async def get_recall_manifest(
        self, request: atomic_models.RecallManifestRequest
    ) -> atomic_models.RecallManifestResponse:
        """Read bounded Atomic Memory metadata before fetching selected exact revisions."""
        return await self._request(atomic_operations.GET_RECALL_MANIFEST, request)

    async def list_atomic_memories(
        self, request: atomic_models.ListAtomicMemoryRequest
    ) -> atomic_models.ListAtomicMemoryResponse:
        return await self._request(atomic_operations.LIST_ATOMIC_MEMORIES, request)

    async def search_atomic_memory(
        self, request: atomic_models.SearchAtomicMemoryRequest
    ) -> atomic_models.SearchAtomicMemoryResponse:
        return await self._request(atomic_operations.SEARCH_ATOMIC_MEMORY, request)

    async def merge_atomic_memories(
        self, request: atomic_models.MergeAtomicMemoryRequest
    ) -> atomic_models.AtomicMemoryMutationResponse:
        """Merge exact inputs; a transport failure requires inspecting current state."""
        return await self._request(atomic_operations.MERGE_ATOMIC_MEMORIES, request)

    async def change_atomic_memory_lifecycle(
        self, request: atomic_models.AtomicMemoryLifecycleRequest
    ) -> atomic_models.AtomicMemoryMutationResponse:
        return await self._request(atomic_operations.CHANGE_ATOMIC_MEMORY_LIFECYCLE, request)

    async def preview_atomic_memory_restoration(
        self, request: atomic_models.AtomicMemoryRestorationPreviewRequest
    ) -> atomic_models.AtomicMemoryRestorationPreview:
        return await self._request(atomic_operations.PREVIEW_ATOMIC_MEMORY_RESTORATION, request)

    async def restore_atomic_memory(
        self, request: atomic_models.AtomicMemoryRestorationRequest
    ) -> atomic_models.AtomicMemoryRestorationResponse:
        """Restore the current graph once, without blindly replaying an unknown commit."""
        return await self._request(atomic_operations.RESTORE_ATOMIC_MEMORY, request)

    async def remember_memory(self, request: RememberMemoryRequest) -> MemoryMutationResponse:
        """Create one Atomic Memory; non-null legacy collection revision preconditions are unsupported."""

        return await self._request(REMEMBER_MEMORY, request)

    async def search_memory(self, request: SearchMemoryRequest) -> SearchMemoryResponse:
        """Search active Memory entries in one scope."""

        return await self._request(SEARCH_MEMORY, request)

    async def search_topic_memory(self, request: SearchTopicMemoryRequest) -> SearchTopicMemoryResponse:
        """Search current Topic Memory heads with Server-owned retrieval mode."""

        return await self._request(SEARCH_TOPIC_MEMORY, request)

    async def search_artifacts(
        self, scope_id: str, family: str, request: SearchArtifactsRequest
    ) -> SearchArtifactsResponse:
        """Search a registered Artifact Family and retain complete exact revisions."""

        return await self._request(SEARCH_ARTIFACTS, request, path_parameters={"scope_id": scope_id, "family": family})

    async def get_topic_memory(self, request: GetTopicMemoryRequest) -> TopicMemoryArtifact:
        """Read one exact immutable Topic Memory revision."""

        return await self._request(GET_TOPIC_MEMORY, request)

    async def query_code(self, scope_id: str, request: CodeQueryRequest) -> CodeQueryResponse:
        """Read bounded native code evidence for an explicitly authorized Scope."""
        return await self._request(QUERY_CODE, request, path_parameters={"scope_id": scope_id})

    async def prepare_context(self, request: PrepareContextRequest) -> PreparedContext | PreparedContextWithReuse:
        """Prepare final bounded context for one Agent turn."""

        result = await self._request(PREPARE_CONTEXT, request)
        if isinstance(result.root, PreparedContextWithReuse) != request.include_reuse:
            raise InvalidResponseError(PREPARE_CONTEXT.path, request_id=None)
        return result.root

    async def check_context(self, request: CheckContextRequest, *, resolve_target: bool = False) -> ContextCheckResult:
        """Check final bytes; privileged target resolution is opt-in on before_send only."""
        if resolve_target and request.root.phase != "before_send":
            raise ValueError("target resolution requires before_send")  # noqa: TRY003
        result = await self._request(
            CHECK_CONTEXT,
            request,
            extra_headers={"X-PowerContext-Resolve-Target": "true"} if resolve_target else None,
        )
        if (
            result.phase != request.root.phase
            or (result.decision == "allow" and (not result.coverage.complete or not result.binding))
            or (
                resolve_target
                and result.decision == "allow"
                and (not result.target_endpoint or not result.target_protocol)
            )
        ):
            raise InvalidResponseError(CHECK_CONTEXT.path, request_id=None)
        return result

    async def prepare_bootstrap_context(self, request: BootstrapContextRequest) -> BootstrapContext:
        """Prepare curated bounded context for one Agent lifecycle boundary."""

        return await self._request(PREPARE_BOOTSTRAP_CONTEXT, request)

    async def record_bootstrap_delivery(
        self,
        request: RecordBootstrapDeliveryRequest,
    ) -> BootstrapDeliveryReceipt:
        """Finalize one content-free bootstrap delivery receipt."""

        return await self._request(RECORD_BOOTSTRAP_DELIVERY, request)

    async def prepare_handoff(self, request: PrepareHandoffRequest) -> HandoffDraft:
        """Generate one inspectable Handoff Draft from exact evidence."""

        return await self._request(PREPARE_HANDOFF, request)

    async def activate_handoff(self, request: ActivateHandoffRequest) -> HandoffActivation:
        """Evaluate the standard Handoff Trigger at one Source boundary."""

        return await self._request(ACTIVATE_HANDOFF, request)

    async def finalize_handoff(self, request: FinalizeHandoffRequest) -> PreparedHandoff:
        """Finalize an inspected Handoff Draft for direct transfer."""

        return await self._request(FINALIZE_HANDOFF, request)

    async def commit_handoff(self, request: CommitHandoffRequest) -> CommittedHandoff:
        """Commit one finalized Handoff as a durable milestone."""

        return await self._request(COMMIT_HANDOFF, request)

    async def continue_handoff(self, request: ContinueHandoffRequest) -> HandoffResolution:
        """Resolve temporary or committed Handoff content as untrusted history."""

        return await self._request(CONTINUE_HANDOFF, request)

    async def prepare_handoff_hint(self, request: PrepareHandoffHintRequest) -> PreparedContext:
        """Prepare optional orientation; read the full Handoff before continuing work."""

        return await self._request(PREPARE_HANDOFF_HINT, request)

    async def get_memory_capacity(self, request: GetMemoryCapacityRequest) -> MemoryCapacity:
        """Legacy collection capacity is unsupported; the Server returns an explicit error."""

        return await self._request(GET_MEMORY_CAPACITY, request)

    async def list_memory_entries(self, request: ListMemoryEntriesRequest) -> ListMemoryEntriesResponse:
        """List current Atomic Memory records with explicit lifecycle states and pagination."""

        return await self._request(LIST_MEMORY_ENTRIES, request)

    async def get_memory_entry(self, request: GetMemoryEntryRequest) -> atomic_models.AtomicMemoryRecord:
        """Read the current Atomic Memory mapped from a legacy collection and entry target."""
        response = await self._request(GET_MEMORY_ENTRY, request)
        return response.root

    async def revise_memory_entry(self, request: ReviseMemoryEntryRequest) -> MemoryMutationResponse:
        """Legacy citation writes are unsupported; use Atomic content Replace with If-Match."""

        return await self._request(REVISE_MEMORY_ENTRY, request)

    async def retire_memory_entry(self, request: RetireMemoryEntryRequest) -> MemoryMutationResponse:
        """Deactivate one exact Memory entry without deleting history."""

        return await self._request(RETIRE_MEMORY_ENTRY, request)

    async def list_memory_changes(self, request: ListMemoryChangesRequest) -> ListMemoryChangesResponse:
        """Read compact Memory Revision changes."""

        return await self._request(LIST_MEMORY_CHANGES, request)

    async def propose_experience(self, request: ProposeExperienceRequest) -> Candidate:
        """Submit complete Experience content as a pending Candidate."""

        return await self._request(PROPOSE_EXPERIENCE, request)

    async def generate_experience(self, request: GenerateExperienceRequest) -> GeneratedCandidateResponse:
        """Generate a reviewed Experience Candidate from exact evidence."""

        return await self._request(GENERATE_EXPERIENCE, request)

    async def get_experience(self, request: GetExperienceRequest) -> ExperienceArtifact:
        """Read one exact approved Experience Revision."""

        return await self._request(GET_EXPERIENCE, request)

    async def propose_skill(self, request: ProposeSkillRequest) -> Candidate:
        """Submit complete managed Skill content as a pending Candidate."""

        return await self._request(PROPOSE_SKILL, request)

    async def generate_skill(self, request: GenerateSkillRequest) -> GeneratedCandidateResponse:
        """Generate a reviewed managed Skill Candidate from explicit provenance."""

        return await self._request(GENERATE_SKILL, request)

    async def get_skill(self, request: GetSkillRequest) -> SkillArtifact:
        """Read one exact approved managed Skill Revision."""

        return await self._request(GET_SKILL, request)

    async def list_managed_skills(self, request: ListManagedSkillsRequest) -> ListManagedSkillsResponse:
        """List or search current governed managed Skill heads."""

        return await self._request(LIST_MANAGED_SKILLS, request)

    async def update_skill_lifecycle(self, request: UpdateSkillLifecycleRequest) -> SkillGovernance:
        """Apply one governance generation CAS lifecycle transition."""

        return await self._request(UPDATE_SKILL_LIFECYCLE, request)

    async def get_skill_package_manifest(self, request: GetSkillPackageRequest) -> SkillPackageManifest:
        """Read verified exact package metadata and file inventory."""

        return await self._request(GET_SKILL_PACKAGE_MANIFEST, request)

    async def download_skill_package(self, request: GetSkillPackageRequest) -> SkillPackageDownload:
        """Read canonical exact package ZIP bytes as bounded base64."""

        return await self._request(DOWNLOAD_SKILL_PACKAGE, request)

    async def propose_skill_package(self, request: ProposeSkillPackageRequest) -> Candidate:
        """Create a pending exact package Candidate without LLM rewriting."""

        return await self._request(PROPOSE_SKILL_PACKAGE, request)

    async def record_skill_usage(self, request: RecordSkillUsageRequest) -> CaptureContentSourceResponse:
        """Capture one bounded exact Skill usage observation as immutable Source evidence."""

        return await self._request(RECORD_SKILL_USAGE, request)

    async def create_remote_skill_target(
        self,
        request: CreateRemoteSkillTargetRequest,
    ) -> RemoteSkillTargetEnrollment:
        """Create a pending remote target and one-time enrollment code."""

        return await self._request(CREATE_REMOTE_SKILL_TARGET, request)

    async def list_remote_skill_targets(
        self,
        request: ListRemoteSkillTargetsRequest,
    ) -> ListRemoteSkillTargetsResponse:
        """List credential-free target and publication status for one scope."""

        return await self._request(LIST_REMOTE_SKILL_TARGETS, request)

    async def enroll_remote_skill_target(
        self,
        request: EnrollRemoteSkillTargetRequest,
    ) -> RemoteSkillTargetCredential:
        """Consume one enrollment code and receive a per-target credential."""

        return await self._request(ENROLL_REMOTE_SKILL_TARGET, request)

    async def revoke_remote_skill_target(
        self,
        request: RevokeRemoteSkillTargetRequest,
    ) -> RemoteSkillTarget:
        """Revoke one remote target credential using generation CAS."""

        return await self._request(REVOKE_REMOTE_SKILL_TARGET, request)

    async def rename_remote_skill_target(
        self,
        request: RenameRemoteSkillTargetRequest,
    ) -> RemoteSkillTarget:
        """Rename one remote target using generation CAS."""

        return await self._request(RENAME_REMOTE_SKILL_TARGET, request)

    async def publish_remote_skill(self, request: PublishRemoteSkillRequest) -> RemoteSkillPublication:
        """Set an exact approved package as remote desired state."""

        return await self._request(PUBLISH_REMOTE_SKILL, request)

    async def unpublish_remote_skill(self, request: UnpublishRemoteSkillRequest) -> RemoteSkillPublication:
        """Set desired absence for one remote publication."""

        return await self._request(UNPUBLISH_REMOTE_SKILL, request)

    async def reconcile_remote_skills(
        self,
        request: ReconcileRemoteSkillsRequest,
    ) -> ReconcileRemoteSkillsResponse:
        """Read latest-generation actions using this client's target credential."""

        return await self._request(RECONCILE_REMOTE_SKILLS, request)

    async def download_remote_skill_package(
        self,
        request: DownloadRemoteSkillPackageRequest,
    ) -> SkillPackageDownload:
        """Download an exact package authorized for this target generation."""

        return await self._request(DOWNLOAD_REMOTE_SKILL_PACKAGE, request)

    async def record_remote_skill_receipt(
        self,
        request: RecordRemoteSkillReceiptRequest,
    ) -> RemoteSkillReceiptResponse:
        """Record target-local delivery evidence for one exact generation."""

        return await self._request(RECORD_REMOTE_SKILL_RECEIPT, request)

    async def scan_external_skills(self, request: ScanExternalSkillsRequest) -> ScanExternalSkillsResponse:
        """Refresh the configured host-local external Skill Registry."""

        return await self._request(SCAN_EXTERNAL_SKILLS, request)

    async def list_external_skills(self, request: ListExternalSkillsRequest) -> ListExternalSkillsResponse:
        """List external Skills after live local availability checks."""

        return await self._request(LIST_EXTERNAL_SKILLS, request)

    async def resolve_external_skill(self, request: ResolveExternalSkillRequest) -> ExternalSkillResolution:
        """Resolve one exact local external Skill fingerprint without fallback."""

        return await self._request(RESOLVE_EXTERNAL_SKILL, request)

    async def import_external_skill(self, request: ImportExternalSkillRequest) -> GeneratedCandidateResponse:
        """Snapshot an exact external package and propose a new managed Skill."""

        return await self._request(IMPORT_EXTERNAL_SKILL, request)

    async def get_candidate_history(self, request: GetCandidateRequest) -> CandidateHistory:
        return await self._request(GET_CANDIDATE_HISTORY, request)

    async def list_candidates(self, request: ListCandidatesRequest) -> CandidatePage:
        """Page current Candidate heads in the Review Inbox."""

        return await self._request(LIST_CANDIDATES, request)

    async def get_candidate(self, request: GetCandidateRequest) -> Candidate:
        """Read the current head of one Candidate."""

        return await self._request(GET_CANDIDATE, request)

    async def approve_candidate(self, request: ApproveCandidateRequest) -> Candidate:
        """Approve the exact current Candidate version."""

        return await self._request(APPROVE_CANDIDATE, request)

    async def reject_candidate(self, request: RejectCandidateRequest) -> Candidate:
        """Reject the exact current Candidate version."""

        return await self._request(REJECT_CANDIDATE, request)

    async def revise_candidate(self, request: ReviseCandidateRequest) -> Candidate:
        """Append a complete replacement Candidate proposal."""

        return await self._request(REVISE_CANDIDATE, request)

    async def _request(
        self,
        operation: Operation[_RequestT, _ResponseT],
        request: _RequestT | None = None,
        *,
        path_parameters: Mapping[str, str | int] | None = None,
        query_parameters: Mapping[str, Any] | None = None,
        extra_headers: Mapping[str, str] | None = None,
        response_headers: dict[str, str] | None = None,
    ) -> _ResponseT:
        path, json_payload, request_query = _prepare_request(
            operation,
            request,
            path_parameters=path_parameters,
            query_parameters=query_parameters,
        )

        span = ClientSpan.start(operation.operation_id)
        try:
            headers = {} if self._headers is None else dict(self._headers)
            if extra_headers is not None:
                headers.update(extra_headers)
            span.inject(headers)
            response = await self._http_client.request(
                operation.method,
                f"{self._base_url}{path}",
                json=json_payload,
                headers=headers,
                params=request_query or None,
            )
        except asyncio.CancelledError as error:
            span.finish("cancelled", error=error)
            raise
        except httpx.HTTPError as exc:
            span.finish("failure", error=exc)
            raise TransportError(path) from exc
        except BaseException as error:
            span.finish("failure", error=error)
            raise
        declared_not_modified = response.status_code == 304 and 304 in operation.responses
        declared_success = 200 <= response.status_code < 300 and response.status_code in operation.responses
        succeeded = declared_success or declared_not_modified
        span.finish("success" if succeeded else "failure", status_code=response.status_code)

        request_id = response.headers.get(REQUEST_ID_HEADER)
        if response_headers is not None:
            response_headers.update(response.headers)
        if not succeeded:
            error = _decode_error(response.content)
            raise server_response_error(
                status_code=response.status_code,
                request_id=request_id,
                code=None if error is None else error.error.code,
                message=None if error is None else error.error.message,
                details=None if error is None else error.error.details,
            )

        if response.status_code in {204, 304} or operation.response_type is None:
            return cast(_ResponseT, None)

        try:
            return TypeAdapter(operation.response_type).validate_json(response.content)
        except ValidationError as exc:
            raise InvalidResponseError(
                path,
                request_id=request_id,
            ) from exc


def _prepare_request(
    operation: Operation[Any, Any],
    request: object | None,
    *,
    path_parameters: Mapping[str, str | int] | None,
    query_parameters: Mapping[str, Any] | None,
) -> tuple[str, dict[str, Any] | None, dict[str, Any] | None]:
    json_payload: dict[str, Any] | None = None
    request_query: dict[str, Any] = {}
    if request is not None:
        if operation.request_type is None:
            message = f"{operation.operation_id} does not accept a request"
            raise TypeError(message)
        payload = TypeAdapter(operation.request_type).dump_python(
            request, mode="json", by_alias=True, exclude_unset=operation is not PREPARE_CONTEXT
        )
        if not isinstance(payload, dict):
            message = "Request must serialize to an object."
            raise TypeError(message)
        if operation is PREPARE_CONTEXT:
            _trim_prepare_context_payload(request, payload)
        if operation.request_location == "query":
            request_query.update({key: value for key, value in payload.items() if value is not None})
        else:
            json_payload = payload
    if query_parameters is not None:
        request_query.update({key: value for key, value in query_parameters.items() if value is not None})
    path = _bind_operation_path(operation, path_parameters)
    return path, json_payload, request_query or None


def _trim_prepare_context_payload(request: object, payload: dict[str, Any]) -> None:
    """Send only the Prepared Context fields an older Server already accepts, unless they are used."""

    if isinstance(request, PrepareContextRequest) and "assembly" not in request.model_fields_set:
        payload.pop("assembly", None)
    if isinstance(payload.get("assembly"), dict):
        # Plugin search fields are new; omit them when unused so an older Server accepts the request.
        for section in payload["assembly"].get("sections", []):
            if section.get("search") is None:
                section.pop("search", None)
    if isinstance(request, PrepareContextRequest) and not payload.get("include_receipt", False):
        # ``PREPARE_CONTEXT`` serializes its defaults because an older Server needs the fields
        # it already knows about. ``include_receipt`` is not one of them: an older Server
        # rejects the key with ``422 invalid_request``, so a client upgraded ahead of its
        # Server must not volunteer a flag whose default means "say nothing extra". ``false``
        # and absence are the same request.
        payload.pop("include_receipt", None)
    if not payload.get("include_reuse", False):
        payload.pop("include_reuse", None)


def _bind_operation_path(
    operation: Operation[Any, Any],
    path_parameters: Mapping[str, str | int] | None,
) -> str:
    values = {} if path_parameters is None else dict(path_parameters)
    expected = set(operation.path_parameters)
    provided = set(values)
    if provided != expected:
        missing = sorted(expected - provided)
        unexpected = sorted(provided - expected)
        message = f"{operation.operation_id} path parameters do not match"
        if missing:
            message += f"; missing: {', '.join(missing)}"
        if unexpected:
            message += f"; unexpected: {', '.join(unexpected)}"
        raise TypeError(message)

    path = operation.path
    for name in operation.path_parameters:
        value = values[name]
        if not isinstance(value, str | int) or isinstance(value, bool):
            message = f"{operation.operation_id} path parameter {name} must be a string or integer"
            raise TypeError(message)
        path = path.replace(f"{{{name}}}", quote(str(value), safe=""))
    return path


def _decode_error(content: bytes) -> ErrorResponse | None:
    try:
        return ErrorResponse.model_validate_json(content)
    except ValidationError:
        return None
