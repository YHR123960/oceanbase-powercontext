# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Product orchestration for temporary and committed Handoffs."""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Iterable, Sequence
from typing import Protocol, runtime_checkable

from powercontext.artifacts import ArtifactRef
from powercontext.builtin.artifacts.handoff.errors import (
    HandoffEvidenceUnavailableError,
    HandoffGenerationUnavailableError,
    HandoffScopeMismatchError,
    InvalidHandoffGenerationError,
    InvalidHandoffReferenceError,
)
from powercontext.builtin.artifacts.handoff.generation import rollover_draft_violation
from powercontext.builtin.artifacts.handoff.generation_metadata import HandoffGenerationReceipts
from powercontext.builtin.artifacts.handoff.hints import render_handoff_hint
from powercontext.builtin.artifacts.handoff.models import (
    Handoff,
    HandoffArtifactCitation,
    HandoffArtifactDraft,
    HandoffAudience,
    HandoffCitation,
    HandoffClaim,
    HandoffContent,
    HandoffDraft,
    HandoffEvidenceCheck,
    HandoffGenerationEvidence,
    HandoffGenerationRequest,
    HandoffResolution,
    HandoffResolutionSelection,
    HandoffSourceCitation,
    PreparedHandoff,
    PrepareHandoff,
    PrepareHandoffHint,
)
from powercontext.builtin.artifacts.handoff.protocols import (
    HandoffBackend,
    HandoffEvidenceResolver,
    HandoffGenerationPipeline,
)
from powercontext.builtin.artifacts.prompt import PromptError
from powercontext.builtin.artifacts.prompt.service import ScopedPrompts, current_prompt, prompt_operation
from powercontext.builtin.processing_diagnostics import observe_processing_failure
from powercontext.builtin.source_eligibility import SourceNotEligibleError
from powercontext.errors import RevisionConflictError
from powercontext.sources import SourceRef

HandoffEvidenceAuthorizer = Callable[[HandoffCitation], Awaitable[bool]]


@runtime_checkable
class _BatchHandoffEvidenceResolver(Protocol):
    async def resolve_many(
        self,
        citations: Sequence[HandoffCitation],
        /,
    ) -> tuple[HandoffGenerationEvidence, ...]: ...


class HandoffService:
    """Generate, finalize, commit, inspect, and resolve one scope's Handoff lifecycle."""

    def __init__(
        self,
        *,
        scope_id: str,
        artifact_id: str,
        backend: HandoffBackend,
        evidence_resolver: HandoffEvidenceResolver,
        evidence_resolver_for_scope: Callable[[str], HandoffEvidenceResolver] | None = None,
        generation_pipeline: HandoffGenerationPipeline | None = None,
        prompt_context: ScopedPrompts | None = None,
        generation_receipts: HandoffGenerationReceipts | None = None,
    ) -> None:
        self.scope_id = scope_id
        self._prompt_context = prompt_context
        self._generation_receipts = generation_receipts
        self.artifact_id = artifact_id
        self._backend = backend
        self._evidence_resolver = evidence_resolver
        self._evidence_resolver_for_scope = evidence_resolver_for_scope
        self._generation_pipeline = generation_pipeline
        ArtifactRef(family=Handoff.family, artifact_id=artifact_id, revision=1)

    async def prepare(self, action: PrepareHandoff, /) -> HandoffDraft:
        """Generate an inspectable Draft from one standard bounded action."""
        async with observe_processing_failure(
            Handoff.family, "handoff.generate", self.scope_id, input_item_count=len(action.evidence)
        ):
            return await self._prepare_with_prompt(action)

    @prompt_operation("handoff.generate")
    async def _prepare_with_prompt(self, action: PrepareHandoff, /) -> HandoffDraft:
        if self._generation_pipeline is None:
            raise HandoffGenerationUnavailableError
        if isinstance(self._evidence_resolver, _BatchHandoffEvidenceResolver):
            evidence = await self._evidence_resolver.resolve_many(action.evidence)
        else:
            evidence = tuple([await self._evidence_resolver.resolve(citation) for citation in action.evidence])
        draft = await self._generation_pipeline.generate(
            HandoffGenerationRequest(
                objective=action.objective,
                rollover_reasons=action.rollover_reasons,
                evidence=evidence,
                max_bytes=action.max_bytes,
            )
        )
        self._validate_generated_draft(action, draft)
        selection = current_prompt("handoff.generate")
        if selection is not None and self._generation_receipts is not None:
            draft = draft.model_copy(
                update={"generation": self._generation_receipts.issue(self.scope_id, selection, draft)}
            )
        elif draft.generation is not None:
            raise PromptError("invalid_handoff_generation")
        return draft

    async def finalize(self, draft: HandoffDraft, /) -> PreparedHandoff:
        """Finalize inspected content after validating its direct evidence."""

        async with observe_processing_failure(Handoff.family, "handoff.finalize", self.scope_id):
            content = draft.as_content()
            if draft.generation is not None:
                if self._generation_receipts is None:
                    raise PromptError("invalid_handoff_generation")
                content = content.model_copy(
                    update={"generation": self._generation_receipts.verify(self.scope_id, draft.generation, content)}
                )
            await self._validate_evidence(content)
            current = await self._backend.latest(self.artifact_id)
            return PreparedHandoff(
                scope_id=self.scope_id,
                base=None if current is None else current.as_ref(),
                content=content,
                generation=draft.generation,
            )

    async def commit(
        self,
        prepared: PreparedHandoff,
        /,
        *,
        additional_sources: tuple[SourceRef, ...] = (),
        force_revision: bool = False,
    ) -> Handoff:
        """Commit an explicit milestone with no-op and optimistic concurrency semantics."""

        async with observe_processing_failure(
            Handoff.family, "handoff.commit", self.scope_id, storage_location="handoff-commit-storage"
        ):
            self._require_prepared(prepared)
            if prepared.generation is None:
                if prepared.content.generation is not None:
                    raise PromptError("invalid_handoff_generation")
            else:
                if self._generation_receipts is None:
                    raise PromptError("invalid_handoff_generation")
                metadata = self._generation_receipts.verify(self.scope_id, prepared.generation, prepared.content)
                prepared = prepared.model_copy(
                    update={"content": prepared.content.model_copy(update={"generation": metadata})}
                )
            current = await self._backend.latest(self.artifact_id)
            if not force_revision and current is not None and current.content == prepared.content:
                return current

            self._require_current_base(prepared.base, current)
            await self._validate_evidence(prepared.content)
            draft = HandoffArtifactDraft(
                content=prepared.content,
                sources=(*additional_sources, *_source_lineage(prepared.content)),
                artifacts=_artifact_lineage(prepared.content) + _generation_lineage(prepared.content),
            )
            if current is None:
                return await self._backend.create(self.artifact_id, draft)
            return await self._backend.revise(current, draft)

    async def latest(self) -> Handoff | None:
        """Return the current committed milestone."""

        return await self._backend.latest(self.artifact_id)

    async def revision(self, reference: ArtifactRef, /) -> Handoff:
        """Return one exact local or published Handoff revision."""

        self._require_handoff_reference(reference)
        return await self._backend.get(reference)

    async def revisions(self) -> tuple[Handoff, ...]:
        """Return committed milestones in ascending Revision order."""

        return await self._backend.revisions(self.artifact_id)

    async def validate_evidence(self, citations: Iterable[HandoffCitation], /) -> None:
        """Validate exact same-scope evidence used by a higher-level work record."""

        for citation in citations:
            await self._evidence_resolver.validate(citation)

    async def continue_from(
        self,
        handoff: PreparedHandoff | ArtifactRef,
        /,
        *,
        evidence_authorizer: HandoffEvidenceAuthorizer | None = None,
    ) -> HandoffResolution:
        """Resolve Handoff content without treating historical claims as current truth."""

        evidence_resolver = self._evidence_resolver
        if isinstance(handoff, PreparedHandoff):
            current = await self._backend.latest(self.artifact_id)
            self._require_prepared(handoff)
            content = handoff.content
            selection: HandoffResolutionSelection = "prepared"
            selected_revision = None
        else:
            selected = await self.revision(handoff)
            current = await self._backend.latest(selected.artifact_id)
            content = selected.content
            selection = "exact"
            selected_revision = selected.as_ref()
            provenance = selected.lineage.publication_source
            evidence_resolver = self._resolver_for_scope(self.scope_id if provenance is None else provenance.scope_id)
        return await self._resolve(
            content,
            selection=selection,
            selected_revision=selected_revision,
            current=current,
            evidence_resolver=evidence_resolver,
            evidence_authorizer=evidence_authorizer,
        )

    async def continue_latest(
        self,
        *,
        evidence_authorizer: HandoffEvidenceAuthorizer | None = None,
    ) -> HandoffResolution:
        """Resolve the latest milestone after the caller selects the current workstream."""

        current = await self._backend.latest(self.artifact_id)
        if current is None:
            return HandoffResolution(
                status="empty",
                scope_id=self.scope_id,
                content=None,
            )
        return await self._resolve(
            current.content,
            selection="latest",
            selected_revision=current.as_ref(),
            current=current,
            evidence_resolver=self._evidence_resolver,
            evidence_authorizer=evidence_authorizer,
        )

    async def _resolve(
        self,
        content: HandoffContent,
        *,
        selection: HandoffResolutionSelection,
        selected_revision: ArtifactRef | None,
        current: Handoff | None,
        evidence_resolver: HandoffEvidenceResolver,
        evidence_authorizer: HandoffEvidenceAuthorizer | None,
    ) -> HandoffResolution:
        return HandoffResolution(
            status="resolved",
            scope_id=self.scope_id,
            content=content,
            selection=selection,
            selected_revision=selected_revision,
            current_revision=None if current is None else current.as_ref(),
            evidence_checks=await self._evidence_checks(
                content,
                evidence_resolver=evidence_resolver,
                evidence_authorizer=evidence_authorizer,
            ),
        )

    async def hint(self, request: PrepareHandoffHint, /) -> str | None:
        """Project a selected Handoff without generating, persisting, or truncating history."""

        evidence_scope_id = self.scope_id
        selected_revision = None
        if request.prepared is not None:
            self._require_prepared(request.prepared)
            content = request.prepared.content
            current = await self._backend.latest(self.artifact_id)
        else:
            selected = (
                await self.revision(request.revision)
                if request.revision is not None
                else await self._backend.latest(self.artifact_id)
            )
            if selected is None:
                return None
            content = selected.content
            selected_revision = selected.as_ref()
            current = selected if request.selection == "latest" else await self._backend.latest(selected.artifact_id)
            provenance = selected.lineage.publication_source
            if provenance is not None:
                evidence_scope_id = provenance.scope_id
        resolver = self._resolver_for_scope(evidence_scope_id)

        checks = await self._hint_evidence_checks(content, resolver=resolver)
        if checks is None:
            return None
        resolution = HandoffResolution(
            status="resolved",
            scope_id=self.scope_id,
            content=content,
            selection=request.selection,
            selected_revision=selected_revision,
            current_revision=None if current is None else current.as_ref(),
            evidence_checks=checks,
        )
        return render_handoff_hint(
            resolution,
            evidence_scope_id=evidence_scope_id,
            max_bytes=request.max_bytes,
        )

    async def _hint_evidence_checks(
        self,
        content: HandoffContent,
        *,
        resolver: HandoffEvidenceResolver,
    ) -> tuple[HandoffEvidenceCheck, ...] | None:
        """Require complete evidence, including omission citations, before exposing orientation."""

        try:
            checks = await self._evidence_checks(content, evidence_resolver=resolver, evidence_authorizer=None)
            if any(check.status == "unavailable" for check in checks):
                return None
            for omission in content.omissions:
                if omission.citation is None:
                    continue
                await resolver.validate(omission.citation)
        except (HandoffEvidenceUnavailableError, SourceNotEligibleError):
            return None
        return checks

    def _resolver_for_scope(self, scope_id: str) -> HandoffEvidenceResolver:
        if scope_id == self.scope_id:
            return self._evidence_resolver
        if self._evidence_resolver_for_scope is None:
            return self._evidence_resolver
        return self._evidence_resolver_for_scope(scope_id)

    @staticmethod
    def render(
        handoff: HandoffDraft | PreparedHandoff | Handoff,
        /,
        *,
        audience: HandoffAudience,
    ) -> str:
        """Render one lossless document for either supported audience."""

        if audience not in {"human", "agent"}:
            raise ValueError(f"unsupported Handoff audience: {audience}")  # noqa: TRY003
        content = handoff.as_content() if isinstance(handoff, HandoffDraft) else handoff.content
        return content.model_dump_json(by_alias=True, indent=2)

    def _require_prepared(self, prepared: PreparedHandoff) -> None:
        if prepared.scope_id != self.scope_id:
            raise HandoffScopeMismatchError(self.scope_id, prepared.scope_id)
        if prepared.base is not None:
            self._require_lifecycle_reference(prepared.base)

    def _require_handoff_reference(self, reference: ArtifactRef) -> None:
        if reference.family != Handoff.family:
            raise InvalidHandoffReferenceError(reference)

    def _require_lifecycle_reference(self, reference: ArtifactRef) -> None:
        if reference.family != Handoff.family or reference.artifact_id != self.artifact_id:
            raise InvalidHandoffReferenceError(reference)

    @staticmethod
    def _require_current_base(base: ArtifactRef | None, current: Handoff | None) -> None:
        current_ref = None if current is None else current.as_ref()
        if base != current_ref:
            raise RevisionConflictError(base, current)

    async def _validate_evidence(self, content: HandoffContent) -> None:
        for citation in _direct_citations(content):
            await self._evidence_resolver.validate(citation)

    @staticmethod
    def _validate_generated_draft(action: PrepareHandoff, draft: object) -> None:
        if not isinstance(draft, HandoffDraft):
            raise InvalidHandoffGenerationError("output")
        if draft.objective != action.objective:
            raise InvalidHandoffGenerationError("objective")
        allowed_evidence = action.evidence
        if any(citation not in allowed_evidence for citation in _all_citations(draft.as_content())):
            raise InvalidHandoffGenerationError("evidence")
        content_bytes = len(draft.as_content().model_dump_json(by_alias=True, indent=2).encode())
        if content_bytes > action.max_bytes:
            raise InvalidHandoffGenerationError("budget")
        if action.rollover_reasons and (violation := rollover_draft_violation(draft)):
            raise InvalidHandoffGenerationError(violation)

    async def _evidence_checks(
        self,
        content: HandoffContent,
        *,
        evidence_resolver: HandoffEvidenceResolver,
        evidence_authorizer: HandoffEvidenceAuthorizer | None,
    ) -> tuple[HandoffEvidenceCheck, ...]:
        checks = [
            await self._check_evidence(
                statement.citations,
                claim="state",
                state_index=index,
                evidence_resolver=evidence_resolver,
                evidence_authorizer=evidence_authorizer,
            )
            for index, statement in enumerate(content.state)
        ]
        if content.next_action is not None:
            checks.append(
                await self._check_evidence(
                    content.next_action.citations,
                    claim="next_action",
                    evidence_resolver=evidence_resolver,
                    evidence_authorizer=evidence_authorizer,
                )
            )
        return tuple(checks)

    async def _check_evidence(
        self,
        citations: tuple[HandoffCitation, ...],
        *,
        claim: HandoffClaim,
        state_index: int | None = None,
        evidence_resolver: HandoffEvidenceResolver,
        evidence_authorizer: HandoffEvidenceAuthorizer | None,
    ) -> HandoffEvidenceCheck:
        unavailable: list[HandoffCitation] = []
        for citation in citations:
            if evidence_authorizer is not None and not await evidence_authorizer(citation):
                unavailable.append(citation)
                continue
            try:
                await evidence_resolver.validate(citation)
            except HandoffEvidenceUnavailableError:
                if citation not in unavailable:
                    unavailable.append(citation)
        return HandoffEvidenceCheck(
            claim=claim,
            state_index=state_index,
            status="unavailable" if unavailable else "available",
            unavailable_evidence=tuple(unavailable),
        )


def _direct_citations(content: HandoffContent) -> Iterable[HandoffCitation]:
    for statement in content.state:
        yield from statement.citations
    if content.next_action is not None:
        yield from content.next_action.citations


def _all_citations(content: HandoffContent) -> Iterable[HandoffCitation]:
    yield from _direct_citations(content)
    for omission in content.omissions:
        if omission.citation is not None:
            yield omission.citation


def _generation_lineage(content: HandoffContent) -> tuple[ArtifactRef, ...]:
    origin = content.generation
    return () if origin is None or origin.artifact is None else (origin.artifact,)


def _source_lineage(content: HandoffContent) -> tuple[SourceRef, ...]:
    sources: list[SourceRef] = []
    for citation in _direct_citations(content):
        if isinstance(citation, HandoffSourceCitation) and citation.source_ref not in sources:
            sources.append(citation.source_ref)
    return tuple(sources)


def _artifact_lineage(content: HandoffContent) -> tuple[ArtifactRef, ...]:
    artifacts: list[ArtifactRef] = []
    for citation in _direct_citations(content):
        if isinstance(citation, HandoffArtifactCitation) and citation.artifact_ref not in artifacts:
            artifacts.append(citation.artifact_ref)
    return tuple(artifacts)
