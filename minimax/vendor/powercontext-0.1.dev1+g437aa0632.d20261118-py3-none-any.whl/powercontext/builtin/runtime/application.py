# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Business-specific Runtime operations over composed built-in contexts."""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import AsyncIterator, Awaitable, Callable, Iterable, Mapping, Sequence
from contextlib import AbstractAsyncContextManager, AbstractContextManager, asynccontextmanager, nullcontext
from contextvars import ContextVar
from dataclasses import dataclass, replace
from datetime import UTC, datetime, timedelta
from functools import partial
from hashlib import sha256
from time import perf_counter
from types import MethodType
from typing import TYPE_CHECKING, Any, Protocol, TypeVar
from uuid import uuid4

from pydantic import BaseModel, JsonValue, ValidationError

from powercontext._logging import log_context, log_safely
from powercontext.artifacts import ArtifactAddress, ArtifactLineage, ArtifactRef, StableHandle
from powercontext.artifacts.search import (
    ArtifactSearchExecutionContext,
    ArtifactSearchOutcome,
    ArtifactSearchUnsupported,
)
from powercontext.builtin.artifacts.atomic_memory.models import (
    AtomicMemoryContent,
    AtomicMemoryMutationResult,
)
from powercontext.builtin.artifacts.experience import (
    EXPERIENCE_INCUBATION_WINDOW_LIMIT,
    Experience,
    ExperienceSearchHit,
    ExperienceSearchOutcome,
)
from powercontext.builtin.artifacts.handoff import (
    ActivateHandoff,
    Handoff,
    HandoffActivation,
    HandoffArtifactCitation,
    HandoffAudience,
    HandoffCitation,
    HandoffDraft,
    HandoffEvidenceAuthorizer,
    HandoffOmission,
    HandoffResolution,
    HandoffService,
    HandoffSourceCitation,
    HandoffStatement,
    PreparedHandoff,
    PrepareHandoff,
    PrepareHandoffHint,
)
from powercontext.builtin.artifacts.memory import EmbeddingProfile, MemoryQueryEmbedding
from powercontext.builtin.artifacts.merge_models import (
    ArtifactMergeMutationResult,
    ArtifactMergeRead,
    ArtifactMergeRecord,
    ArtifactMergeRestorationPreview,
    ArtifactMergeRestoreOperation,
)
from powercontext.builtin.artifacts.profile.service import RelationalProfileService
from powercontext.builtin.artifacts.prompt import (
    GeneratePromptDemonstrations,
    PromptConfiguration,
    PromptDemonstrationResult,
    PromptError,
)
from powercontext.builtin.artifacts.prompt.service import PromptService
from powercontext.builtin.artifacts.search import (
    AdmissionCounts,
    AdmissionFloor,
    analyze_text,
)
from powercontext.builtin.artifacts.skill import (
    AgentKind,
    AgentSkillTarget,
    ExternalSkillRegistryUnavailableError,
    ExternalSkillResolution,
    Skill,
    SkillOrigin,
    SkillPackageRef,
    SkillPackageSnapshot,
    SkillSearchHit,
)
from powercontext.builtin.artifacts.skill.distribution import (
    RemoteSkillDistributionService,
    RemoteSkillObservation,
    RemoteSkillReceipt,
    RemoteSkillReceiptResult,
    RemoteSkillReconcileResult,
    RemoteSkillTargetStatus,
    RemoteTargetCredential,
    RemoteTargetEnrollment,
)
from powercontext.builtin.artifacts.skill.publication import (
    ManagedSkillPublicationService,
    ManagedSkillPublicationStatus,
)
from powercontext.builtin.artifacts.skill.registry import ExternalSkillRegistryService
from powercontext.builtin.artifacts.topic_memory import (
    MAX_TOPIC_MEMORY_QUERY_LENGTH,
    MAX_TOPIC_MEMORY_QUERY_TERMS,
    MAX_TOPIC_MEMORY_SEARCH_LIMIT,
    TOPIC_MEMORY_SOURCE_WINDOW_BINDING,
    PublishedTopicMemory,
    TopicMemory,
    TopicMemoryBrowseCursor,
    TopicMemoryCurrentItem,
    TopicMemorySearchHit,
    TopicMemorySearchMode,
    TopicMemorySearchResult,
)
from powercontext.builtin.artifacts.topic_memory.processing import (
    TopicMemoryProcessingStatus,
    TopicMemoryRetryResult,
    TopicMemoryWorkBlock,
)
from powercontext.builtin.artifacts.topic_memory.search import bounded_topic_memory_query
from powercontext.builtin.catalog_changes.application import CatalogChangeApplication
from powercontext.builtin.catalog_changes.models import CatalogChangeProposal, TagDreamTarget
from powercontext.builtin.catalog_changes.service import CatalogChangeService
from powercontext.builtin.code.application import CodeApplication
from powercontext.builtin.code.errors import CodeError
from powercontext.builtin.code.models import CodeConfig, CodeQueryRequest, CodeQueryResult
from powercontext.builtin.code.service import CodeService
from powercontext.builtin.context import BuiltinArtifacts, BuiltinSources
from powercontext.builtin.dream.application import DreamApplication
from powercontext.builtin.dream.service import CandidateAttester, DreamAuthorizer, DreamService
from powercontext.builtin.evidence.resolver import (
    AuthorizationContext,
    ScopedEvidenceAuthorizer,
    ScopedEvidenceBatchAuthorizer,
)
from powercontext.builtin.inference import (
    EmbeddingModel,
)
from powercontext.builtin.inference.errors import InferencePrivacyError
from powercontext.builtin.inference.models import InferenceUsage
from powercontext.builtin.inference.privacy import InferenceProtectionConfig
from powercontext.builtin.inference.usage import bind_usage_reporter
from powercontext.builtin.persistence.agent_skill_targets import RemoteAgentSkillTarget
from powercontext.builtin.persistence.artifact_governance import (
    ArtifactGovernance,
    ArtifactLifecycleState,
)
from powercontext.builtin.persistence.bootstrap_receipts import (
    BootstrapReceiptRepository,
    StoredBootstrapReceipt,
)
from powercontext.builtin.persistence.database import AsyncDatabase
from powercontext.builtin.persistence.skill_publications import SkillPublication
from powercontext.builtin.processing_diagnostics import observe_processing_failure
from powercontext.builtin.publication import ArtifactPublicationApplication
from powercontext.builtin.records import (
    ArtifactCreated,
    ArtifactRecord,
    ArtifactRecordPage,
    ArtifactRevisionPage,
    ArtifactWrite,
    BaseValueConflictError,
    InvalidBaseAccessRequestError,
    LogicalArtifactRecord,
    RecordService,
    ScopeSummaryPage,
    SourceRecord,
    SourceRecordPage,
)
from powercontext.builtin.review.errors import InvalidCandidateError
from powercontext.builtin.review.generation import GeneratedCandidateResult, ReviewedGenerationService
from powercontext.builtin.review.models import Candidate
from powercontext.builtin.review.service import CandidateCommitHook, ReviewService
from powercontext.builtin.runtime._scope_cache import (
    DEFAULT_SCOPE_CACHE_SIZE,
    ScopeCache,
    ScopeCacheObserver,
    ScopeEvictor,
)
from powercontext.builtin.runtime._source_capture import SourceCaptureCoalescer
from powercontext.builtin.runtime.artifact_merge import ArtifactMergeApplication
from powercontext.builtin.runtime.artifact_search import ArtifactSearchService
from powercontext.builtin.runtime.atomic_memory import (
    AtomicMemoryDependencySelection,
    AtomicMemoryDependencySnapshot,
    AtomicMemorySearchHit,
)
from powercontext.builtin.runtime.bootstrap_context import (
    BootstrapBuild,
    BootstrapCandidate,
    build_bootstrap_context,
)
from powercontext.builtin.runtime.context_bindings import BindingCodec
from powercontext.builtin.runtime.context_check import CheckContextRequest, ContextCheckResult, check_context
from powercontext.builtin.runtime.context_reuse import (
    ContextReuseError,
    ValidatedContextReuse,
    prepare_reuse,
    validate_reuse,
)
from powercontext.builtin.runtime.decision_model import DecisionModel
from powercontext.builtin.runtime.errors import InvalidRuntimeRequestError, TopicMemoryProcessingUnavailableError
from powercontext.builtin.runtime.extraction_diagnostics import ExtractionDiagnostics
from powercontext.builtin.runtime.models import (
    BUILTIN_CONTEXT_FAMILIES,
    ApproveCandidateRequest,
    BootstrapContext,
    BootstrapContextItem,
    BootstrapContextRequest,
    BootstrapDeliveryReceipt,
    BootstrapReceiptState,
    BootstrapSkipReason,
    CaptureSource,
    CaptureWorkingNote,
    CommitConnectorCheckpoint,
    ConnectorCheckpointState,
    ExperienceCandidate,
    ExperienceIncubationResult,
    ExternalSkillList,
    ExternalSkillScanResult,
    ExtractionStatus,
    GenerateExperienceRequest,
    GenerateSkillRequest,
    GetCandidateRequest,
    GetExperienceRequest,
    GetSkillRequest,
    GetTopicMemoryRequest,
    ImportExternalSkillRequest,
    ListCandidatesRequest,
    ListExternalSkillsRequest,
    MemoryFlushResult,
    PrepareContextRequest,
    PrepareContextResult,
    PreparedContext,
    ProposeExperienceRequest,
    ProposeSkillRequest,
    RecordBootstrapDeliveryRequest,
    RejectCandidateRequest,
    ResolveExternalSkillRequest,
    ReviewedCandidate,
    ReviewedCandidatePage,
    ReviseCandidateRequest,
    RuntimeCapabilities,
    SearchTopicMemoryRequest,
    SkillCandidate,
    SourceReceipt,
    SubmitSourceObservation,
    TopicMemoryFlushResult,
)
from powercontext.builtin.runtime.prepared_code import PreparedCodeCandidate, code_candidates
from powercontext.builtin.runtime.prepared_context import (
    PreparedContextBuild,
    PreparedContextBuilder,
    PreparedExperienceCandidates,
    PreparedMemoryCandidates,
    PreparedProfileCandidate,
)
from powercontext.builtin.runtime.protocols import (
    BuiltinTriggers,
    PowerContextProvider,
    RemoteIngestion,
    RuntimeSpan,
    RuntimeTracing,
    TraceAttribute,
)
from powercontext.builtin.runtime.readiness import (
    ReadinessCheckStatus,
    RuntimeReadiness,
    RuntimeReadinessChecks,
    RuntimeReadinessSnapshot,
    RuntimeReadinessStatus,
)
from powercontext.builtin.runtime.recall_sufficiency import (
    EXPERIENCE_FAMILY,
    MEMORY_FAMILY,
    REASON_AT_MAX_ROUNDS,
    REASON_EXPANSION_FAILED,
    REASON_WEAK_TOP_ONE,
    TOPIC_MEMORY_FAMILY,
    RecallEffort,
    RecallExpander,
    RecallSufficiencyGate,
    RecallSufficiencyPolicy,
    build_recall_candidates,
    recall_effort,
)
from powercontext.builtin.runtime.receipt import RecallRound
from powercontext.builtin.runtime.receipt_builder import ReceiptEvidence
from powercontext.builtin.runtime.receipt_capture import (
    bind_receipt_evidence,
    current_receipt_evidence,
    unbind_receipt_evidence,
)
from powercontext.builtin.runtime.skill_search import SkillArtifactSearcher, search_skill_library
from powercontext.builtin.runtime.statistics import RelationalScopedStatistics, overview_selection
from powercontext.builtin.runtime.topic_memory_recovery import TopicMemoryRecoveryService
from powercontext.builtin.runtime.topic_memory_search import TopicMemorySearcher
from powercontext.builtin.scope import ScopeApplication, ScopeDescriptor, ScopeSelection
from powercontext.builtin.scope.subject_sources import SubjectSourceService
from powercontext.builtin.sources import (
    CONTENT_SOURCE_ADAPTER,
    CONTENT_SOURCE_NAME,
    WORKING_NOTE_SOURCE_KIND,
    ContentCapture,
    ContentSource,
    ExternalSkillImportMode,
    SkillUsageCapture,
    SourceCursor,
    validate_scope_id,
)
from powercontext.builtin.statistics import (
    ModelUsageOperation,
    ModelUsagePurpose,
    RecallTokenMeasurement,
    Statistics,
    StatisticsPeriod,
)
from powercontext.builtin.statistics.aggregation import aggregate_statistics
from powercontext.builtin.tags import (
    ArtifactTagSet,
    TagFilter,
    TagQuery,
    TagQueryPage,
    TagTarget,
)
from powercontext.builtin.work import (
    HANDOFF_BOUNDARY_SOURCE_KIND,
    HANDOFF_RECEIPT_SOURCE_KIND,
    TASK_OUTCOME_SOURCE_KIND,
    WORK_CONTRACT_SOURCE_KIND,
    AcknowledgeHandoff,
    CreateWorkContract,
    HandoffAcknowledgement,
    HandoffCurrentWork,
    HandoffReceipt,
    PreparedWorkHandoff,
    RecordTaskOutcome,
    TaskOutcome,
    WorkClaim,
    WorkContinuity,
    WorkContract,
    WorkSourceKind,
    WorkSourceReceipt,
    content_digest,
    project_work_continuity,
)
from powercontext.context import PowerContext
from powercontext.errors import SourceConflictError
from powercontext.sources import ConnectorBinding, SourceDefinitionManifest, SourceRef

if TYPE_CHECKING:
    from powercontext.builtin.handoff_report.application import HandoffReportApplication
    from powercontext.builtin.portability import PortableBundleService
    from powercontext.builtin.runtime.artifact_processing import ArtifactProcessingSupervisors
    from powercontext.builtin.runtime.scope_reads import ScopeReadSnapshot


class TopicMemorySearch(Protocol):
    """Callable contract for one scoped Topic Memory search."""

    def __call__(
        self,
        scope_id: str,
        query: str,
        /,
        *,
        limit: int,
        mode: TopicMemorySearchMode = "auto",
        query_vector: tuple[float, ...] | None = None,
        embedding_profile: EmbeddingProfile | None = None,
        admission: AdmissionFloor | None = None,
        query_embedding: MemoryQueryEmbedding | None = None,
        execution_context: ArtifactSearchExecutionContext | None = None,
    ) -> Awaitable[TopicMemorySearchResult]: ...


TopicMemoryGet = Callable[[str, ArtifactRef], Awaitable[PublishedTopicMemory]]
TopicMemoryBrowse = Callable[..., Awaitable[tuple[TopicMemoryCurrentItem, ...]]]
TopicMemoryFlush = Callable[[str], Awaitable[bool]]
TopicMemorySearchObserver = Callable[[str, bool], None]

logger = logging.getLogger(__name__)

_MEMORY_CAPTURE_STAGE = "memory.capture"
_MEMORY_CAPTURE_SOURCE_COUNT = "powercontext.memory.capture.source_count"
_WORKING_NOTE_RESERVED_METADATA = frozenset({"kind", "session_id", "note_kind", "expires_at"})
_MEMORY_SEARCH_STAGE = "memory.search"
_MEMORY_SEARCH_REQUESTED_MODE = "powercontext.memory.search.requested_mode"
_MEMORY_SEARCH_LIMIT = "powercontext.memory.search.limit"
_MEMORY_SEARCH_MODE = "powercontext.memory.search.mode"
_MEMORY_SEARCH_RESULT_COUNT = "powercontext.memory.search.result_count"

ReviewServiceFactory = Callable[[str], ReviewService]
GenerationServiceFactory = Callable[[str], ReviewedGenerationService]
ExternalSkillRegistryFactory = Callable[[str], ExternalSkillRegistryService]
SkillPublicationServiceFactory = Callable[[str, str, str], ManagedSkillPublicationService]
ExternalSkillImporter = Callable[
    [str, str, str, ExternalSkillImportMode, str | None],
    Awaitable[GeneratedCandidateResult],
]
ExperienceIncubator = Callable[[str, int], Awaitable[ExperienceIncubationResult]]


class ExperienceRecall(Protocol):
    """Callable contract for one scoped Experience recall.

    The outcome carries the hits *and* the admission counts for the search, so the recall gate
    can report retrieved-versus-admitted without a second pass.
    """

    def __call__(
        self,
        scope_id: str,
        query: str,
        limit: int,
        /,
        *,
        admission: AdmissionFloor | None = None,
    ) -> Awaitable[ExperienceSearchOutcome]: ...


@dataclass(frozen=True)
class TopicMemoryRecallOutcome:
    """Topic Memory hits, their admission counts, and the reusable query embedding.

    Produced and consumed entirely inside the Runtime layer, which is why it lives here rather
    than under ``artifacts/**``. ``query_embedding`` is the vector this search resolved (or
    reused); a later expansion round can hand it back so the next search does not re-embed. It
    stays ``None`` when the search ran without a vector channel. Prepare caches that outcome
    too, so expansion rounds retain FTS after a failed embedding attempt.
    """

    hits: tuple[TopicMemorySearchHit, ...] = ()
    admission: AdmissionCounts | None = None
    query_embedding: MemoryQueryEmbedding | None = None
    embedding_calls: int = 0
    #: Non-null only when Topic Memory wanted a vector and had to fall back to FTS.
    embedding_fallback: str | None = None
    mode: str | None = None


@dataclass(frozen=True)
class _ScopeRecallOutcome:
    """One Scope's recall result: the two candidate containers plus their admission counts.

    A named type rather than a tuple because the count fields are the whole point of this
    increment and a silent field-order mistake there would be invisible.
    """

    memory: PreparedMemoryCandidates
    experience: PreparedExperienceCandidates
    memory_admission: AdmissionCounts | None = None
    experience_admission: AdmissionCounts | None = None
    memory_query_embedding: MemoryQueryEmbedding | None = None
    memory_recoverable: bool = False
    #: Non-null only when Atomic Memory wanted a vector and had to fall back to lexical.
    memory_embedding_fallback: str | None = None
    embedding_calls: int = 0
    generation_calls: int = 0


#: The one cause that outranks the others when a preparation loses several channels at once.
_TIMEOUT_REASON = "inference_timeout"


def _degradation(current: str | None, observed: str | None) -> str | None:
    """Fold one more observed cause into the preparation's reason.

    A timeout outranks an unavailable provider because it is the one an operator can fix by
    raising ``recall_embedding_timeout_seconds``; reporting the provider error instead would
    point at the wrong knob when both occurred.
    """

    if observed is None:
        return current
    if current == _TIMEOUT_REASON:
        return current
    return _TIMEOUT_REASON if observed == _TIMEOUT_REASON else (current or observed)


@dataclass
class _EmbeddingBudget:
    """What is left of one context preparation's budget for waiting on query embeddings.

    Only the waits are charged, so database reads, Experience recall and reranking between two searches do not take a
    later search's share. A spent budget is reached only through an embedding that timed out, which already recorded
    the preparation's degradation cause, so a later search can skip its embedding without losing that cause. A spent
    budget stops new embedding requests only: a query vector an earlier search obtained needs no wait and stays usable.
    """

    remaining: float

    def spend(self, seconds: float) -> None:
        self.remaining = max(self.remaining - seconds, 0.0)


@dataclass(frozen=True)
class _RecallRoundOutcome:
    """All observable results produced by one bounded recall pass."""

    memory: tuple[PreparedMemoryCandidates, ...] = ()
    experience: tuple[PreparedExperienceCandidates, ...] = ()
    topic_memory: TopicMemoryRecallOutcome = TopicMemoryRecallOutcome()
    admissions: tuple[AdmissionCounts, ...] = ()
    embedding_calls: int = 0
    generation_calls: int = 0
    memory_recoverable: bool = False
    #: A channel this pass wanted and lost, reported once per preparation. A timeout wins
    #: over an unavailable provider when both happen, because it is the actionable one.
    degradation: str | None = None


SkillRecall = Callable[[str, str, int], Awaitable[tuple[SkillSearchHit, ...]]]
SkillLister = Callable[[str, bool, int], Awaitable[tuple[tuple[Skill, ArtifactGovernance], ...]]]
SkillOriginReader = Callable[[str, tuple[Skill, ...]], Awaitable[tuple[SkillOrigin, ...]]]
SkillGovernanceReader = Callable[[str, str], Awaitable[ArtifactGovernance]]
SkillGovernanceUpdater = Callable[[str, str, int, ArtifactLifecycleState, str | None], Awaitable[ArtifactGovernance]]
SkillPackageResolver = Callable[[str, ArtifactRef], Awaitable[SkillPackageSnapshot]]
PackageSnapshotResolver = Callable[[str, SkillPackageRef], Awaitable[SkillPackageSnapshot]]
SkillPackageUploader = Callable[[str, bytes, str | None, ArtifactRef | None], Awaitable[SkillCandidate]]
SkillUsageRecorder = Callable[[str, SkillUsageCapture], Awaitable[SourceReceipt]]
StatisticsServiceFactory = Callable[[str], RelationalScopedStatistics]
RecallTokenEstimator = Callable[[str, PreparedContextBuild], Awaitable[RecallTokenMeasurement | None]]
RecallEffortSink = Callable[[RecallEffort], Awaitable[None]]
Clock = Callable[[], datetime]
_MEMORY_SEARCH_ATTEMPTS = 3


class _RuntimeConfigurationError(ValueError):
    def __init__(self, field: str) -> None:
        super().__init__(f"{field} must be positive")


class _RuntimeStateError(RuntimeError):
    def __init__(self, code: str) -> None:
        messages = {
            "closed": "Built-in Runtime is closed",
            "database": "Primary database is not configured",
            "empty-write": "explicit Memory write did not produce a Memory",
            "experience-incubation": "Experience incubation is not configured",
            "external-skill-registry": "External Skill Registry is not configured",
            "remote-ingestion": "Remote Source ingestion is not configured",
            "review": "Candidate Review services are not configured",
            "records": "Base Source and Artifact access is not configured",
            "remote-skill-distribution": "Remote Skill distribution services are not configured",
            "scope": "Scope services are not configured",
            "skill-publication": "Managed Skill publication services are not configured",
            "skill-provenance": "Managed Skill provenance services are not configured",
            "skill-governance": "Managed Skill governance services are not configured",
            "skill-package": "Managed Skill package services are not configured",
            "skill-usage": "Managed Skill usage recording is not configured",
            "statistics": "Statistics services are not configured",
            "topic-memory-browse": "Topic Memory browsing is not configured",
        }
        super().__init__(messages[code])


class ScopedSourceApplication:
    """Capture raw integration content in one Source partition."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def capture(self, value: CaptureSource, /) -> SourceReceipt:
        if value.metadata.get("kind") == WORKING_NOTE_SOURCE_KIND:
            raise InvalidRuntimeRequestError("working-note-dedicated-api")
        if self._runtime._record_service is None:
            return await self._capture(value)
        try:
            async with self._runtime._scope_operation(self.scope_id):
                try:
                    capture = ContentCapture.model_validate(
                        {"source_id": value.source_id, "content": value.content, "metadata": dict(value.metadata)},
                        strict=True,
                    )
                except ValidationError as error:
                    raise InvalidBaseAccessRequestError("content", "does not match the Source adapter") from error
                record = await self._runtime._source_captures.capture(
                    self.scope_id, capture, self._runtime._records(), self._capturing()
                )
        except BaseValueConflictError as error:
            raise SourceConflictError("identity", error.identity) from None
        return SourceReceipt(
            source_ref=SourceRef(source_type=record.source_type, source_id=record.source_id), sequence=record.position
        )

    @asynccontextmanager
    async def _capturing(self) -> AsyncIterator[None]:
        # Queue before acquiring the lock, but trace capture only after its wait.
        async with self._runtime._locked(self.scope_id):
            with self._runtime._stage(_MEMORY_CAPTURE_STAGE, attributes={}) as span:
                yield
                if span is not None:
                    span.set_attributes({_MEMORY_CAPTURE_SOURCE_COUNT: 1})

    async def capture_many(self, values: Sequence[CaptureSource], /) -> tuple[SourceReceipt, ...]:
        """Capture one ordered integration batch with stable Source identities."""

        if not values:
            return ()
        if any(value.metadata.get("kind") == WORKING_NOTE_SOURCE_KIND for value in values):
            raise InvalidRuntimeRequestError("working-note-dedicated-api")
        captures = tuple(
            ContentCapture(
                source_id=value.source_id,
                content=value.content,
                metadata=value.model_dump(mode="json")["metadata"],
            )
            for value in values
        )
        if self._runtime._record_service is None:
            raise InvalidRuntimeRequestError("batch-capture-unavailable")
        try:
            async with self._runtime._scope_operation(self.scope_id), self._runtime._locked(self.scope_id):
                with self._runtime._stage(_MEMORY_CAPTURE_STAGE, attributes={}) as span:
                    records = await self._runtime._records().capture_sources(self.scope_id, captures)
                    if span is not None:
                        span.set_attributes({_MEMORY_CAPTURE_SOURCE_COUNT: len(records)})
        except BaseValueConflictError as error:
            raise SourceConflictError("identity", error.identity) from None
        return tuple(
            SourceReceipt(
                source_ref=SourceRef(source_type=record.source_type, source_id=record.source_id),
                sequence=record.position,
            )
            for record in records
        )

    async def capture_working_note(self, value: CaptureWorkingNote, /) -> SourceReceipt:
        """Capture explicit session-local work state without Memory promotion."""

        if _WORKING_NOTE_RESERVED_METADATA.intersection(value.metadata):
            raise InvalidRuntimeRequestError("working-note-metadata")
        if not value.session_id.strip():
            raise ValueError("session_id must not be blank")  # noqa: TRY003
        if not value.note_kind.strip():
            raise ValueError("note_kind must not be blank")  # noqa: TRY003
        if value.expires_at is not None and (value.expires_at.tzinfo is None or value.expires_at.utcoffset() is None):
            raise InvalidRuntimeRequestError("working-note-expiry-timezone")
        metadata = dict(value.metadata)
        metadata.update({
            "kind": WORKING_NOTE_SOURCE_KIND,
            "session_id": value.session_id,
            "note_kind": value.note_kind,
        })
        if value.expires_at is not None:
            metadata["expires_at"] = value.expires_at.astimezone(UTC).isoformat()
        capture = CaptureSource(source_id=value.source_id, content=value.content, metadata=metadata)
        if value.expires_at is not None and value.expires_at <= datetime.now(UTC):
            replay = await self._replay_working_note(capture)
            if replay is not None:
                return replay
            raise InvalidRuntimeRequestError("working-note-expiry-past")
        return await self._capture(capture, working_note=True)

    async def _replay_working_note(self, value: CaptureSource, /) -> SourceReceipt | None:
        capture = ContentCapture(
            source_id=value.source_id,
            content=value.content,
            metadata=value.model_dump(mode="json")["metadata"],
        )
        proposed = (await CONTENT_SOURCE_ADAPTER.resolve(capture)).model_copy(update={"working_note": True})
        ref = SourceRef(source_type=CONTENT_SOURCE_NAME, source_id=value.source_id)
        async with self._runtime._context(self.scope_id) as context, self._runtime._locked(self.scope_id):
            existing = await context.sources.journal.entry(ref)
            if existing is None:
                return None
            if existing.source != proposed:
                raise SourceConflictError("identity", (self.scope_id, ref))
            return SourceReceipt(source_ref=ref, sequence=existing.position)

    async def _capture(
        self,
        value: CaptureSource,
        /,
        *,
        handoff_receipt: bool = False,
        working_note: bool = False,
    ) -> SourceReceipt:
        if self._runtime._record_service is not None:
            try:
                async with self._runtime._scope_operation(self.scope_id), self._runtime._locked(self.scope_id):
                    with self._runtime._stage(_MEMORY_CAPTURE_STAGE, attributes={}) as span:
                        record = await self._runtime._records().capture_source(
                            self.scope_id,
                            CONTENT_SOURCE_NAME,
                            value.source_id,
                            value.content,
                            value.metadata,
                            handoff_receipt=handoff_receipt,
                            working_note=working_note,
                        )
                        if span is not None:
                            span.set_attributes({_MEMORY_CAPTURE_SOURCE_COUNT: 1})
            except BaseValueConflictError as error:
                raise SourceConflictError("identity", error.identity) from None
            return SourceReceipt(
                source_ref=SourceRef(source_type=record.source_type, source_id=record.source_id),
                sequence=record.position,
            )
        async with self._runtime._context(self.scope_id) as context:
            with self._runtime._stage(_MEMORY_CAPTURE_STAGE, attributes={}) as span:
                source, sequence = await context.sources.capture(
                    ContentCapture(
                        source_id=value.source_id,
                        content=value.content,
                        metadata=value.model_dump(mode="json")["metadata"],
                    ),
                    handoff_receipt=handoff_receipt,
                    working_note=working_note,
                )
                if span is not None:
                    span.set_attributes({_MEMORY_CAPTURE_SOURCE_COUNT: 1})
            return SourceReceipt(source_ref=context.sources.catalog.as_ref(source), sequence=sequence)


class SourceApplication:
    """Select a scoped Source application service."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedSourceApplication:
        return ScopedSourceApplication(self._runtime, scope_id)


class ScopedRecordApplication:
    """Run base Source and Artifact operations in one Scope."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def create_source(
        self,
        source_type: str,
        content: JsonValue,
        /,
    ) -> SourceRecord:
        async with self._runtime._scope_operation(self.scope_id), self._runtime._locked(self.scope_id):
            return await self._runtime._records().create_source(
                self.scope_id,
                source_type,
                content,
            )

    async def get_source(self, source_type: str, source_id: str, /) -> SourceRecord:
        async with self._runtime._scope_operation(self.scope_id):
            return await self._runtime._records().get_source(self.scope_id, source_type, source_id)

    async def list_sources(
        self,
        *,
        limit: int,
        cursor: str | None,
        caller: str = "runtime",
    ) -> SourceRecordPage:
        async with self._runtime._scope_operation(self.scope_id):
            return await self._runtime._records().list_sources(
                self.scope_id,
                limit=limit,
                cursor=cursor,
                caller=caller,
            )

    async def create_artifact(
        self,
        family: str,
        write: ArtifactWrite,
        /,
        *,
        execution_context: Any = None,
        on_commit: Callable[[Any, ArtifactCreated], Awaitable[None]] | None = None,
    ) -> ArtifactCreated:
        async with (
            self._runtime._scoped_operation(
                self.scope_id,
                embedding_purpose=ModelUsagePurpose.MEMORY_INDEXING if family == "atomic-memory" else None,
            ),
            self._runtime._locked(self.scope_id),
            (
                observe_processing_failure(
                    family, f"{family}.create", self.scope_id, storage_location=f"{family}-create-storage"
                )
                if family in {"experience", "profile", "prompt", "skill"}
                else nullcontext()
            ),
        ):
            return await self._runtime._records().create_artifact(
                self.scope_id,
                family,
                write,
                execution_context=execution_context,
                **({"on_commit": on_commit} if on_commit is not None else {}),
            )

    async def bind_artifact_handle(self, handle: StableHandle, target: ArtifactRef, /) -> ArtifactRef:
        async with self._runtime._scope_operation(self.scope_id), self._runtime._locked(self.scope_id):
            return await self._runtime._records().bind_artifact_handle(self.scope_id, handle, target)

    async def resolve_artifact_handle(self, handle: StableHandle, /) -> ArtifactRef:
        async with self._runtime._scope_operation(self.scope_id):
            return await self._runtime._records().resolve_artifact_handle(self.scope_id, handle)

    async def get_artifact(self, family: str, artifact_id: str, /, *, execution_context: Any = None) -> ArtifactRecord:
        async with self._runtime._scope_operation(self.scope_id):
            return await self._runtime._records().get_artifact(
                self.scope_id, family, artifact_id, execution_context=execution_context
            )

    async def get_artifact_revision(
        self,
        family: str,
        artifact_id: str,
        revision: int,
        /,
        *,
        execution_context: Any = None,
    ) -> ArtifactRecord:
        async with self._runtime._scope_operation(self.scope_id):
            return await self._runtime._records().get_artifact_revision(
                self.scope_id,
                family,
                artifact_id,
                revision,
                execution_context=execution_context,
            )

    async def list_artifact_revisions(
        self,
        family: str,
        artifact_id: str,
        /,
        *,
        limit: int,
        cursor: str | None,
    ) -> ArtifactRevisionPage:
        async with self._runtime._scope_operation(self.scope_id):
            return await self._runtime._records().list_artifact_revisions(
                self.scope_id, family, artifact_id, limit=limit, cursor=cursor
            )

    async def logical_artifacts(self) -> tuple[LogicalArtifactRecord, ...]:
        async with self._runtime._scope_operation(self.scope_id):
            return await self._runtime._records().logical_artifacts(self.scope_id)

    async def query_artifacts(
        self,
        family: str,
        /,
        *,
        limit: int,
        cursor: str | None,
        tag_filter: TagFilter | None = None,
    ) -> ArtifactRecordPage:
        async with self._runtime._scope_operation(self.scope_id):
            filters = {} if tag_filter is None else {"tag_filter": tag_filter}
            return await self._runtime._records().query_artifacts(
                self.scope_id,
                family,
                limit=limit,
                cursor=cursor,
                **filters,
            )

    async def get_tags(self, target: TagTarget) -> ArtifactTagSet:
        async with self._runtime._scope_operation(self.scope_id):
            return await self._runtime._records().get_tags(self.scope_id, target)

    async def replace_tags(
        self, target: TagTarget, tags: tuple[str, ...], *, expected_etag: str, execution_context=None
    ) -> ArtifactTagSet:
        async with self._runtime._scope_operation(self.scope_id), self._runtime._locked(self.scope_id):
            return await self._runtime._records().replace_tags(
                self.scope_id, target, tags, expected_etag=expected_etag, execution_context=execution_context
            )

    async def query_tags(self, query: TagQuery, *, caller: str = "runtime") -> TagQueryPage:
        async with self._runtime._scope_operation(self.scope_id):
            return await self._runtime._records().query_tags(self.scope_id, query, caller=caller)

    async def replace_artifact(
        self,
        family: str,
        artifact_id: str,
        expected_etag: str,
        write: ArtifactWrite,
        /,
        *,
        actor_type: str | None = None,
        actor_id: str | None = None,
        execution_context: Any = None,
    ) -> ArtifactRecord:
        async with (
            self._runtime._scoped_operation(
                self.scope_id,
                embedding_purpose=ModelUsagePurpose.MEMORY_INDEXING if family == "atomic-memory" else None,
            ),
            self._runtime._locked(self.scope_id),
            (
                observe_processing_failure(
                    family, f"{family}.replace", self.scope_id, storage_location=f"{family}-replace-storage"
                )
                if family in {"experience", "profile", "prompt", "skill"}
                else nullcontext()
            ),
        ):
            return await self._runtime._records().replace_artifact(
                self.scope_id,
                family,
                artifact_id,
                expected_etag,
                write,
                actor_type=actor_type,
                actor_id=actor_id,
                execution_context=execution_context,
            )


class RecordApplication:
    """Select scoped base access and list observable Scopes."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedRecordApplication:
        return ScopedRecordApplication(self._runtime, scope_id)

    async def list_scopes(self, *, limit: int, cursor: str | None) -> ScopeSummaryPage:
        async with self._runtime._operation():
            return await self._runtime._records().list_scopes(limit=limit, cursor=cursor)


class ScopedPromptApplication:
    """Read configuration and generate suggestions inside an existing Scope."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def read_configuration(self, key: str, /) -> PromptConfiguration:
        return (await self.read_configurations((key,)))[0]

    async def read_configurations(self, keys: tuple[str, ...], /) -> tuple[PromptConfiguration, ...]:
        async with self._runtime._scope_operation(self.scope_id):
            service = self._runtime._prompt_service
            if service is None:
                raise PromptError("prompt_customization_unavailable")
            return await service.read_configurations(self.scope_id, keys)

    async def generate_demonstrations(
        self, key: str, request: GeneratePromptDemonstrations, /
    ) -> PromptDemonstrationResult:
        async with (
            self._runtime._scope_operation(self.scope_id),
            observe_processing_failure("prompt", "prompt.generate_demonstrations", self.scope_id),
        ):
            service = self._runtime._prompt_service
            if service is None:
                raise PromptError("prompt_customization_unavailable")
            return await service.generate_demonstrations(key, request)


class PromptApplication:
    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedPromptApplication:
        return ScopedPromptApplication(self._runtime, scope_id)


class RemoteIngestionApplication:
    """Expose worker-owned Definition and observation operations."""

    def __init__(self, runtime: BuiltinRuntime, service: RemoteIngestion | None) -> None:
        self._runtime = runtime
        self._service = service

    def _require_service(self) -> RemoteIngestion:
        if self._service is None:
            raise _RuntimeStateError("remote-ingestion")
        return self._service

    async def register(self, manifest: SourceDefinitionManifest, /) -> SourceDefinitionManifest:
        async with self._runtime._operation():
            return await self._require_service().register_source_definition(manifest)

    async def checkpoint(self, binding: ConnectorBinding, /) -> ConnectorCheckpointState:
        async with self._runtime._scope_operation(binding.scope_id):
            return await self._require_service().connector_checkpoint(binding)

    async def submit(self, request: SubmitSourceObservation, /) -> SourceReceipt:
        async with self._runtime._scope_operation(request.scope_id):
            return await self._require_service().submit_source_observation(request)

    async def commit(self, request: CommitConnectorCheckpoint, /) -> ConnectorCheckpointState:
        async with self._runtime._scope_operation(request.binding.scope_id):
            return await self._require_service().commit_connector_checkpoint(request)


async def _processing_statistics(runtime: BuiltinRuntime, result: Statistics) -> Statistics:
    from powercontext.builtin.runtime.processing_observation import observe_processing

    processing = await observe_processing(
        runtime.primary_database, result.scope_ids, runtime.artifact_processing_supervisor
    )
    return result.model_copy(
        update={
            "by_scope": tuple(
                row.model_copy(update={"processing": processing[row.scope_id]}) for row in result.by_scope
            )
        }
    )


class ScopedStatisticsApplication:
    """Read product statistics and record model usage for one scope."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def overview(
        self, *, period: StatisticsPeriod = StatisticsPeriod.THIRTY_DAYS, include_processing: bool = False
    ) -> Statistics:
        async with self._runtime._scope_operation(self.scope_id):
            result = await self._runtime._statistics(self.scope_id).overview(period, self._runtime._clock())
            return await _processing_statistics(self._runtime, result) if include_processing else result

    async def record_model_usage(
        self,
        purpose: ModelUsagePurpose,
        operation: ModelUsageOperation,
        usage: InferenceUsage,
        /,
    ) -> None:
        """Freeze usage for this Scope; the recorder owns the write.

        The enclosing operation already validated and leased the Scope, so this
        callback performs no I/O. The runtime-owned recorder writes the record in
        an independent short transaction outside the caller's model deadline.
        A Runtime without statistics has no recorder, and accounting must never
        turn a successful model call into a failure.
        """

        if self._runtime._statistics_service is None:
            return
        self._runtime._statistics(self.scope_id).offer_model_usage(
            purpose,
            operation,
            usage,
            self._runtime._clock().astimezone(UTC).date(),
        )

    async def record_recall(self, measurement: RecallTokenMeasurement, /) -> None:
        try:
            async with self._runtime._scope_operation(self.scope_id):
                await self._runtime._statistics(self.scope_id).record_recall(
                    measurement,
                    self._runtime._clock().astimezone(UTC).date(),
                )
        except Exception as error:
            log_safely(
                logger,
                logging.ERROR,
                "Recall token recording failed",
                exc_info=error,
                extra={
                    "event": "statistics.recall_tokens.failed",
                    "estimator_id": measurement.estimator.estimator_id,
                    "outcome": "failure",
                    "unit": "statistics",
                },
            )


class StatisticsApplication:
    """Select scoped product statistics."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedStatisticsApplication:
        return ScopedStatisticsApplication(self._runtime, scope_id)

    async def overview(
        self,
        selection: ScopeSelection,
        *,
        period: StatisticsPeriod = StatisticsPeriod.THIRTY_DAYS,
        include_processing: bool = False,
    ) -> Statistics:
        if self._runtime.scopes is None:
            raise _RuntimeStateError("statistics")
        async with self._runtime._operation():
            resolved = await self._runtime.scopes.resolve_selection(selection)
            captured_at = self._runtime._clock()
            snapshots = await overview_selection(
                tuple(self._runtime._statistics(scope.scope_id) for scope in resolved),
                period,
                captured_at,
            )
            result = aggregate_statistics(selection, snapshots, captured_at)
            return await _processing_statistics(self._runtime, result) if include_processing else result


_PREPARE_ATOMIC_CONTEXT: ContextVar[ArtifactSearchExecutionContext | None] = ContextVar(
    "prepare_atomic_context", default=None
)


class ScopedContextApplication:
    """Prepare final context for one scope using Runtime-owned source policy."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def prepare(
        self,
        request: PrepareContextRequest,
        /,
        *,
        authorize_scopes: Callable[[tuple[str, ...]], Awaitable[None]] | None = None,
        atomic_context: ArtifactSearchExecutionContext | None = None,
        binding_identity: str = "local",
    ) -> PrepareContextResult:
        if (
            request.assembly is not None
            and sum(section.limit for section in request.assembly.sections) > self._runtime.context_assembly_max_entries
        ):
            raise InvalidRuntimeRequestError("context-assembly-entry-limit")
        async with self._runtime._scope_operation(self.scope_id) as scope:
            if (
                request.assembly is not None
                and not request.assembly.sections
                and not request.include_code
                and not request.include_reuse
            ):
                empty = PreparedContextBuilder().empty()
                return (
                    self._attach_receipt(request, PreparedContextBuild(context=empty, origins=()), ReceiptEvidence())
                    if request.include_receipt
                    else empty
                )
            if authorize_scopes is not None:
                await authorize_scopes((self.scope_id, *scope.context_references))
            if request.include_reuse:
                self._require_reuse_scope(scope)
            token = _PREPARE_ATOMIC_CONTEXT.set(atomic_context)
            try:
                return await self._prepare(request, scope, binding_identity=binding_identity)
            finally:
                _PREPARE_ATOMIC_CONTEXT.reset(token)

    def _require_reuse_scope(self, scope: ScopeDescriptor) -> None:
        if scope.context_references:
            raise ContextReuseError("context-reuse-cross-scope-unsupported")

    async def validate_reuse(
        self,
        binding: str,
        /,
        *,
        binding_identity: str = "local",
        atomic_context: ArtifactSearchExecutionContext | None = None,
        authorize_scopes: Callable[[tuple[str, ...]], Awaitable[None]] | None = None,
    ) -> ValidatedContextReuse:
        """Reauthorize exact retained evidence without recall or model calls."""
        async with self._runtime._scope_operation(self.scope_id) as scope:
            if authorize_scopes is not None:
                await authorize_scopes((self.scope_id,))
            self._require_reuse_scope(scope)
            atomic = self._runtime.atomic_memory
            return await validate_reuse(
                None if atomic is None else atomic.for_scope(self.scope_id),
                self.scope_id,
                binding,
                codec=self._runtime.context_binding_codec,
                binding_identity=binding_identity,
                now=self._runtime._clock(),
                context=atomic_context,
                code=self._runtime.code.for_scope(self.scope_id),
            )

    async def check(
        self,
        request: CheckContextRequest,
        /,
        *,
        binding_identity: str = "local",
        atomic_context: ArtifactSearchExecutionContext | None = None,
        authorize_scopes: Callable[[tuple[str, ...]], Awaitable[None]] | None = None,
        resolve_target: bool = False,
    ) -> ContextCheckResult:
        """Admit final bytes without retrieving or changing the current context."""
        async with self._runtime._scope_operation(self.scope_id):
            if authorize_scopes is not None:
                await authorize_scopes((self.scope_id,))

            async def validate(binding: str) -> ValidatedContextReuse:
                return await self.validate_reuse(
                    binding,
                    binding_identity=binding_identity,
                    atomic_context=atomic_context,
                    authorize_scopes=authorize_scopes,
                )

            return await check_context(
                request,
                scope_id=self.scope_id,
                config=self._runtime.inference_protection,
                codec=self._runtime.context_binding_codec,
                binding_identity=binding_identity,
                now=self._runtime._clock(),
                validate_reuse=validate,
                resolve_target=resolve_target,
            )

    async def _prepare(
        self, request: PrepareContextRequest, scope: ScopeDescriptor, /, *, binding_identity: str = "local"
    ) -> PrepareContextResult:
        evidence = ReceiptEvidence() if request.include_receipt else None
        token = bind_receipt_evidence(evidence)
        try:
            build, effort = await self._prepare_build(request, scope)
        finally:
            unbind_receipt_evidence(token)
        if effort is not None:
            try:
                # An explicit sink replaces the relational recorder. Both receive
                # the same final trace, and one preparation is never recorded twice.
                if self._runtime._recall_effort_sink is not None:
                    await self._runtime._recall_effort_sink(effort)
                elif self._runtime._statistics_service is not None:
                    await self._runtime._statistics(self.scope_id).record_recall_effort(
                        effort,
                        self._runtime._clock().astimezone(UTC).date(),
                    )
            except Exception as error:
                log_safely(
                    logger,
                    logging.ERROR,
                    "Recall effort sink failed",
                    extra={
                        "event": "context.recall_gate.sink_failed",
                        "outcome": "failure",
                        "unit": "context",
                        "error_type": type(error).__name__,
                    },
                )
        if self._runtime._recall_token_estimator is not None:
            try:
                measurement = await self._runtime._recall_token_estimator(self.scope_id, build)
            except InferencePrivacyError:
                raise
            except Exception as error:
                log_safely(
                    logger,
                    logging.ERROR,
                    "Recall token estimation failed",
                    exc_info=error,
                    extra={
                        "event": "statistics.recall_tokens.estimation_failed",
                        "outcome": "failure",
                        "unit": "statistics",
                    },
                )
            else:
                if measurement is not None:
                    await self._runtime.statistics.for_scope(self.scope_id).record_recall(measurement)
        return await self._prepared_result(request, build, binding_identity, evidence)

    async def _prepared_result(
        self,
        request: PrepareContextRequest,
        build: PreparedContextBuild,
        binding_identity: str,
        evidence: ReceiptEvidence | None,
    ) -> PrepareContextResult:
        """Expose only explicitly requested diagnostics and current reuse proof."""
        context = self._attach_receipt(request, build, evidence)
        if request.include_reuse:
            atomic = self._runtime.atomic_memory
            return await prepare_reuse(
                None if atomic is None else atomic.for_scope(self.scope_id),
                self.scope_id,
                build,
                context,
                codec=self._runtime.context_binding_codec,
                binding_identity=binding_identity,
                now=self._runtime._clock(),
                context=_PREPARE_ATOMIC_CONTEXT.get(),
                code=self._runtime.code.for_scope(self.scope_id),
            )
        return context

    def _attach_receipt(
        self, request: PrepareContextRequest, build: PreparedContextBuild, evidence: ReceiptEvidence | None
    ) -> PreparedContext:
        if evidence is None:
            return build.context
        try:
            receipt = evidence.build(request, build.context, build, self.scope_id)
        except Exception as error:
            log_safely(
                logger,
                logging.WARNING,
                "PreparedContext Receipt omitted",
                extra={
                    "event": "context.receipt.omitted",
                    "operation": "prepare_context",
                    "outcome": "failure",
                    "unit": "context",
                    "error_code": "receipt-byte-limit"
                    if isinstance(error, ValueError) and str(error) == "receipt-byte-limit"
                    else "receipt-assembly-failed",
                },
            )
            return build.context
        log_safely(
            logger,
            logging.INFO,
            "PreparedContext Receipt built",
            extra={
                "event": "context.receipt.built",
                "operation": "prepare_context",
                "outcome": "success",
                "unit": "context",
                "receipt_id": receipt.receipt_id,
            },
        )
        return build.context.model_copy(update={"receipt": receipt})

    async def _prepare_build(
        self,
        request: PrepareContextRequest,
        scope: ScopeDescriptor,
        /,
    ) -> tuple[PreparedContextBuild, RecallEffort | None]:
        """Recall the participating families, optionally expand, then build the context.

        The controlled expansion loop lives here. It runs at most ``policy.max_rounds`` extra
        searches, each of which only lowers the admission floor for the families the caller
        already selected — never a new family, a larger ``limit``, or a different ``mode``.
        Every gate or expansion error preserves the last committed candidate set.

        Returns ``(build, effort)``. The RFC 1560 trace is **not** a field of the build:
        ``_prepare`` returns ``build.context`` and discards the rest, so a field there would
        have no production observer. The trace is returned alongside the build and delivered
        by ``_prepare`` to the Runtime's optional sink. ``effort`` is ``None`` whenever the
        policy is not configured, so the default-off path allocates nothing.
        """

        builder = PreparedContextBuilder()
        if request.include_code:
            builder.entry_limit = self._runtime.context_assembly_max_entries
        scope_ids = [self.scope_id, *scope.context_references]
        families: set[str] = (
            {section.family for section in request.assembly.sections}
            if request.assembly is not None
            else {MEMORY_FAMILY, EXPERIENCE_FAMILY, TOPIC_MEMORY_FAMILY}
        )
        # Caller-owned cache of the query vectors round 0 already paid for, keyed by scope.
        # Expansion rounds read it so a repeat search does not re-embed; round 0 fills it.
        reuse: dict[str, MemoryQueryEmbedding | None] = {}
        topic_reuse: dict[str, MemoryQueryEmbedding | None] = {}
        injected_memory_keys: frozenset[tuple[object, ...]] = frozenset()
        if request.bootstrap_receipt_id is not None and self._runtime._bootstrap_receipts is not None:
            receipts = self._runtime._bootstrap_receipts
            cutoff = self._runtime._clock().astimezone(UTC) - _BOOTSTRAP_RECEIPT_RETENTION
            await receipts.delete_before(cutoff)
            injected_memory_keys = await receipts.injected_memory_keys(
                self.scope_id,
                request.bootstrap_receipt_id,
            )

        # One budget covers every query embedding this preparation waits for. Each search gets what the earlier ones
        # left, so the waits cannot add up past it however many Scopes and families are searched.
        embedding_budget = _EmbeddingBudget(self._runtime.recall_embedding_timeout_seconds)
        round_zero = await self._recall_round(
            request,
            scope_ids,
            families,
            builder,
            admission=None,
            reuse=reuse,
            topic_reuse=topic_reuse,
            embedding_budget=embedding_budget,
            excluded_memory=injected_memory_keys,
        )
        evidence = current_receipt_evidence()
        if evidence is not None:
            evidence.rounds.append(RecallRound(round=0, outcome="completed", retained=True))
        memory_candidates = list(round_zero.memory)
        experience_candidates = list(round_zero.experience)
        topic_memory_hits = round_zero.topic_memory.hits
        profile_candidates = await self._prepare_profiles(scope_ids, families, evidence)

        policy = self._runtime.recall_sufficiency_policy
        recall_effort: RecallEffort | None = None
        if policy is not None:
            (
                memory_candidates,
                experience_candidates,
                topic_memory_hits,
                recall_effort,
            ) = await self._gated_recall_effort(
                request=request,
                scope_ids=scope_ids,
                families=families,
                builder=builder,
                policy=policy,
                memory_candidates=memory_candidates,
                experience_candidates=experience_candidates,
                topic_memory_hits=topic_memory_hits,
                profile_candidates=profile_candidates,
                reuse=reuse,
                topic_reuse=topic_reuse,
                embedding_budget=embedding_budget,
                round_zero=round_zero,
                excluded_memory=injected_memory_keys,
            )
        if evidence is not None:
            evidence.round = 0
        memory_candidates = await self._available_atomic_candidates(memory_candidates)
        code = await self._code_candidates(request) if request.include_code else ()
        self._record_unretrieved(
            evidence,
            families,
            request.include_code,
            memory_candidates,
            topic_memory_hits,
            experience_candidates,
            profile_candidates,
            code,
            plugins={
                section.family: bool(section.hits)
                for section in (request.assembly.sections if request.assembly is not None else ())
                if section.family not in BUILTIN_CONTEXT_FAMILIES
            },
            failed_plugins=[
                section.family
                for section in (request.assembly.sections if request.assembly is not None else ())
                if section.search_failed
            ],
        )
        started_build = perf_counter() if evidence is not None else None
        with self._runtime._stage(
            "context.build",
            attributes={
                "powercontext.context.build.scope_count": len(scope_ids),
                "powercontext.context.build.memory_candidate_count": sum(
                    len(candidates.hits) for candidates in memory_candidates
                ),
                "powercontext.context.build.topic_memory_candidate_count": len(topic_memory_hits),
                "powercontext.context.build.experience_candidate_count": sum(
                    len(candidates.hits) for candidates in experience_candidates
                ),
                "powercontext.context.build.profile_candidate_count": len(profile_candidates),
                "powercontext.context.build.code_candidate_count": len(code),
            },
        ) as span:
            build = builder.build_scopes_result(
                request=request,
                current_scope_id=self.scope_id,
                memory_candidates=memory_candidates,
                topic_memory_hits=topic_memory_hits,
                experience_candidates=experience_candidates,
                profile_candidates=profile_candidates,
                code_candidates=code,
            )
            build = replace(
                build,
                lineages=tuple(
                    (ArtifactAddress(scope_id=group.scope_id, artifact=hit.hit.artifact_ref), hit.lineage)
                    for group in memory_candidates
                    for hit in group.hits
                    if hit.lineage is not None
                ),
            )
            build = self._bind_reuse_roots(request, build, memory_candidates)
            if recall_effort is not None:
                recall_effort = replace(
                    recall_effort,
                    truncated_items=build.omissions.truncated_items,
                    dropped_items=build.omissions.dropped_items,
                    dropped_below_min_bytes=build.omissions.dropped_below_min_bytes,
                    dropped_no_fitting_truncation=build.omissions.dropped_no_fitting_truncation,
                )
            if span is not None:
                span.set_attributes({
                    "powercontext.context.build.selected_count": len(build.origins) + len(build.code_origins),
                    "powercontext.context.build.code_selected_count": len(build.code_origins),
                    "powercontext.context.build.code_injected_count": len(build.code_origins),
                    "powercontext.context.build.code_omitted_count": max(0, len(code) - len(build.code_origins)),
                    "powercontext.context.build.status": build.context.status,
                    "powercontext.context.build.content_bytes": build.context.content_bytes,
                })
                if recall_effort is not None:
                    # RFC 0028 permits "internal search mode and aggregate selection counts".
                    # These four are aggregates only: no query text, no entry id, no per-entry
                    # attribution, and nothing is written to a table.
                    span.set_attributes({
                        "powercontext.context.build.recall.rounds": recall_effort.rounds,
                        "powercontext.context.build.recall.assessment": recall_effort.assessment,
                        "powercontext.context.build.recall.truncated_items": recall_effort.truncated_items,
                        "powercontext.context.build.recall.dropped_items": recall_effort.dropped_items,
                    })
        if evidence is not None and started_build is not None:
            evidence.stage("context.build", (perf_counter() - started_build) * 1000)
        # Round zero is the round that embeds: later expansion rounds reuse its vector when it
        # has one, so a cause observed here is the whole preparation's cause.
        return replace(build, degradation=round_zero.degradation), recall_effort

    def _bind_reuse_roots(
        self,
        request: PrepareContextRequest,
        build: PreparedContextBuild,
        memory_candidates: Sequence[PreparedMemoryCandidates],
    ) -> PreparedContextBuild:
        """Bind final selected origins to their observed current lifecycle versions."""
        if not request.include_reuse:
            return build
        # Final origins, not all recalled candidates, own the reuse proof.
        selected_keys = {
            (origin.scope_id, origin.artifact.family, origin.artifact.artifact_id, origin.artifact.revision)
            if isinstance(origin, ArtifactAddress)
            else (self.scope_id, origin.family, origin.artifact_id, origin.revision)
            for origin in build.origins
        }
        return replace(
            build,
            reuse_roots=tuple(
                AtomicMemoryDependencySelection(
                    address=ArtifactAddress(scope_id=group.scope_id, artifact=hit.hit.artifact_ref),
                    state_version=hit.hit.state_version,
                    kind=hit.hit.kind,
                    text_digest=sha256(hit.hit.text.encode("utf-8")).hexdigest(),
                )
                for group in memory_candidates
                for hit in group.hits
                if (
                    group.scope_id,
                    hit.hit.artifact_ref.family,
                    hit.hit.artifact_ref.artifact_id,
                    hit.hit.artifact_ref.revision,
                )
                in selected_keys
            ),
        )

    async def _prepare_profiles(
        self, scope_ids: Sequence[str], families: set[str], evidence: ReceiptEvidence | None
    ) -> list[PreparedProfileCandidate]:
        candidates: list[PreparedProfileCandidate] = []
        profiles = self._runtime.profiles
        if "profile" in families and profiles is not None:
            async with profiles.database.transaction() as connection:
                for scope_id in scope_ids:
                    profile = await profiles.latest(connection, scope_id)
                    if evidence is not None:
                        evidence.search("profile", "snapshot", "completed")
                    if profile is not None:
                        candidates.append(PreparedProfileCandidate(scope_id=scope_id, profile=profile))
        elif "profile" in families and evidence is not None:
            for _scope_id in scope_ids:
                evidence.search("profile", None, "not_run")
        return candidates

    @staticmethod
    def _record_unretrieved(
        evidence: ReceiptEvidence | None,
        families: set[str],
        include_code: bool,
        memory: Sequence[PreparedMemoryCandidates],
        topic: Sequence[TopicMemorySearchHit],
        experience: Sequence[PreparedExperienceCandidates],
        profiles: Sequence[PreparedProfileCandidate],
        code: Sequence[PreparedCodeCandidate],
        *,
        plugins: Mapping[str, bool],
        failed_plugins: Sequence[str] = (),
    ) -> None:
        if evidence is None:
            return
        for family in failed_plugins:
            evidence.search(family, "none", "failed")
        retrieved = {
            **plugins,
            MEMORY_FAMILY: any(group.hits for group in memory),
            TOPIC_MEMORY_FAMILY: bool(topic),
            EXPERIENCE_FAMILY: any(group.hits for group in experience),
            "profile": bool(profiles),
            "code": bool(code),
        }
        for family in families | ({"code"} if include_code else set()):
            if not retrieved[family]:
                evidence.omitted[("atomic-memory" if family == MEMORY_FAMILY else family, "not_retrieved")] = 1

    async def _available_atomic_candidates(
        self, candidates: list[PreparedMemoryCandidates]
    ) -> list[PreparedMemoryCandidates]:
        atomic = self._runtime.atomic_memory
        if atomic is None:
            return candidates
        available = []
        for group in candidates:
            hits = await atomic.for_scope(group.scope_id)._filter_current_candidates(
                group.hits, context=_PREPARE_ATOMIC_CONTEXT.get()
            )
            available.append(replace(group, hits=hits))
        return available

    async def _code_candidates(self, request: PrepareContextRequest) -> tuple[PreparedCodeCandidate, ...]:
        evidence = current_receipt_evidence()
        try:
            result = await self._runtime.code.for_scope(self.scope_id).query(
                CodeQueryRequest.model_validate({
                    "operation": {"kind": "explore", "query": request.query},
                    "max_bytes": 16000,
                })
            )
        except CodeError as error:
            if evidence is not None:
                evidence.search("code", "code", "failed")
            log_safely(
                logger,
                logging.INFO,
                "Code context unavailable",
                extra={
                    "event": "context.code.unavailable",
                    "reason": error.code,
                },
            )
            return ()
        candidates = code_candidates(result) if isinstance(result, CodeQueryResult) else ()
        if evidence is not None:
            evidence.search("code", "code", "completed")
        log_safely(
            logger,
            logging.INFO,
            "Code context retrieved",
            extra={
                "event": "context.code.retrieved",
                "candidate_count": len(candidates),
            },
        )
        return candidates

    async def _gated_recall_effort(  # noqa: C901 - the bounded expansion loop is intentionally explicit
        self,
        *,
        request: PrepareContextRequest,
        scope_ids: Sequence[str],
        families: set[str],
        builder: PreparedContextBuilder,
        policy: RecallSufficiencyPolicy,
        memory_candidates: list[PreparedMemoryCandidates],
        experience_candidates: list[PreparedExperienceCandidates],
        topic_memory_hits: tuple[TopicMemorySearchHit, ...],
        profile_candidates: Sequence[PreparedProfileCandidate],
        reuse: dict[str, MemoryQueryEmbedding | None],
        topic_reuse: dict[str, MemoryQueryEmbedding | None],
        embedding_budget: _EmbeddingBudget,
        round_zero: _RecallRoundOutcome,
        excluded_memory: frozenset[tuple[object, ...]],
    ) -> tuple[
        list[PreparedMemoryCandidates],
        list[PreparedExperienceCandidates],
        tuple[TopicMemorySearchHit, ...],
        RecallEffort,
    ]:
        """Run the bounded expansion loop and return the winning candidates plus the trace.

        Candidates accumulate across rounds; only new identities are ever added, so an earlier
        round's candidate is never removed. Any error returns the last committed candidates unchanged
        and records ``expansion-failed`` — the gate can never turn a successful prepare into a
        failure. For a consistent signal basis, ``candidates_by_round`` counts the *un-truncated*
        accumulated pool (no family is clamped while the gate is consulting it); the Builder
        ceilings are applied once, on the returned candidates only. Committed candidates keep the
        latest round's fused order inside those ceilings, so evidence surfaced by a later round is
        deliverable instead of trailing the round-zero prefix.
        """

        gate = RecallSufficiencyGate()
        expander = RecallExpander()
        families_expected = _families_with_retrieved_candidates(
            families,
            round_zero.admissions,
            memory_present=round_zero.memory_recoverable or any(group.hits for group in memory_candidates),
        )
        families_recoverable = _families_with_recoverable_candidates(
            families, round_zero.admissions, memory_recoverable=round_zero.memory_recoverable
        )
        memory_hits_by_scope = {group.scope_id: list(group.hits) for group in memory_candidates}
        memory_versions = {
            (group.scope_id, hit.hit.artifact_ref.artifact_id): (hit.hit.artifact_ref, hit.hit.state_version)
            for group in memory_candidates
            for hit in group.hits
        }
        seen_memory = {_memory_identity(group.scope_id, hit) for group in memory_candidates for hit in group.hits}
        experience_hits_by_scope = {group.scope_id: list(group.hits) for group in experience_candidates}
        seen_experience = {
            _experience_identity(group.scope_id, hit) for group in experience_candidates for hit in group.hits
        }
        accumulated_topic = list(topic_memory_hits)
        seen_topic = {_topic_identity(hit) for hit in topic_memory_hits}
        candidates = build_recall_candidates(
            memory_hits=_flatten_memory_hits(memory_candidates),
            topic_memory_hits=topic_memory_hits,
            experience_hits=_flatten_experience_hits(experience_candidates),
            memory_scope_ids=tuple(group.scope_id for group in memory_candidates for _hit in group.hits),
        )
        round_zero_count = len(candidates)
        candidates_by_round = [round_zero_count]
        expansions: list[str] = []
        added_embeddings = 0
        added_generation_calls = 0
        admission_by_family = list(round_zero.admissions)
        last_signals = None
        committed_memory = memory_candidates
        committed_experience = experience_candidates
        committed_topic = topic_memory_hits
        evidence = current_receipt_evidence()
        retained_omissions = None if evidence is None else evidence.omitted.copy()
        try:
            budget = builder.probe_budget(
                request=request,
                current_scope_id=self.scope_id,
                memory_candidates=memory_candidates,
                topic_memory_hits=topic_memory_hits,
                experience_candidates=experience_candidates,
                profile_candidates=profile_candidates,
            )
            assessment = gate.assess(
                candidates,
                request.query,
                policy,
                scope_has_content=bool(candidates) or families_expected > 0,
                budget=budget,
                families_expected=families_expected,
            )
            last_signals = assessment.signals
            while not assessment.sufficient and families_recoverable > 0 and len(expansions) < policy.max_rounds:
                plan = expander.plan(len(expansions) + 1, policy)
                evidence = current_receipt_evidence()
                if evidence is not None:
                    evidence.round = len(expansions) + 1
                    retained_omissions = evidence.omitted.copy()
                issued = await self._recall_round(
                    request,
                    scope_ids,
                    families,
                    builder,
                    admission=plan.admission,
                    reuse=reuse,
                    topic_reuse=topic_reuse,
                    embedding_budget=embedding_budget,
                    excluded_memory=excluded_memory,
                )
                memory_ranks: dict[Any, int] = {}
                for group in issued.memory:
                    _ensure_memory_heads_stable(group, memory_versions)
                    bucket = memory_hits_by_scope.setdefault(group.scope_id, [])
                    for hit in group.hits:
                        identity = _memory_identity(group.scope_id, hit)
                        memory_ranks[identity] = len(memory_ranks)
                        if identity in seen_memory:
                            if evidence is not None:
                                evidence.omitted[("atomic-memory", "duplicate")] += 1
                            continue
                        seen_memory.add(identity)
                        bucket.append(hit)
                experience_ranks: dict[Any, int] = {}
                for group in issued.experience:
                    bucket = experience_hits_by_scope.setdefault(group.scope_id, [])
                    for hit in group.hits:
                        identity = _experience_identity(group.scope_id, hit)
                        experience_ranks[identity] = len(experience_ranks)
                        if identity in seen_experience:
                            if evidence is not None:
                                evidence.omitted[("experience", "duplicate")] += 1
                            continue
                        seen_experience.add(identity)
                        bucket.append(hit)
                topic_ranks = {_topic_identity(hit): index for index, hit in enumerate(issued.topic_memory.hits)}
                for hit in issued.topic_memory.hits:
                    identity = _topic_identity(hit)
                    if identity in seen_topic:
                        if evidence is not None:
                            evidence.omitted[("topic-memory", "duplicate")] += 1
                        continue
                    seen_topic.add(identity)
                    accumulated_topic.append(hit)
                candidates = build_recall_candidates(
                    memory_hits=_flatten_scope_memory(memory_hits_by_scope, scope_ids),
                    topic_memory_hits=tuple(accumulated_topic),
                    experience_hits=_flatten_scope_experience(experience_hits_by_scope, scope_ids),
                    memory_scope_ids=tuple(
                        scope_id for scope_id in scope_ids for _hit in memory_hits_by_scope.get(scope_id, ())
                    ),
                )
                staged_memory = _limit_expanded_memory_candidates(
                    [
                        PreparedMemoryCandidates(
                            scope_id=scope_id,
                            hits=_latest_round_order(
                                memory_hits_by_scope.get(scope_id, ()),
                                memory_ranks,
                                lambda hit, s=scope_id: _memory_identity(s, hit),
                            ),
                        )
                        for scope_id in scope_ids
                    ],
                    memory_candidates,
                    builder.memory_candidate_limit,
                )
                staged_topic = _latest_round_order(accumulated_topic, topic_ranks, _topic_identity)[
                    : builder.topic_memory_candidate_limit
                ]
                staged_experience = _limit_expanded_experience_candidates(
                    [
                        PreparedExperienceCandidates(
                            scope_id=scope_id,
                            hits=_latest_round_order(
                                experience_hits_by_scope.get(scope_id, ()),
                                experience_ranks,
                                lambda hit, s=scope_id: _experience_identity(s, hit),
                            ),
                        )
                        for scope_id in scope_ids
                    ],
                    experience_candidates,
                    builder.experience_candidate_limit,
                )
                if evidence is not None:
                    evidence.omitted[("atomic-memory", "family_limit")] += sum(
                        map(len, memory_hits_by_scope.values())
                    ) - sum(len(group.hits) for group in staged_memory)
                    evidence.omitted[("topic-memory", "family_limit")] += len(accumulated_topic) - len(staged_topic)
                    evidence.omitted[("experience", "family_limit")] += sum(
                        map(len, experience_hits_by_scope.values())
                    ) - sum(len(group.hits) for group in staged_experience)
                budget = builder.probe_budget(
                    request=request,
                    current_scope_id=self.scope_id,
                    memory_candidates=staged_memory,
                    topic_memory_hits=staged_topic,
                    experience_candidates=staged_experience,
                    profile_candidates=profile_candidates,
                )
                assessment = gate.assess(
                    candidates,
                    request.query,
                    policy,
                    scope_has_content=bool(candidates) or families_expected > 0,
                    budget=budget,
                    families_expected=families_expected,
                )
                committed_memory = staged_memory
                committed_experience = staged_experience
                committed_topic = staged_topic
                expansions.append(plan.action)
                if evidence is not None:
                    evidence.rounds.append(RecallRound(round=evidence.round, outcome="completed", retained=True))
                added_embeddings += issued.embedding_calls
                added_generation_calls += issued.generation_calls
                admission_by_family = list(issued.admissions)
                families_recoverable = _families_with_recoverable_candidates(
                    families, issued.admissions, memory_recoverable=issued.memory_recoverable
                )
                candidates_by_round.append(len(candidates))
                last_signals = assessment.signals
            if (
                not assessment.sufficient
                and assessment.reason != REASON_WEAK_TOP_ONE
                and families_recoverable > 0
                and len(expansions) >= policy.max_rounds
            ):
                assessment = replace(assessment, reason=REASON_AT_MAX_ROUNDS)
            reason = assessment.reason
        except InferencePrivacyError:
            raise
        except Exception as error:
            evidence = current_receipt_evidence()
            if evidence is not None and evidence.round > len(expansions):
                evidence.rounds.append(RecallRound(round=evidence.round, outcome="expansion_failed", retained=False))
                if retained_omissions is not None:
                    evidence.omitted = retained_omissions
            log_safely(
                logger,
                logging.ERROR,
                "Recall sufficiency expansion failed; keeping the last committed candidates",
                exc_info=error,
                extra={
                    "event": "context.recall_gate.expansion_failed",
                    "outcome": "failure",
                    "unit": "context",
                },
            )
            reason = REASON_EXPANSION_FAILED
        return (
            committed_memory,
            committed_experience,
            committed_topic,
            recall_effort(
                policy=policy,
                assessment=reason,
                expansion_actions=expansions,
                candidates_by_round=candidates_by_round,
                admission_by_family=admission_by_family,
                added_embeddings=added_embeddings,
                added_generation_calls=added_generation_calls,
                signals=last_signals,
            ),
        )

    async def _recall_round(
        self,
        request: PrepareContextRequest,
        scope_ids: Sequence[str],
        families: set[str],
        builder: PreparedContextBuilder,
        *,
        admission: AdmissionFloor | None,
        reuse: dict[str, MemoryQueryEmbedding | None],
        topic_reuse: dict[str, MemoryQueryEmbedding | None],
        embedding_budget: _EmbeddingBudget,
        excluded_memory: frozenset[tuple[object, ...]],
    ) -> _RecallRoundOutcome:
        memory_candidates: list[PreparedMemoryCandidates] = []
        experience_candidates: list[PreparedExperienceCandidates] = []
        admissions: list[AdmissionCounts] = []
        embedding_calls = 0
        generation_calls = 0
        memory_recoverable = False
        degradation: str | None = None
        shared_embedding = next((embedding for embedding in reuse.values() if embedding is not None), None)
        for scope_id in scope_ids:
            memory_limit = (
                builder.memory_candidate_limit + sum(identity[0] == scope_id for identity in excluded_memory)
                if MEMORY_FAMILY in families
                else 0
            )
            outcome = await self._recall_scope(
                scope_id,
                request,
                memory_limit=memory_limit,
                experience_limit=builder.experience_candidate_limit if EXPERIENCE_FAMILY in families else 0,
                memory_requested=MEMORY_FAMILY in families,
                experience_requested=EXPERIENCE_FAMILY in families,
                admission=admission,
                reuse=reuse.get(scope_id, shared_embedding),
                allow_embedding=scope_id not in reuse or reuse[scope_id] is not None,
                embedding_budget=embedding_budget,
            )
            memory_recoverable |= outcome.memory_recoverable
            degradation = _degradation(degradation, outcome.memory_embedding_fallback)
            memory_candidates.append(
                replace(
                    outcome.memory,
                    hits=tuple(
                        hit
                        for hit in outcome.memory.hits
                        if _bootstrap_memory_identity(outcome.memory.scope_id, hit) not in excluded_memory
                    ),
                )
                if excluded_memory
                else outcome.memory
            )
            experience_candidates.append(outcome.experience)
            reuse[scope_id] = outcome.memory_query_embedding
            if outcome.memory_query_embedding is not None:
                shared_embedding = outcome.memory_query_embedding
            admissions.extend(
                count for count in (outcome.memory_admission, outcome.experience_admission) if count is not None
            )
            embedding_calls += outcome.embedding_calls
            generation_calls += outcome.generation_calls
        unbounded_memory = memory_candidates
        unbounded_experience = experience_candidates
        memory_candidates = _limit_memory_candidates(memory_candidates, builder.memory_candidate_limit)
        experience_candidates = _limit_experience_candidates(
            experience_candidates,
            builder.experience_candidate_limit,
        )
        evidence = current_receipt_evidence()
        if evidence is not None:
            for family, before, after in (
                ("atomic-memory", unbounded_memory, memory_candidates),
                ("experience", unbounded_experience, experience_candidates),
            ):
                dropped = sum(len(group.hits) for group in before) - sum(len(group.hits) for group in after)
                evidence.omitted[(family, "family_limit")] += dropped
        atomic = self._runtime.atomic_memory
        topic_embedding = topic_reuse.get(self.scope_id)
        if (
            self.scope_id not in topic_reuse
            and atomic is not None
            and self._runtime._topic_memory_embedding_model is atomic._application.embedding_model
            and bounded_topic_memory_query(request.query.strip()) == request.query
        ):
            topic_embedding = shared_embedding
        topic_outcome = (
            await self._topic_memory_hits(
                request.query.strip(),
                builder.topic_memory_candidate_limit,
                admission=admission,
                reuse=topic_embedding,
                allow_embedding=self.scope_id not in topic_reuse or topic_reuse[self.scope_id] is not None,
                embedding_budget=embedding_budget,
            )
            if TOPIC_MEMORY_FAMILY in families
            else TopicMemoryRecallOutcome()
        )
        if TOPIC_MEMORY_FAMILY in families:
            topic_reuse[self.scope_id] = topic_outcome.query_embedding
            evidence = current_receipt_evidence()
            if evidence is not None:
                evidence.search(
                    "topic-memory",
                    topic_outcome.mode,
                    "completed" if self._runtime._topic_memory_search is not None else "not_run",
                    topic_outcome.embedding_fallback or "none",
                    scope_id=self.scope_id,
                )
        return _RecallRoundOutcome(
            memory=tuple(memory_candidates),
            experience=tuple(experience_candidates),
            topic_memory=topic_outcome,
            admissions=tuple(admissions) + (() if topic_outcome.admission is None else (topic_outcome.admission,)),
            embedding_calls=embedding_calls + topic_outcome.embedding_calls,
            generation_calls=generation_calls,
            memory_recoverable=memory_recoverable,
            degradation=_degradation(degradation, topic_outcome.embedding_fallback),
        )

    async def _recall_scope(
        self,
        scope_id: str,
        request: PrepareContextRequest,
        *,
        memory_limit: int,
        experience_limit: int,
        memory_requested: bool,
        experience_requested: bool,
        admission: AdmissionFloor | None,
        reuse: MemoryQueryEmbedding | None,
        allow_embedding: bool = True,
        embedding_budget: _EmbeddingBudget,
    ) -> _ScopeRecallOutcome:
        evidence = current_receipt_evidence()
        async with self._runtime._scoped_operation(scope_id, embedding_purpose=ModelUsagePurpose.MEMORY_RECALL):
            started_memory = perf_counter() if evidence is not None else None
            with self._runtime._stage(
                _MEMORY_SEARCH_STAGE,
                attributes={_MEMORY_SEARCH_REQUESTED_MODE: "auto", _MEMORY_SEARCH_LIMIT: memory_limit},
            ) as span:
                memory_hits = ()
                memory_admission = None
                memory_recoverable = False
                memory_embedding_calls = 0
                memory_generation_calls = 0
                search_mode: str | None = None
                memory_embedding_fallback: str | None = None
                atomic = self._runtime.atomic_memory
                if memory_limit > 0 and atomic is not None:
                    policy = self._runtime.recall_sufficiency_policy
                    try:
                        result = await atomic.for_scope(scope_id).search(
                            request.query,
                            limit=memory_limit,
                            mode="auto",
                            admission=admission,
                            query_embedding=reuse,
                            embedding_timeout_seconds=embedding_budget.remaining,
                            allow_embedding=allow_embedding and embedding_budget.remaining > 0,
                            recovery_admission=None if policy is None else policy.round2_admission,
                            context=_PREPARE_ATOMIC_CONTEXT.get(),
                            _trace=False,
                        )
                    except Exception:
                        if evidence is not None and started_memory is not None and memory_requested:
                            evidence.stage(_MEMORY_SEARCH_STAGE, (perf_counter() - started_memory) * 1000)
                            evidence.search("atomic-memory", None, "failed")
                        raise
                    embedding_budget.spend(result.embedding_wait_seconds)
                    memory_hits = result.hits
                    memory_admission = result.admission
                    memory_recoverable = result.recoverable
                    search_mode = result.mode
                    memory_embedding_fallback = result.embedding_fallback
                    reuse = result.query_embedding
                    memory_embedding_calls = result.embedding_calls
                    memory_generation_calls = result.generation_calls
                if span is not None:
                    attributes: dict[str, TraceAttribute] = {
                        _MEMORY_SEARCH_RESULT_COUNT: len(memory_hits),
                        "powercontext.memory.search.embedding_calls": memory_embedding_calls,
                        "powercontext.memory.search.generation_calls": memory_generation_calls,
                    }
                    if search_mode is not None:
                        attributes[_MEMORY_SEARCH_MODE] = search_mode
                    span.set_attributes(attributes)
            if evidence is not None and started_memory is not None and memory_requested:
                evidence.stage(_MEMORY_SEARCH_STAGE, (perf_counter() - started_memory) * 1000)
                evidence.search(
                    "atomic-memory",
                    search_mode if memory_limit > 0 and atomic is not None else None,
                    "completed" if memory_limit > 0 and atomic is not None else "not_run",
                    memory_embedding_fallback or "none",
                    scope_id=scope_id,
                )

            experience_outcome = await self._recall_experience(
                scope_id, request.query, experience_limit, admission, evidence, experience_requested
            )
        return _ScopeRecallOutcome(
            memory=PreparedMemoryCandidates(
                scope_id=scope_id,
                hits=memory_hits,
            ),
            experience=PreparedExperienceCandidates(scope_id=scope_id, hits=experience_outcome.hits),
            memory_admission=memory_admission,
            experience_admission=(
                None
                if experience_outcome.admission is None
                else replace(experience_outcome.admission, scope_id=scope_id)
            ),
            memory_query_embedding=reuse,
            memory_recoverable=memory_recoverable,
            memory_embedding_fallback=memory_embedding_fallback,
            embedding_calls=memory_embedding_calls,
            generation_calls=memory_generation_calls,
        )

    async def _recall_experience(
        self,
        scope_id: str,
        query: str,
        limit: int,
        admission: AdmissionFloor | None,
        evidence: ReceiptEvidence | None,
        requested: bool,
    ) -> ExperienceSearchOutcome:
        reader = self._runtime._experience_recall
        started = perf_counter() if evidence is not None else None
        with self._runtime._stage(
            "experience.search",
            attributes={
                "powercontext.experience.search.configured": reader is not None,
                "powercontext.experience.search.limit": limit,
            },
        ) as span:
            if reader is None or limit == 0:
                outcome = ExperienceSearchOutcome()
            else:
                try:
                    if admission is None:
                        outcome = await reader(scope_id, query, limit)
                    else:
                        outcome = await reader(scope_id, query, limit, admission=admission)
                except Exception:
                    if evidence is not None and started is not None and requested:
                        evidence.stage("experience.search", (perf_counter() - started) * 1000)
                        evidence.search("experience", None, "failed")
                    raise
            if span is not None:
                span.set_attributes({"powercontext.experience.search.result_count": len(outcome.hits)})
        if evidence is not None and started is not None and requested:
            evidence.stage("experience.search", (perf_counter() - started) * 1000)
            evidence.search(
                "experience",
                outcome.mode if reader is not None and limit > 0 else None,
                "completed" if reader is not None and limit > 0 else "not_run",
            )
        return outcome

    async def _topic_memory_hits(
        self,
        query: str,
        limit: int,
        *,
        admission: AdmissionFloor | None,
        reuse: MemoryQueryEmbedding | None,
        allow_embedding: bool,
        embedding_budget: _EmbeddingBudget,
    ) -> TopicMemoryRecallOutcome:
        evidence = current_receipt_evidence()
        started = perf_counter() if evidence is not None else None
        configured = self._runtime._topic_memory_search is not None
        bounded_query = bounded_topic_memory_query(query)
        with self._runtime._stage(
            "topic_memory.search",
            attributes={
                "powercontext.topic_memory.search.configured": configured,
                "powercontext.topic_memory.search.limit": limit,
            },
        ) as span:
            try:
                result = (
                    TopicMemorySearchResult(mode="fts")
                    if not configured
                    else (
                        await self._runtime.topic_memory.for_scope(self.scope_id).search(
                            SearchTopicMemoryRequest(query=bounded_query, limit=limit),
                            admission=admission,
                            query_embedding=reuse,
                            embedding_timeout_seconds=embedding_budget.remaining,
                            allow_embedding=allow_embedding and embedding_budget.remaining > 0,
                        )
                    )
                )
            except Exception:
                if evidence is not None and started is not None:
                    evidence.stage("topic_memory.search", (perf_counter() - started) * 1000)
                    evidence.search("topic-memory", None, "failed")
                raise
            embedding_budget.spend(result.embedding_wait_seconds)
            if span is not None:
                span.set_attributes({"powercontext.topic_memory.search.result_count": len(result.hits)})
            outcome = TopicMemoryRecallOutcome(
                hits=result.hits,
                admission=result.admission,
                query_embedding=result.query_embedding,
                embedding_calls=result.embedding_calls,
                embedding_fallback=result.embedding_fallback,
                mode=result.mode if configured else None,
            )
        if evidence is not None and started is not None:
            evidence.stage("topic_memory.search", (perf_counter() - started) * 1000)
        return outcome


def _limit_memory_candidates(
    candidates: list[PreparedMemoryCandidates],
    limit: int,
) -> list[PreparedMemoryCandidates]:
    counts = _round_robin_counts(tuple(len(group.hits) for group in candidates), limit)
    return [
        PreparedMemoryCandidates(
            scope_id=group.scope_id,
            hits=group.hits[:count],
        )
        for group, count in zip(candidates, counts, strict=True)
    ]


def _ensure_memory_heads_stable(
    group: PreparedMemoryCandidates,
    versions: dict[tuple[str, str], tuple[ArtifactRef, int]],
) -> None:
    for candidate in group.hits:
        hit = candidate.hit
        key = (group.scope_id, hit.artifact_ref.artifact_id)
        version = (hit.artifact_ref, hit.state_version)
        if key in versions and versions[key] != version:
            raise RuntimeError(f"Atomic Memory changed during recall expansion for scope {group.scope_id}")  # noqa: TRY003
        versions[key] = version


def _limit_expanded_memory_candidates(
    candidates: list[PreparedMemoryCandidates],
    round_zero: list[PreparedMemoryCandidates],
    limit: int,
) -> list[PreparedMemoryCandidates]:
    counts = _prefix_preserving_counts(
        tuple(len(group.hits) for group in candidates),
        tuple(len(group.hits) for group in round_zero),
        limit,
    )
    return [
        PreparedMemoryCandidates(
            scope_id=group.scope_id,
            hits=group.hits[:count],
        )
        for group, count in zip(candidates, counts, strict=True)
    ]


def _limit_experience_candidates(
    candidates: list[PreparedExperienceCandidates],
    limit: int,
) -> list[PreparedExperienceCandidates]:
    counts = _round_robin_counts(tuple(len(group.hits) for group in candidates), limit)
    return [
        PreparedExperienceCandidates(scope_id=group.scope_id, hits=group.hits[:count])
        for group, count in zip(candidates, counts, strict=True)
    ]


def _limit_expanded_experience_candidates(
    candidates: list[PreparedExperienceCandidates],
    round_zero: list[PreparedExperienceCandidates],
    limit: int,
) -> list[PreparedExperienceCandidates]:
    counts = _prefix_preserving_counts(
        tuple(len(group.hits) for group in candidates),
        tuple(len(group.hits) for group in round_zero),
        limit,
    )
    return [
        PreparedExperienceCandidates(scope_id=group.scope_id, hits=group.hits[:count])
        for group, count in zip(candidates, counts, strict=True)
    ]


def _prefix_preserving_counts(
    sizes: tuple[int, ...],
    prefix_sizes: tuple[int, ...],
    limit: int,
) -> tuple[int, ...]:
    prefix_counts = tuple(min(size, prefix) for size, prefix in zip(sizes, prefix_sizes, strict=True))
    remaining = max(0, limit - sum(prefix_counts))
    suffix_counts = _round_robin_counts(
        tuple(size - prefix for size, prefix in zip(sizes, prefix_counts, strict=True)),
        remaining,
    )
    return tuple(prefix + suffix for prefix, suffix in zip(prefix_counts, suffix_counts, strict=True))


def _families_with_retrieved_candidates(
    families: set[str],
    admissions: Sequence[AdmissionCounts],
    *,
    memory_present: bool = False,
) -> int:
    """Count selected families with observed or recoverable candidates."""

    observed = {
        admission.family for admission in admissions if admission.family in families and admission.retrieved > 0
    }
    if memory_present and MEMORY_FAMILY in families:
        observed.add(MEMORY_FAMILY)
    return len(observed)


def _families_with_recoverable_candidates(
    families: set[str],
    admissions: Sequence[AdmissionCounts],
    *,
    memory_recoverable: bool = False,
) -> int:
    """Count selected families where a lower admission floor may recover candidates."""

    observed = {
        admission.family
        for admission in admissions
        if admission.family in families
        and (admission.rejected if admission.rejected is not None else admission.retrieved - admission.admitted) > 0
    }
    if memory_recoverable and MEMORY_FAMILY in families:
        observed.add(MEMORY_FAMILY)
    return len(observed)


def _round_robin_counts(sizes: tuple[int, ...], limit: int) -> tuple[int, ...]:
    counts = [0] * len(sizes)
    remaining = limit
    while remaining > 0:
        advanced = False
        for index, size in enumerate(sizes):
            if counts[index] >= size:
                continue
            counts[index] += 1
            remaining -= 1
            advanced = True
            if remaining == 0:
                break
        if not advanced:
            break
    return tuple(counts)


def _flatten_memory_hits(
    candidates: Sequence[PreparedMemoryCandidates],
) -> tuple[AtomicMemorySearchHit, ...]:
    return tuple(hit for group in candidates for hit in group.hits)


def _flatten_experience_hits(
    candidates: Sequence[PreparedExperienceCandidates],
) -> tuple[ExperienceSearchHit, ...]:
    return tuple(hit for group in candidates for hit in group.hits)


def _flatten_scope_memory(
    hits_by_scope: Mapping[str, Sequence[AtomicMemorySearchHit]],
    scope_ids: Sequence[str],
) -> tuple[AtomicMemorySearchHit, ...]:
    return tuple(hit for scope_id in scope_ids for hit in hits_by_scope.get(scope_id, ()))


def _flatten_scope_experience(
    hits_by_scope: Mapping[str, Sequence[ExperienceSearchHit]],
    scope_ids: Sequence[str],
) -> tuple[ExperienceSearchHit, ...]:
    return tuple(hit for scope_id in scope_ids for hit in hits_by_scope.get(scope_id, ()))


def _memory_identity(scope_id: str, hit: AtomicMemorySearchHit) -> tuple[str, str, int, int]:
    return (scope_id, hit.hit.artifact_ref.artifact_id, hit.hit.artifact_ref.revision, hit.hit.state_version)


def _bootstrap_memory_identity(scope_id: str, hit: AtomicMemorySearchHit) -> tuple[str, str, int]:
    """Identify one exact Atomic Memory content revision."""

    return (scope_id, hit.hit.artifact_ref.artifact_id, hit.hit.artifact_ref.revision)


def _experience_identity(scope_id: str, hit: ExperienceSearchHit) -> tuple[str, str, int]:
    return (scope_id, hit.artifact_ref.artifact_id, hit.artifact_ref.revision)


def _topic_identity(hit: TopicMemorySearchHit) -> tuple[str, int]:
    return (hit.artifact_ref.artifact_id, hit.artifact_ref.revision)


_HitT = TypeVar("_HitT")


def _latest_round_order(
    hits: Sequence[_HitT],
    ranks: Mapping[Any, int],
    identity: Callable[[_HitT], Any],
) -> tuple[_HitT, ...]:
    """Order hits by the latest round's fused ranking, keeping the accumulated order for
    identities the latest round did not re-admit. A fused hit that only entered the window
    under a lowered floor must rank inside the delivery cap, not behind the round-zero prefix."""
    if not ranks:
        return tuple(hits)
    return tuple(sorted(hits, key=lambda hit: ranks.get(identity(hit), len(ranks))))


def _admission_keyword(admission: AdmissionFloor | None) -> dict[str, Any]:
    """Forward ``admission`` only when set, keeping today's exact downstream calls otherwise."""

    return {} if admission is None else {"admission": admission}


class ContextApplication:
    """Select the scoped context-preparation application service."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedContextApplication:
        return ScopedContextApplication(self._runtime, scope_id)


_BOOTSTRAP_TAG = "bootstrap-context"
_BOOTSTRAP_MEMORY_LIMIT = 6
_BOOTSTRAP_CONTEXT_REFERENCE_LIMIT = 8
_BOOTSTRAP_TAG_SCAN_LIMIT = 32
_BOOTSTRAP_RECEIPT_RETENTION = timedelta(days=30)
_SECRET_MEMORY_KIND_MARKERS = (
    "secret",
    "credential",
    "password",
    "token",
    "apikey",
    "accesskey",
    "privatekey",
)


class ScopedBootstrapApplication:
    """Prepare and account for one Scope's lifecycle bootstrap context."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def prepare(
        self,
        request: BootstrapContextRequest,
        /,
        *,
        authorize_scopes: Callable[[tuple[str, ...]], Awaitable[None]] | None = None,
    ) -> BootstrapContext:
        repository = self._repository()
        async with self._runtime._scope_operation(self.scope_id) as scope:
            scope_ids = (self.scope_id, *scope.context_references[:_BOOTSTRAP_CONTEXT_REFERENCE_LIMIT])
            event_key = _bootstrap_event_key(self.scope_id, request)
            await self._delete_expired_receipts(request, event_key, repository)
            if not request.enabled:
                return await self._disabled_result(request, event_key, repository, authorize_scopes)
            existing = await self._existing_event_result(
                request,
                event_key,
                scope_ids,
                repository,
                authorize_scopes,
            )
            if existing is not None:
                return existing
            if authorize_scopes is not None:
                await authorize_scopes(scope_ids)
            candidates = await self._select_candidates(request, scope_ids)
            build = build_bootstrap_context(candidates, request.max_bytes)
            if build.content is None:
                return await self._empty_result(
                    request,
                    event_key,
                    build,
                    scope_ids,
                    repository,
                    authorize_scopes,
                )

            stored, created = await repository.create(
                self._stored_receipt(
                    request,
                    event_key=event_key,
                    state="pending",
                    content=build.content,
                    items=build.items,
                    truncated=build.truncated,
                )
            )
            if not created:
                self._require_matching_request(stored, request)
                await self._authorize_stored_result(stored, scope_ids, authorize_scopes)
                return await self._existing_result(stored)
            return _ready_bootstrap(stored, build.content)

    async def _delete_expired_receipts(
        self,
        request: BootstrapContextRequest,
        event_key: str | None,
        repository: BootstrapReceiptRepository,
    ) -> None:
        if request.enabled or event_key is not None:
            cutoff = self._runtime._clock().astimezone(UTC) - _BOOTSTRAP_RECEIPT_RETENTION
            await repository.delete_before(cutoff)

    async def _existing_event_result(
        self,
        request: BootstrapContextRequest,
        event_key: str | None,
        scope_ids: tuple[str, ...],
        repository: BootstrapReceiptRepository,
        authorize_scopes: Callable[[tuple[str, ...]], Awaitable[None]] | None,
    ) -> BootstrapContext | None:
        if event_key is None:
            return None
        existing = await repository.by_event(event_key)
        if existing is None:
            return None
        self._require_matching_request(existing, request)
        await self._authorize_stored_result(existing, scope_ids, authorize_scopes)
        return await self._existing_result(existing)

    async def _authorize_stored_result(
        self,
        stored: StoredBootstrapReceipt,
        scope_ids: tuple[str, ...],
        authorize_scopes: Callable[[tuple[str, ...]], Awaitable[None]] | None,
    ) -> None:
        if authorize_scopes is None:
            return
        stored_scope_ids = tuple(dict.fromkeys((*scope_ids, *(item.scope_id for item in stored.items))))
        await authorize_scopes(stored_scope_ids)

    async def _empty_result(
        self,
        request: BootstrapContextRequest,
        event_key: str | None,
        build: BootstrapBuild,
        scope_ids: tuple[str, ...],
        repository: BootstrapReceiptRepository,
        authorize_scopes: Callable[[tuple[str, ...]], Awaitable[None]] | None,
    ) -> BootstrapContext:
        candidate = self._stored_receipt(
            request,
            event_key=event_key,
            state="skipped",
            reason="no_eligible_context",
            truncated=build.truncated,
        )
        if event_key is None:
            stored = candidate
        else:
            stored, created = await repository.create(candidate)
            if not created:
                self._require_matching_request(stored, request)
                await self._authorize_stored_result(stored, scope_ids, authorize_scopes)
                return await self._existing_result(stored)
        return BootstrapContext(
            status="empty",
            reason="no_eligible_context",
            content=None,
            content_bytes=0,
            truncated=build.truncated,
            receipt=_delivery_receipt(stored),
        )

    async def _disabled_result(
        self,
        request: BootstrapContextRequest,
        event_key: str | None,
        repository: BootstrapReceiptRepository,
        authorize_scopes: Callable[[tuple[str, ...]], Awaitable[None]] | None,
    ) -> BootstrapContext:
        if authorize_scopes is not None:
            await authorize_scopes((self.scope_id,))
        stored = await repository.by_event(event_key) if event_key is not None else None
        if stored is None:
            candidate = self._stored_receipt(request, event_key=event_key, state="skipped", reason="disabled")
            if event_key is None:
                stored = candidate
            else:
                stored, _ = await repository.create(candidate)
        if stored.state == "pending":
            stored, _ = await repository.record_delivery(self.scope_id, stored.receipt_id, "skipped")
            if stored is None:
                raise InvalidRuntimeRequestError("bootstrap-receipt")
        return self._terminal_result(stored, reason="disabled" if stored.state == "skipped" else "already_delivered")

    async def record_delivery(self, request: RecordBootstrapDeliveryRequest, /) -> BootstrapDeliveryReceipt:
        async with self._runtime._scope_operation(self.scope_id):
            stored, claimed = await self._repository().record_delivery(
                self.scope_id, request.receipt_id, request.outcome
            )
        if stored is None:
            raise InvalidRuntimeRequestError("bootstrap-receipt")
        if request.outcome == "injected" and not claimed:
            raise InvalidRuntimeRequestError("bootstrap-delivery-already-claimed")
        return _delivery_receipt(stored)

    async def _select_candidates(
        self,
        request: BootstrapContextRequest,
        scope_ids: tuple[str, ...],
    ) -> tuple[BootstrapCandidate, ...]:
        records = self._runtime._records()
        candidates: list[BootstrapCandidate] = []
        if request.handoff is not None:
            handoff = await records.get_artifact_revision(
                self.scope_id,
                "handoff",
                request.handoff.artifact_id,
                request.handoff.revision,
            )
            candidates.append(
                BootstrapCandidate(
                    item=BootstrapContextItem(
                        kind="handoff",
                        scope_id=self.scope_id,
                        artifact=request.handoff,
                        content_digest=handoff.content_digest,
                    ),
                    content=json.dumps(handoff.content, ensure_ascii=False, indent=2, sort_keys=True),
                )
            )

        remaining = _BOOTSTRAP_MEMORY_LIMIT
        for scope_id in scope_ids:
            if remaining == 0:
                break
            page = await records.query_tags(
                scope_id,
                TagQuery(
                    tags=(_BOOTSTRAP_TAG,),
                    families=("atomic-memory",),
                    target_types=("artifact",),
                    include_inactive=False,
                    limit=_BOOTSTRAP_TAG_SCAN_LIMIT,
                ),
                caller="bootstrap-context",
            )
            for tagged in page.items:
                reference = tagged.reference
                record = await records.get_artifact_revision(
                    scope_id,
                    "atomic-memory",
                    reference.artifact_id,
                    reference.revision,
                )
                memory = AtomicMemoryContent.model_validate(record.content)
                if _secret_memory_kind(memory.kind):
                    continue
                candidates.append(
                    BootstrapCandidate(
                        item=BootstrapContextItem(
                            kind="atomic-memory",
                            scope_id=scope_id,
                            artifact=reference,
                            content_digest=record.content_digest,
                        ),
                        content=f"Kind: {json.dumps(memory.kind, ensure_ascii=True)}\nText:\n{memory.text}",
                    )
                )
                remaining -= 1
                if remaining == 0:
                    break
        return tuple(candidates)

    async def _existing_result(self, stored: StoredBootstrapReceipt) -> BootstrapContext:
        if stored.scope_id != self.scope_id or stored.state != "pending":
            return self._terminal_result(stored, reason="already_delivered")
        try:
            candidates = tuple([await self._candidate_from_item(item) for item in stored.items])
            build = build_bootstrap_context(candidates, stored.max_bytes)
            content = _require_reconstructed_bootstrap(stored, build.content, build)
        except Exception as error:
            log_safely(
                logger,
                logging.ERROR,
                "Bootstrap receipt reconstruction failed",
                exc_info=error,
                extra={"event": "context.bootstrap.reconstruct_failed", "outcome": "failure", "unit": "context"},
            )
            failed, _ = await self._repository().record_delivery(self.scope_id, stored.receipt_id, "failed")
            terminal = failed or stored
            if terminal.state == "pending":
                raise InvalidRuntimeRequestError("bootstrap-receipt") from error
            reason: BootstrapSkipReason = "preparation_failed" if terminal.state == "failed" else "already_delivered"
            return self._terminal_result(terminal, reason=reason)
        return _ready_bootstrap(stored, content)

    async def _candidate_from_item(self, item: BootstrapContextItem) -> BootstrapCandidate:
        records = self._runtime._records()
        if item.kind == "handoff":
            record = await records.get_artifact_revision(
                item.scope_id,
                item.artifact.family,
                item.artifact.artifact_id,
                item.artifact.revision,
            )
            if record.content_digest != item.content_digest:
                raise ValueError("bootstrap Handoff digest changed")  # noqa: TRY003
            content = json.dumps(record.content, ensure_ascii=False, indent=2, sort_keys=True)
        else:
            record = await records.get_artifact_revision(
                item.scope_id,
                "atomic-memory",
                item.artifact.artifact_id,
                item.artifact.revision,
            )
            if record.content_digest != item.content_digest:
                raise ValueError("bootstrap Atomic Memory digest changed")  # noqa: TRY003
            memory = AtomicMemoryContent.model_validate(record.content)
            content = f"Kind: {json.dumps(memory.kind, ensure_ascii=True)}\nText:\n{memory.text}"
        return BootstrapCandidate(item=item.model_copy(update={"truncated": False}), content=content)

    def _stored_receipt(
        self,
        request: BootstrapContextRequest,
        *,
        event_key: str | None,
        state: BootstrapReceiptState,
        reason: BootstrapSkipReason | None = None,
        content: str | None = None,
        items: tuple[BootstrapContextItem, ...] = (),
        truncated: bool = False,
    ) -> StoredBootstrapReceipt:
        encoded = b"" if content is None else content.encode("utf-8")
        return StoredBootstrapReceipt(
            receipt_id=f"bcr_{uuid4().hex}",
            scope_id=self.scope_id,
            event_key=event_key,
            request_digest=_bootstrap_request_digest(request),
            integration=request.integration,
            lifecycle=request.lifecycle,
            profile=request.profile,
            state=state,
            reason=reason,
            max_bytes=request.max_bytes,
            package_digest=None if content is None else _package_digest(content),
            content_bytes=len(encoded),
            truncated=truncated,
            items=items,
            created_at=self._runtime._clock(),
        )

    @staticmethod
    def _require_matching_request(stored: StoredBootstrapReceipt, request: BootstrapContextRequest) -> None:
        if stored.request_digest != _bootstrap_request_digest(request):
            raise InvalidRuntimeRequestError("bootstrap-event-request-mismatch")

    def _terminal_result(self, stored: StoredBootstrapReceipt, *, reason: BootstrapSkipReason) -> BootstrapContext:
        return BootstrapContext(
            status="skipped",
            reason=reason,
            profile=stored.profile,
            content=None,
            content_bytes=0,
            truncated=False,
            receipt=_delivery_receipt(stored),
        )

    def _repository(self) -> BootstrapReceiptRepository:
        if self._runtime._bootstrap_receipts is None:
            raise _RuntimeStateError("bootstrap-receipts")
        return self._runtime._bootstrap_receipts


class BootstrapApplication:
    """Select scoped bootstrap operations."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedBootstrapApplication:
        return ScopedBootstrapApplication(self._runtime, scope_id)


def _bootstrap_event_key(scope_id: str, request: BootstrapContextRequest) -> str | None:
    if request.event_id is None:
        return None
    value = "\0".join((scope_id, request.integration, request.lifecycle, request.event_id))
    return sha256(value.encode()).hexdigest()


def _secret_memory_kind(kind: str) -> bool:
    compact = "".join(character for character in kind.casefold() if character.isalnum())
    return any(marker in compact for marker in _SECRET_MEMORY_KIND_MARKERS)


def _bootstrap_request_digest(request: BootstrapContextRequest) -> str:
    payload = {
        "handoff": None if request.handoff is None else request.handoff.model_dump(mode="json", by_alias=True),
        "integration": request.integration,
        "lifecycle": request.lifecycle,
        "max_bytes": request.max_bytes,
        "profile": request.profile,
    }
    encoded = json.dumps(payload, ensure_ascii=True, separators=(",", ":"), sort_keys=True).encode()
    return "sha256:" + sha256(encoded).hexdigest()


def _package_digest(content: str) -> str:
    return "sha256:" + sha256(content.encode("utf-8")).hexdigest()


def _require_reconstructed_bootstrap(
    stored: StoredBootstrapReceipt,
    content: str | None,
    build: BootstrapBuild,
) -> str:
    if (
        content is None
        or build.items != stored.items
        or len(content.encode("utf-8")) != stored.content_bytes
        or _package_digest(content) != stored.package_digest
    ):
        raise ValueError("bootstrap receipt cannot be reconstructed")  # noqa: TRY003
    return content


def _delivery_receipt(stored: StoredBootstrapReceipt) -> BootstrapDeliveryReceipt:
    return BootstrapDeliveryReceipt(receipt_id=stored.receipt_id, state=stored.state)


def _ready_bootstrap(stored: StoredBootstrapReceipt, content: str) -> BootstrapContext:
    return BootstrapContext(
        status="ready",
        profile=stored.profile,
        content=content,
        content_bytes=stored.content_bytes,
        package_digest=stored.package_digest,
        items=stored.items,
        truncated=stored.truncated,
        receipt=_delivery_receipt(stored),
    )


class ScopedExperienceApplication:
    """Propose and exactly read Experience Artifacts in one scope."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def propose(
        self,
        request: ProposeExperienceRequest,
        /,
        *,
        on_commit: CandidateCommitHook | None = None,
    ) -> ExperienceCandidate:
        async with self._runtime._scoped_operation(self.scope_id), self._runtime._locked(self.scope_id):
            service = self._runtime._review(self.scope_id)
            return await service.propose_experience(
                request.proposal,
                sources=request.sources,
                artifacts=request.artifacts,
                target=request.target,
                reason=request.reason,
                **({"on_commit": on_commit} if on_commit is not None else {}),
            )

    async def generate(
        self,
        request: GenerateExperienceRequest,
        /,
        *,
        on_commit: CandidateCommitHook | None = None,
    ) -> GeneratedCandidateResult:
        async with (
            self._runtime._scoped_operation(
                self.scope_id,
                generation_purpose=ModelUsagePurpose.EXPERIENCE_GENERATION,
            ),
            self._runtime._locked(self.scope_id),
        ):
            return await self._runtime._generation(self.scope_id).experience(
                sources=request.sources,
                artifacts=request.artifacts,
                target=request.target,
                reason=request.reason,
                **({"on_commit": on_commit} if on_commit is not None else {}),
            )

    async def get(self, request: GetExperienceRequest, /) -> Experience:
        async with self._runtime._scoped_operation(self.scope_id):
            return await self._runtime._review(self.scope_id).get_experience(request.artifact)

    async def incubate(
        self,
        /,
        *,
        limit: int | None = None,
        on_commit: Callable[..., Awaitable[None]] | None = None,
    ) -> ExperienceIncubationResult:
        """Process one independent Task Outcome Source window into Review."""

        from powercontext.builtin.runtime.relational import RelationalContexts

        incubator = self._runtime._experience_incubator
        if incubator is None:
            raise _RuntimeStateError("experience-incubation")
        window_limit = EXPERIENCE_INCUBATION_WINDOW_LIMIT if limit is None else limit
        if window_limit < 1:
            raise _RuntimeConfigurationError("limit")
        scope_lock: AbstractAsyncContextManager[None] = self._runtime._locked(self.scope_id)
        # The relational incubator can acquire the Scope lock at commit.
        # Other callbacks rely on the Runtime to serialize the whole invocation.
        if isinstance(incubator, MethodType) and incubator.__func__ is RelationalContexts.incubate_experience:
            incubator = partial(incubator, commit_lock=scope_lock)
            scope_lock = nullcontext()
        async with (
            self._runtime._scoped_operation(
                self.scope_id,
                generation_purpose=ModelUsagePurpose.EXPERIENCE_GENERATION,
            ),
            scope_lock,
        ):
            with self._runtime._stage("experience.incubation", attributes={}) as span:
                result = await incubator(
                    self.scope_id, window_limit, **({"on_commit": on_commit} if on_commit is not None else {})
                )
                if span is not None:
                    span.set_attributes({
                        "powercontext.experience.incubation.source_count": result.source_count,
                        "powercontext.experience.incubation.candidate_count": result.candidate_count,
                    })
                    span.set_outcome("success" if result.processed else "noop")
                return result


class ExperienceApplication:
    """Select a scoped Experience application service."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedExperienceApplication:
        return ScopedExperienceApplication(self._runtime, scope_id)


class ScopedArtifactApplication:
    """Search a registered Artifact Family within one existing Scope."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def search(
        self,
        family: str,
        payload: Mapping[str, Any],
        /,
        *,
        execution_context: ArtifactSearchExecutionContext | None = None,
    ) -> ArtifactSearchOutcome:
        service = self._runtime._artifact_search
        if service is None:
            raise ArtifactSearchUnsupported(family, field="family")
        async with self._runtime._scoped_operation(self.scope_id, embedding_purpose=service.embedding_purpose(family)):
            return await service.search(self.scope_id, family, payload, execution_context=execution_context)


class ArtifactApplication:
    """Select the scoped public Artifact search application."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedArtifactApplication:
        return ScopedArtifactApplication(self._runtime, scope_id)


class ScopedSkillApplication:
    """Propose and exactly read managed Skill Artifacts in one scope."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def propose(
        self,
        request: ProposeSkillRequest,
        /,
        *,
        on_commit: CandidateCommitHook | None = None,
    ) -> SkillCandidate:
        async with self._runtime._scoped_operation(self.scope_id), self._runtime._locked(self.scope_id):
            service = self._runtime._review(self.scope_id)
            return await service.propose_skill(
                request.proposal,
                sources=request.sources,
                artifacts=request.artifacts,
                target=request.target,
                reason=request.reason,
                **({"on_commit": on_commit} if on_commit is not None else {}),
            )

    async def generate(
        self,
        request: GenerateSkillRequest,
        /,
        *,
        on_commit: CandidateCommitHook | None = None,
    ) -> GeneratedCandidateResult:
        async with (
            self._runtime._scoped_operation(
                self.scope_id,
                generation_purpose=ModelUsagePurpose.SKILL_GENERATION,
            ),
            self._runtime._locked(self.scope_id),
        ):
            return await self._runtime._generation(self.scope_id).skill(
                origin=request.origin,
                sources=request.sources,
                artifacts=request.artifacts,
                target=request.target,
                reason=request.reason,
                **({"on_commit": on_commit} if on_commit is not None else {}),
            )

    async def get(self, request: GetSkillRequest, /) -> Skill:
        async with self._runtime._scoped_operation(self.scope_id):
            return await self._runtime._review(self.scope_id).get_skill(request.artifact)

    async def search(self, query: str, limit: int, /) -> tuple[SkillSearchHit, ...]:
        recall = self._runtime._skill_recall
        if recall is None:
            return ()
        async with self._runtime._scoped_operation(self.scope_id):
            return await recall(self.scope_id, query, limit)

    async def search_library(
        self, query: str, limit: int, /, *, include_deprecated: bool = False
    ) -> tuple[tuple[Skill, ArtifactGovernance], ...]:
        """Preserve the Skill Library's active search and bounded deprecated append rule."""

        lister = self._runtime._skill_lister
        if isinstance(lister, SkillArtifactSearcher):
            async with self._runtime._scoped_operation(self.scope_id):
                return await lister(self.scope_id, include_deprecated, limit, query=query)
        return await search_skill_library(self, query, limit, include_deprecated=include_deprecated)

    async def list(
        self,
        *,
        include_deprecated: bool = False,
        limit: int = 100,
    ) -> tuple[tuple[Skill, ArtifactGovernance], ...]:
        lister = self._runtime._skill_lister
        if lister is None:
            return ()
        async with self._runtime._scoped_operation(self.scope_id):
            return await lister(self.scope_id, include_deprecated, limit)

    async def origins(self, skills: tuple[Skill, ...], /) -> tuple[SkillOrigin, ...]:
        """Resolve display provenance for current Skill revisions in one bounded read."""

        reader = self._runtime._skill_origin_reader
        if reader is None:
            raise _RuntimeStateError("skill-provenance")
        async with self._runtime._scoped_operation(self.scope_id):
            return await reader(self.scope_id, skills)

    async def package(self, artifact: ArtifactRef, /) -> SkillPackageSnapshot:
        resolver = self._runtime._skill_package_resolver
        if resolver is None:
            raise _RuntimeStateError("skill-package")
        async with self._runtime._scoped_operation(self.scope_id):
            return await resolver(self.scope_id, artifact)

    async def package_snapshot(self, package: SkillPackageRef, /) -> SkillPackageSnapshot:
        resolver = self._runtime._package_snapshot_resolver
        if resolver is None:
            raise _RuntimeStateError("skill-package")
        async with self._runtime._scoped_operation(self.scope_id):
            return await resolver(self.scope_id, package)

    async def upload_package(
        self,
        archive_bytes: bytes,
        reason: str | None,
        target: ArtifactRef | None,
        /,
        *,
        on_commit: CandidateCommitHook | None = None,
    ) -> SkillCandidate:
        uploader = self._runtime._skill_package_uploader
        if uploader is None:
            raise _RuntimeStateError("skill-package")
        async with self._runtime._scoped_operation(self.scope_id), self._runtime._locked(self.scope_id):
            return await uploader(
                self.scope_id,
                archive_bytes,
                reason,
                target,
                **({"on_commit": on_commit} if on_commit is not None else {}),
            )

    async def record_usage(self, observation: SkillUsageCapture, /) -> SourceReceipt:
        recorder = self._runtime._skill_usage_recorder
        if recorder is None:
            raise _RuntimeStateError("skill-usage")
        async with self._runtime._scoped_operation(self.scope_id), self._runtime._locked(self.scope_id):
            return await recorder(self.scope_id, observation)

    async def governance(self, artifact_id: str, /) -> ArtifactGovernance:
        reader = self._runtime._skill_governance_reader
        if reader is None:
            raise _RuntimeStateError("skill-governance")
        async with self._runtime._scoped_operation(self.scope_id):
            return await reader(self.scope_id, artifact_id)

    async def update_lifecycle(
        self,
        artifact_id: str,
        expected_generation: int,
        lifecycle_state: ArtifactLifecycleState,
        replacement_artifact_id: str | None,
        /,
    ) -> ArtifactGovernance:
        updater = self._runtime._skill_governance_updater
        if updater is None:
            raise _RuntimeStateError("skill-governance")
        async with self._runtime._scoped_operation(self.scope_id), self._runtime._locked(self.scope_id):
            return await updater(
                self.scope_id,
                artifact_id,
                expected_generation,
                lifecycle_state,
                replacement_artifact_id,
            )

    async def inspect_publication(
        self,
        artifact: ArtifactRef,
        target: AgentSkillTarget,
        /,
    ) -> ManagedSkillPublicationStatus:
        async with self._runtime._scoped_operation(self.scope_id):
            service = self._runtime._skill_publications(self.scope_id, target, artifact)
            return await service.inspect(artifact, target)

    async def publish(
        self,
        artifact: ArtifactRef,
        target: AgentSkillTarget,
        /,
        *,
        allow_deprecated: bool = False,
    ) -> ManagedSkillPublicationStatus:
        async with self._runtime._scoped_operation(self.scope_id):
            service = self._runtime._skill_publications(self.scope_id, target, artifact)
            return await service.publish(artifact, target, allow_deprecated=allow_deprecated)

    async def unpublish(
        self,
        artifact: ArtifactRef,
        target: AgentSkillTarget,
        /,
    ) -> ManagedSkillPublicationStatus:
        async with self._runtime._scoped_operation(self.scope_id):
            service = self._runtime._skill_publications(self.scope_id, target, artifact)
            return await service.unpublish(artifact, target)


class SkillApplication:
    """Select a scoped managed Skill application service."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedSkillApplication:
        return ScopedSkillApplication(self._runtime, scope_id)


class RemoteSkillApplication:
    """Expose remote target lifecycle and Receiver reconciliation through the Runtime boundary."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def _service(self) -> RemoteSkillDistributionService:
        service = self._runtime._remote_skill_distribution
        if service is None:
            raise _RuntimeStateError("remote-skill-distribution")
        return service

    async def list_targets(
        self,
        scope_id: str,
        /,
        *,
        target_id: str | None = None,
        limit: int = 100,
    ) -> tuple[RemoteSkillTargetStatus, ...]:
        async with self._runtime._scoped_operation(scope_id):
            return await self._service().list_targets(
                scope_id,
                target_id=target_id,
                limit=limit,
            )

    async def create_target(
        self,
        scope_id: str,
        agent_kind: AgentKind,
        display_name: str,
        /,
    ) -> RemoteTargetEnrollment:
        async with self._runtime._scoped_operation(scope_id):
            return await self._service().create_target(scope_id, agent_kind, display_name)

    async def enroll(
        self,
        enrollment_code: str,
        installation_id: str,
        receiver_version: str,
        environment_fingerprint: str | None,
        machine_hostname: str | None = None,
        workspace_name: str | None = None,
        /,
    ) -> RemoteTargetCredential:
        async with self._runtime._operation():
            return await self._service().enroll(
                enrollment_code,
                installation_id,
                receiver_version,
                environment_fingerprint,
                machine_hostname,
                workspace_name,
            )

    async def rename_target(
        self,
        scope_id: str,
        target_id: str,
        expected_generation: int,
        display_name: str,
        /,
    ) -> RemoteAgentSkillTarget:
        async with self._runtime._scoped_operation(scope_id):
            return await self._service().rename_target(scope_id, target_id, expected_generation, display_name)

    async def revoke_target(
        self,
        scope_id: str,
        target_id: str,
        expected_generation: int,
        /,
    ) -> RemoteAgentSkillTarget:
        async with self._runtime._scoped_operation(scope_id):
            return await self._service().revoke_target(scope_id, target_id, expected_generation)

    async def publish(
        self,
        scope_id: str,
        target_id: str,
        artifact: ArtifactRef,
        expected_generation: int | None,
        /,
        *,
        allow_deprecated: bool = False,
    ) -> SkillPublication:
        async with self._runtime._scoped_operation(scope_id):
            return await self._service().publish(
                scope_id,
                target_id,
                artifact,
                expected_generation,
                allow_deprecated=allow_deprecated,
            )

    async def unpublish(
        self,
        scope_id: str,
        target_id: str,
        artifact_id: str,
        expected_generation: int,
        /,
    ) -> SkillPublication:
        async with self._runtime._scoped_operation(scope_id):
            return await self._service().unpublish(scope_id, target_id, artifact_id, expected_generation)

    async def reconcile(
        self,
        credential: str,
        observations: tuple[RemoteSkillObservation, ...],
        receiver_version: str,
        environment_fingerprint: str | None,
        /,
    ) -> RemoteSkillReconcileResult:
        async with self._runtime._operation():
            return await self._service().reconcile(
                credential,
                observations,
                receiver_version,
                environment_fingerprint,
            )

    async def download(
        self,
        credential: str,
        generation: int,
        artifact: ArtifactRef,
        package: SkillPackageRef,
        /,
    ) -> SkillPackageSnapshot:
        async with self._runtime._operation():
            return await self._service().download(credential, generation, artifact, package)

    async def receipt(
        self,
        credential: str,
        receipt: RemoteSkillReceipt,
        /,
    ) -> RemoteSkillReceiptResult:
        async with self._runtime._operation():
            return await self._service().receipt(credential, receipt)


class ScopedHandoffApplication:
    """Operate temporary and committed Handoffs for one scope."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def activate(self, request: ActivateHandoff, /) -> HandoffActivation:
        async with self._runtime._context(
            self.scope_id,
            generation_purpose=ModelUsagePurpose.HANDOFF_GENERATION,
        ) as context:
            return await context.triggers.activate_handoff(request)

    async def prepare(self, action: PrepareHandoff, /) -> HandoffDraft:
        async with self._runtime._context(
            self.scope_id,
            generation_purpose=ModelUsagePurpose.HANDOFF_GENERATION,
        ) as context:
            return await context.artifacts.handoff.prepare(action)

    async def finalize(self, draft: HandoffDraft, /) -> PreparedHandoff:
        async with self._runtime._context(self.scope_id) as context:
            return await context.artifacts.handoff.finalize(draft)

    async def hint(self, request: PrepareHandoffHint, /) -> PreparedContext:
        """Prepare optional historical orientation for direct host delivery."""

        async with self._runtime._context(self.scope_id) as context:
            content = await context.artifacts.handoff.hint(request)
        return PreparedContext(
            status="empty" if content is None else "ready",
            content=content,
            content_bytes=0 if content is None else len(content.encode("utf-8")),
        )

    async def commit(self, prepared: PreparedHandoff, /, *, on_commit=None) -> Handoff:
        async with self._runtime._context(self.scope_id) as context, self._runtime._locked(self.scope_id):
            if on_commit is not None:
                committer = self._runtime._handoff_committer
                if committer is None:
                    raise _RuntimeStateError("handoff-commit")
                return await committer(self.scope_id, prepared, on_commit=on_commit)
            return await context.artifacts.handoff.commit(prepared)

    async def continue_from(
        self,
        handoff: PreparedHandoff | ArtifactRef,
        /,
        *,
        evidence_authorizer: HandoffEvidenceAuthorizer | None = None,
    ) -> HandoffResolution:
        async with self._runtime._context(self.scope_id) as context:
            return await context.artifacts.handoff.continue_from(
                handoff,
                evidence_authorizer=evidence_authorizer,
            )

    async def continue_latest(
        self,
        *,
        evidence_authorizer: HandoffEvidenceAuthorizer | None = None,
    ) -> HandoffResolution:
        async with self._runtime._context(self.scope_id) as context:
            return await context.artifacts.handoff.continue_latest(evidence_authorizer=evidence_authorizer)

    async def latest(self) -> Handoff | None:
        async with self._runtime._context(self.scope_id) as context:
            return await context.artifacts.handoff.latest()

    async def revision(self, reference: ArtifactRef, /) -> Handoff:
        async with self._runtime._context(self.scope_id) as context:
            return await context.artifacts.handoff.revision(reference)

    async def revisions(self) -> tuple[Handoff, ...]:
        async with self._runtime._context(self.scope_id) as context:
            return await context.artifacts.handoff.revisions()

    async def validate_evidence(self, citations: tuple[HandoffCitation, ...], /) -> None:
        """Validate exact same-scope evidence for a higher-level Work record."""

        async with self._runtime._context(self.scope_id) as context:
            await context.artifacts.handoff.validate_evidence(citations)

    @staticmethod
    def render(
        handoff: HandoffDraft | PreparedHandoff | Handoff,
        /,
        *,
        audience: HandoffAudience,
    ) -> str:
        return HandoffService.render(handoff, audience=audience)


class HandoffApplication:
    """Select the application service for one Handoff family scope."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedHandoffApplication:
        return ScopedHandoffApplication(self._runtime, scope_id)


class ScopedWorkApplication:
    """Orchestrate the minimal Delegation, Handoff, Continue, and Outcome loop."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def create_contract(self, request: CreateWorkContract, /) -> WorkSourceReceipt:
        await self._validate(_contract_evidence(request.contract))
        return await self._capture(WORK_CONTRACT_SOURCE_KIND, request.source_id, request.contract)

    async def continuity(self, selected_handoff: ArtifactRef | None = None) -> WorkContinuity:
        """Read a bounded timeline and loop coverage from the scoped Source journal."""

        async with self._runtime._context(self.scope_id) as context:
            entries = await context.sources.journal.entries()
            if selected_handoff is None:
                latest = await context.artifacts.handoff.latest()
                selected_handoff = None if latest is None else latest.as_ref()
        return project_work_continuity(self.scope_id, entries, selected_handoff=selected_handoff)

    async def record_outcome(self, request: RecordTaskOutcome, /) -> WorkSourceReceipt:
        await self._validate(_outcome_evidence(request.outcome))
        if request.outcome.handoff_receipt_ref is not None:
            await self._validate_outcome_receipt(request.outcome.handoff_receipt_ref)
        return await self._capture(TASK_OUTCOME_SOURCE_KIND, request.source_id, request.outcome)

    async def handoff_current(self, request: HandoffCurrentWork, /) -> PreparedWorkHandoff:
        await self._validate(_claims_evidence((*request.handoff.state, request.handoff.next_action)))
        boundary = await self._capture(HANDOFF_BOUNDARY_SOURCE_KIND, request.source_id, request.handoff)
        boundary_citation = HandoffSourceCitation(source_ref=boundary.source_ref)
        draft = HandoffDraft(
            objective=request.handoff.objective,
            state=tuple(_handoff_statement(claim, boundary_citation) for claim in request.handoff.state),
            disposition=request.handoff.disposition,
            next_action=(
                None
                if request.handoff.next_action is None
                else _handoff_statement(request.handoff.next_action, boundary_citation)
            ),
            omissions=tuple(HandoffOmission(text=text) for text in request.handoff.omissions),
        )
        prepared = await self._runtime.handoff.for_scope(self.scope_id).finalize(draft)
        return PreparedWorkHandoff(boundary=boundary, handoff=prepared)

    async def acknowledge(self, request: AcknowledgeHandoff, /) -> HandoffAcknowledgement:
        handoff = self._runtime.handoff.for_scope(self.scope_id)
        if request.selection == "prepared":
            if request.prepared is None:
                raise InvalidRuntimeRequestError("handoff-selection")
            resolution = await handoff.continue_from(request.prepared)
        else:
            if request.revision is None:
                raise InvalidRuntimeRequestError("handoff-selection")
            resolution = await handoff.continue_from(request.revision)
        if resolution.status == "empty":
            raise InvalidRuntimeRequestError("handoff-empty")

        unavailable = _unavailable_evidence(resolution)
        if request.status == "accepted" and unavailable:
            raise InvalidRuntimeRequestError("handoff-evidence-unavailable")
        receipt_record = HandoffReceipt.model_validate({
            "receiver": request.receiver,
            "status": request.status,
            "selection": request.selection,
            "selected_revision": resolution.selected_revision,
            "prepared_digest": None if request.prepared is None else content_digest(request.prepared),
            "receiver_checks": request.receiver_checks,
            "evidence_status": "unavailable" if unavailable else "available",
            "unavailable_evidence": tuple(citation.model_dump() for citation in unavailable),
            "message": request.message,
        })
        receipt = await self._capture(HANDOFF_RECEIPT_SOURCE_KIND, request.source_id, receipt_record)
        return HandoffAcknowledgement(resolution=resolution, receipt=receipt)

    async def _validate_outcome_receipt(self, receipt_ref: SourceRef) -> None:
        async with self._runtime._context(self.scope_id) as context:
            entry = await context.sources.journal.entry(receipt_ref)
        if entry is None or not isinstance(entry.source, ContentSource):
            raise InvalidRuntimeRequestError("task-outcome-handoff-receipt")
        if entry.source.metadata.get("kind") != HANDOFF_RECEIPT_SOURCE_KIND:
            raise InvalidRuntimeRequestError("task-outcome-handoff-receipt")
        try:
            receipt = HandoffReceipt.model_validate_json(entry.source.content)
        except ValidationError as error:
            raise InvalidRuntimeRequestError("task-outcome-handoff-receipt") from error
        if receipt.status != "accepted" or receipt.selection != "exact" or receipt.selected_revision is None:
            raise InvalidRuntimeRequestError("task-outcome-handoff-receipt")

    async def _validate(self, citations: tuple[HandoffCitation, ...]) -> None:
        if citations:
            await self._runtime.handoff.for_scope(self.scope_id).validate_evidence(citations)

    async def _capture(self, kind: WorkSourceKind, source_id: str, value: BaseModel) -> WorkSourceReceipt:
        receipt = await self._runtime.sources.for_scope(self.scope_id)._capture(
            CaptureSource(
                source_id=source_id,
                content=value.model_dump_json(by_alias=True, exclude_none=False, indent=2),
                metadata={"kind": kind, "schema": value.model_dump(by_alias=True)["schema"]},
            ),
            handoff_receipt=kind == HANDOFF_RECEIPT_SOURCE_KIND,
        )
        return WorkSourceReceipt(
            kind=kind,
            source_ref=receipt.source_ref,
            position=receipt.sequence,
            content_digest=content_digest(value),
        )


class WorkApplication:
    """Select the high-level Work application for one stable scope."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedWorkApplication:
        return ScopedWorkApplication(self._runtime, scope_id)


class ScopedExternalSkillApplication:
    """Discover and exactly resolve Agent-native Skills in one local scope."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def scan(self) -> ExternalSkillScanResult:
        async with self._runtime._scoped_operation(self.scope_id), self._runtime._locked(self.scope_id):
            return await self._runtime._external_skills(self.scope_id).scan()

    async def list(self, request: ListExternalSkillsRequest, /) -> ExternalSkillList:
        async with self._runtime._scoped_operation(self.scope_id):
            return await self._runtime._external_skills(self.scope_id).list(
                include_unavailable=request.include_unavailable
            )

    async def resolve(self, request: ResolveExternalSkillRequest, /) -> ExternalSkillResolution:
        async with self._runtime._scoped_operation(self.scope_id):
            return await self._runtime._external_skills(self.scope_id).resolve(
                request.external_skill_id,
                request.fingerprint,
            )

    async def import_managed(
        self,
        request: ImportExternalSkillRequest,
        /,
        *,
        on_commit: CandidateCommitHook | None = None,
    ) -> GeneratedCandidateResult:
        importer = self._runtime._external_skill_importer
        if importer is None:
            raise ExternalSkillRegistryUnavailableError()
        async with (
            self._runtime._scoped_operation(
                self.scope_id,
                generation_purpose=ModelUsagePurpose.SKILL_GENERATION,
            ),
            self._runtime._locked(self.scope_id),
        ):
            return await importer(
                self.scope_id,
                request.external_skill_id,
                request.fingerprint,
                request.mode,
                request.reason,
                **({"on_commit": on_commit} if on_commit is not None else {}),
            )


class ExternalSkillApplication:
    """Select a scoped host-local external Skill Registry."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedExternalSkillApplication:
        return ScopedExternalSkillApplication(self._runtime, scope_id)


class ScopedReviewApplication:
    """Inspect and decide current Candidate heads in one scope."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def _candidate_page(self, request, *, metadata_only, connection):
        async with (
            self._runtime._scoped_operation(self.scope_id),
            self._runtime._review_authorization_context(),
            self._runtime._review(self.scope_id)._connection()
            if connection is None
            else nullcontext(connection) as connection,
        ):
            candidates, cursor = await self._runtime._review(self.scope_id).candidate_page(
                request,
                metadata_only=metadata_only,
                connection=connection,
            )
            tags = tuple(candidate for candidate in candidates if candidate.candidate_kind == "tag")
            if tags:
                await self._runtime._catalog_review(self.scope_id).authorize_candidates(tags, connection)
            return candidates, cursor

    async def list(self, request: ListCandidatesRequest, /, *, connection=None) -> ReviewedCandidatePage:
        candidates, cursor = await self._candidate_page(request, metadata_only=False, connection=connection)
        return ReviewedCandidatePage(candidates=candidates, next_cursor=cursor)

    async def catalog(self, request: ListCandidatesRequest, /, *, connection=None):
        from powercontext.builtin.review.models import CandidateCatalogItem, CandidateCatalogPage

        candidates, cursor = await self._candidate_page(request, metadata_only=True, connection=connection)
        return CandidateCatalogPage(
            candidates=tuple(
                CandidateCatalogItem(
                    candidate_id=value.candidate_id,
                    candidate_kind=value.candidate_kind,
                    family=value.proposal.target.family if value.candidate_kind == "tag" else value.family,
                    version=value.version,
                    status=value.status,
                    reason=value.reason,
                )
                for value in candidates
            ),
            next_cursor=cursor,
        )

    async def get(self, request: GetCandidateRequest, /, *, connection=None) -> ReviewedCandidate:
        from powercontext.builtin.review.errors import CandidateNotFoundError

        async with self._runtime._scoped_operation(self.scope_id):
            try:
                return await self._runtime._review(self.scope_id).get_candidate(
                    request.candidate_id, connection=connection
                )
            except CandidateNotFoundError:
                if self._runtime.catalog_changes is None:
                    raise
                return await self._runtime._catalog_review(self.scope_id).get(
                    request.candidate_id, connection=connection
                )

    async def read_view(self, request: GetCandidateRequest, /, *, include_history=False, connection=None):
        """Read a current proposal and optional immutable version metadata."""
        async with self._runtime._scoped_operation(self.scope_id):
            candidate = await self.get(request, connection=connection)
            versions = None
            if include_history:
                if candidate.candidate_kind == "tag":
                    history = await self._runtime._catalog_review(self.scope_id).history(
                        request.candidate_id, connection=connection
                    )
                    versions = tuple(
                        value.model_dump(mode="json", include={"version", "status", "reason", "decision_reason"})
                        for value in history
                    )
                else:
                    versions = await self._runtime._review(self.scope_id).history_summary(
                        request.candidate_id,
                        connection=connection,
                    )
            return candidate, versions

    async def history(self, request: GetCandidateRequest, /):
        async with self._runtime._scoped_operation(self.scope_id):
            candidate = await self.get(request)
            if candidate.candidate_kind == "tag":
                return await self._runtime._catalog_review(self.scope_id).history(request.candidate_id)
            return await self._runtime._review(self.scope_id).history(request.candidate_id)

    async def inspect_evidence(self, candidate_id: str, expected_version: int):
        async with self._runtime._scoped_operation(self.scope_id):
            candidate = await self.get(GetCandidateRequest(candidate_id=candidate_id))
            if candidate.candidate_kind == "tag":
                if candidate.version != expected_version:
                    from powercontext.builtin.review.errors import CandidateConflictError

                    raise CandidateConflictError(candidate_id, expected_version, candidate.version)
                return await self._runtime._catalog_review(self.scope_id).evidence(candidate_id)
            return await self._runtime._review(self.scope_id).inspect_evidence(candidate_id, expected_version)

    async def approve(self, request: ApproveCandidateRequest, /) -> ReviewedCandidate:
        async with self._runtime._scoped_operation(self.scope_id), self._runtime._locked(self.scope_id):
            current = await self.get(GetCandidateRequest(candidate_id=request.candidate_id))
            if current.candidate_kind == "tag":
                return await self._runtime._catalog_review(self.scope_id).approve(
                    request.candidate_id, request.expected_version
                )
            async with self._runtime._scoped_operation(
                self.scope_id,
                embedding_purpose=ModelUsagePurpose.MEMORY_INDEXING if current.family == "atomic-memory" else None,
            ):
                return await self._runtime._review(self.scope_id).approve(
                    request.candidate_id,
                    request.expected_version,
                )

    async def reject(self, request: RejectCandidateRequest, /) -> ReviewedCandidate:
        async with self._runtime._scoped_operation(self.scope_id), self._runtime._locked(self.scope_id):
            current = await self.get(GetCandidateRequest(candidate_id=request.candidate_id))
            if current.candidate_kind == "tag":
                return await self._runtime._catalog_review(self.scope_id).reject(
                    request.candidate_id, request.expected_version, request.reason
                )
            return await self._runtime._review(self.scope_id).reject(
                request.candidate_id,
                request.expected_version,
                request.reason,
            )

    async def revise(self, request: ReviseCandidateRequest, /) -> ReviewedCandidate:
        async with self._runtime._scoped_operation(self.scope_id), self._runtime._locked(self.scope_id):
            current = await self.get(GetCandidateRequest(candidate_id=request.candidate_id))
            if current.candidate_kind == "tag":
                if not isinstance(request.proposal, CatalogChangeProposal) or request.target is not None:
                    raise InvalidCandidateError("proposal", "Tag review requires its complete Tag proposal")
                if request.reason is None:
                    raise InvalidCandidateError("reason", "Tag revision requires a reason")
                return await self._runtime._catalog_review(self.scope_id).revise(
                    request.candidate_id,
                    request.expected_version,
                    after_tags=request.proposal.after_tags,
                    proposal=request.proposal,
                    reason=request.reason,
                    sources=request.sources,
                    artifacts=request.artifacts,
                )
            if isinstance(request.proposal, CatalogChangeProposal):
                raise InvalidCandidateError("proposal", "Artifact review cannot accept a Tag proposal")
            return await self._runtime._review(self.scope_id).revise(
                request.candidate_id,
                request.expected_version,
                request.proposal,
                sources=request.sources,
                artifacts=request.artifacts,
                target=request.target,
                reason=request.reason,
            )


class ReviewApplication:
    """Select a scoped Candidate Review application service."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedReviewApplication:
        return ScopedReviewApplication(self._runtime, scope_id)


class ScopedAtomicMemoryApplication:
    """Run Atomic Memory operations within the Runtime's Scope lease."""

    def __init__(self, runtime: BuiltinRuntime, application, scope_id: str) -> None:
        self._runtime = runtime
        self._scoped = application.for_scope(validate_scope_id(scope_id))
        self.scope_id = validate_scope_id(scope_id)

    async def get(self, artifact_id: str, *, revision: int | None = None, context=None):
        async with self._runtime._scope_operation(self.scope_id):
            return await self._scoped.get(artifact_id, revision=revision, context=context)

    async def state(self, artifact_id: str, *, context=None):
        async with self._runtime._scope_operation(self.scope_id):
            return await self._scoped.state(artifact_id, context=context)

    async def evidence(self, artifact_id: str, *, revision: int, context=None):
        """Read one authorized revision's neutral evidence facts."""

        async with self._runtime._scope_operation(self.scope_id):
            return await self._scoped.evidence(artifact_id, revision=revision, context=context)

    async def read_dependency_snapshot(
        self,
        roots: tuple[ArtifactRef, ...],
        *,
        selected: tuple[AtomicMemoryDependencySelection, ...] | None = None,
        context: ArtifactSearchExecutionContext | None = None,
    ) -> AtomicMemoryDependencySnapshot:
        """Read bounded, authorized provenance while retaining the Scope lease."""
        async with self._runtime._scope_operation(self.scope_id):
            return await self._scoped.read_dependency_snapshot(roots, selected=selected, context=context)

    async def _filter_current_candidates(self, candidates, *, context=None):
        async with self._runtime._scope_operation(self.scope_id):
            return await self._scoped._filter_current_candidates(candidates, context=context)

    async def manifest(self, **kwargs):
        async with self._runtime._scope_operation(self.scope_id):
            return await self._scoped.manifest(**kwargs)

    async def list(self, **kwargs):
        async with self._runtime._scope_operation(self.scope_id):
            return await self._scoped.list(**kwargs)

    async def search(self, query: str, *, _trace: bool = True, **kwargs):
        async with self._runtime._scoped_operation(
            self.scope_id,
            embedding_purpose=ModelUsagePurpose.MEMORY_RECALL,
            generation_purpose=(
                ModelUsagePurpose.MEMORY_RECALL if self._scoped.application.reranker is not None else None
            ),
        ):
            stage = (
                self._runtime._stage(
                    _MEMORY_SEARCH_STAGE,
                    attributes={
                        _MEMORY_SEARCH_REQUESTED_MODE: kwargs.get("mode", "text"),
                        _MEMORY_SEARCH_LIMIT: kwargs.get("limit", 20),
                    },
                )
                if _trace
                else nullcontext(None)
            )
            with stage as span:
                result = await self._scoped.search(query, **kwargs)
                if span is not None:
                    span.set_attributes({
                        _MEMORY_SEARCH_MODE: result.mode,
                        _MEMORY_SEARCH_RESULT_COUNT: len(result.hits),
                        "powercontext.memory.search.embedding_calls": result.embedding_calls,
                        "powercontext.memory.search.generation_calls": result.generation_calls,
                    })
                return result

    async def create(self, contents: Sequence[AtomicMemoryContent], /, *, context=None) -> AtomicMemoryMutationResult:
        """Create explicit Atomic Memories in one all-or-nothing batch."""
        values = tuple(content.model_dump(mode="json", by_alias=True, exclude_none=True) for content in contents)
        async with self._runtime._scoped_operation(
            self.scope_id,
            embedding_purpose=ModelUsagePurpose.MEMORY_INDEXING,
        ):
            created = await self._runtime._records().create_atomic_memories(
                self.scope_id, values, execution_context=context
            )
            records = await self._scoped.get_many(tuple(item.artifact_id for item in created), context=context)
        return AtomicMemoryMutationResult(
            changed=True, records=records, primary_artifact_id=records[0].artifact.artifact_id
        )

    async def flush(self, /, *, limit: int | None = None, context=None) -> MemoryFlushResult:
        """Process the next scoped Source window into Atomic Memory."""
        return await self._runtime._flush_sources(self.scope_id, limit=limit, context=context)

    async def cursor(self) -> SourceCursor:
        async with self._runtime._context(self.scope_id) as runtime_context:
            return await runtime_context.triggers.cursor()

    async def merge(self, inputs, content, **kwargs):
        async with self._runtime._scoped_operation(
            self.scope_id,
            embedding_purpose=ModelUsagePurpose.MEMORY_INDEXING,
        ):
            return await self._scoped.merge(inputs, content, **kwargs)

    async def forget(self, artifact_id: str, **kwargs):
        async with self._runtime._scope_operation(self.scope_id):
            return await self._scoped.forget(artifact_id, **kwargs)

    async def preview_restoration(self, artifact_id: str, **kwargs):
        async with self._runtime._scope_operation(self.scope_id):
            return await self._scoped.preview_restoration(artifact_id, **kwargs)

    async def restore(self, artifact_id: str, **kwargs):
        async with self._runtime._scoped_operation(
            self.scope_id,
            embedding_purpose=ModelUsagePurpose.MEMORY_INDEXING,
        ):
            return await self._scoped.restore(artifact_id, **kwargs)


class AtomicMemoryRuntimeApplication:
    """Public Scope factory for Atomic Memory; workers use the relational application directly."""

    def __init__(self, runtime: BuiltinRuntime, application) -> None:
        self._runtime = runtime
        self._application = application

    def for_scope(self, scope_id: str, /) -> ScopedAtomicMemoryApplication:
        return ScopedAtomicMemoryApplication(self._runtime, self._application, scope_id)


class ScopedArtifactMergeApplication:
    """Keep shared merge operations inside the Runtime's Scope lease."""

    def __init__(
        self, runtime: BuiltinRuntime, application: ArtifactMergeApplication, scope_id: str, family: str
    ) -> None:
        self._runtime = runtime
        self._scoped = application.for_scope(scope_id, family)
        self.scope_id = self._scoped.scope_id
        self.family = family

    @staticmethod
    def _context(context: Any) -> Any:
        return _PREPARE_ATOMIC_CONTEXT.get() if context is None else context

    async def get(self, artifact_id: str, *, revision: int | None = None, context: Any = None) -> ArtifactMergeRecord:
        async with self._runtime._scope_operation(self.scope_id):
            return await self._scoped.get(artifact_id, revision=revision, context=self._context(context))

    async def restoration_outcome(self, artifact_id: str, *, revision: int, context: Any = None):
        async with self._runtime._scope_operation(self.scope_id):
            return await self._scoped.restoration_outcome(
                artifact_id, revision=revision, context=self._context(context)
            )

    async def merge(
        self,
        inputs: Sequence[ArtifactMergeRead],
        content: BaseModel,
        *,
        artifact_id: str | None = None,
        lineage: ArtifactLineage | None = None,
        context: Any = None,
    ) -> ArtifactMergeMutationResult:
        async with self._runtime._scoped_operation(self.scope_id, embedding_purpose=ModelUsagePurpose.MEMORY_INDEXING):
            return await self._scoped.merge(
                inputs, content, artifact_id=artifact_id, lineage=lineage, context=self._context(context)
            )

    async def forget(
        self, artifact_id: str, *, expected_revision: int, expected_state_version: int, context: Any = None
    ) -> ArtifactMergeMutationResult:
        async with self._runtime._scoped_operation(self.scope_id, embedding_purpose=ModelUsagePurpose.MEMORY_INDEXING):
            return await self._scoped.forget(
                artifact_id,
                expected_revision=expected_revision,
                expected_state_version=expected_state_version,
                context=self._context(context),
            )

    async def preview_restoration(
        self,
        artifact_id: str,
        *,
        operation: ArtifactMergeRestoreOperation = "restore",
        revision: int | None = None,
        context: Any = None,
    ) -> ArtifactMergeRestorationPreview:
        async with self._runtime._scope_operation(self.scope_id):
            return await self._scoped.preview_restoration(
                artifact_id, operation=operation, revision=revision, context=self._context(context)
            )

    async def restore(
        self,
        artifact_id: str,
        *,
        operation: ArtifactMergeRestoreOperation = "restore",
        revision: int | None = None,
        preview_token: str | None = None,
        context: Any = None,
    ) -> ArtifactMergeMutationResult:
        async with self._runtime._scoped_operation(self.scope_id, embedding_purpose=ModelUsagePurpose.MEMORY_INDEXING):
            return await self._scoped.restore(
                artifact_id,
                operation=operation,
                revision=revision,
                preview_token=preview_token,
                context=self._context(context),
            )


class ArtifactMergeRuntimeApplication:
    """Select a registered Family; authenticated hosts supply the caller context."""

    def __init__(self, runtime: BuiltinRuntime, application: ArtifactMergeApplication) -> None:
        self._runtime = runtime
        self._application = application

    def for_scope(self, scope_id: str, family: str, /) -> ScopedArtifactMergeApplication:
        return ScopedArtifactMergeApplication(self._runtime, self._application, scope_id, family)

    def register(self, service: Any) -> None:
        """Add a Family discovered after composition, such as a plugin family loaded at startup."""

        self._application.register(service)

    def content_type(self, family: str) -> type[BaseModel]:
        """The content model a registered Family's merge results validate against."""

        return self._application.content_type(family)


class ScopedTopicMemoryApplication:
    """Search, exactly read, and request processing for Topic Memory in one scope."""

    def __init__(self, runtime: BuiltinRuntime, scope_id: str) -> None:
        self._runtime = runtime
        self.scope_id = validate_scope_id(scope_id)

    async def search(
        self,
        request: SearchTopicMemoryRequest,
        /,
        *,
        admission: AdmissionFloor | None = None,
        query_embedding: MemoryQueryEmbedding | None = None,
        embedding_timeout_seconds: float | None = None,
        allow_embedding: bool = True,
        execution_context: ArtifactSearchExecutionContext | None = None,
    ) -> TopicMemorySearchResult:
        searcher = self._runtime._topic_memory_searcher
        if searcher is None:
            raise _RuntimeStateError("topic-memory-search")
        query = request.query
        if query != query.strip() or not query or len(query) > MAX_TOPIC_MEMORY_QUERY_LENGTH:
            raise InvalidRuntimeRequestError("topic-memory-query")
        if not 1 <= request.limit <= MAX_TOPIC_MEMORY_SEARCH_LIMIT:
            raise InvalidRuntimeRequestError("topic-memory-limit")
        if len(set(analyze_text(query).split())) > MAX_TOPIC_MEMORY_QUERY_TERMS:
            raise InvalidRuntimeRequestError("topic-memory-query-terms")

        async with self._runtime._scoped_operation(
            self.scope_id,
            embedding_purpose=ModelUsagePurpose.TOPIC_MEMORY_RECALL,
        ):
            return await searcher.search_legacy(
                self.scope_id,
                request.query,
                limit=request.limit,
                admission=admission,
                query_embedding=query_embedding,
                embedding_timeout_seconds=embedding_timeout_seconds,
                allow_embedding=allow_embedding,
                execution_context=execution_context,
            )

    async def get(self, request: GetTopicMemoryRequest, /) -> PublishedTopicMemory:
        if self._runtime._topic_memory_get is None:
            raise _RuntimeStateError("topic-memory-get")
        if request.artifact.family != TopicMemory.family:
            raise InvalidRuntimeRequestError("topic-memory-family")
        async with self._runtime._scoped_operation(self.scope_id):
            return await self._runtime._topic_memory_get(self.scope_id, request.artifact)

    async def browse(
        self,
        *,
        limit: int,
        after: TopicMemoryBrowseCursor | None = None,
    ) -> tuple[TopicMemoryCurrentItem, ...]:
        """Browse current Topic heads for a private management projection."""

        if self._runtime._topic_memory_browse is None:
            raise _RuntimeStateError("topic-memory-browse")
        if not 1 <= limit <= 100:
            raise InvalidRuntimeRequestError("topic-memory-browse-limit")
        async with self._runtime._scoped_operation(self.scope_id):
            return await self._runtime._topic_memory_browse(self.scope_id, limit=limit, after=after)

    async def processing_status(self) -> TopicMemoryProcessingStatus:
        if self._runtime._topic_memory_recovery is None:
            raise TopicMemoryProcessingUnavailableError
        async with self._runtime._scoped_operation(self.scope_id):
            return await self._runtime._topic_memory_recovery.status(self.scope_id)

    async def get_block(self, block_id: str) -> TopicMemoryWorkBlock:
        if self._runtime._topic_memory_recovery is None:
            raise TopicMemoryProcessingUnavailableError
        async with self._runtime._scoped_operation(self.scope_id):
            return await self._runtime._topic_memory_recovery.get_block(self.scope_id, block_id)

    async def retry(self, block_id: str) -> TopicMemoryRetryResult:
        if self._runtime._topic_memory_recovery is None:
            raise TopicMemoryProcessingUnavailableError
        async with self._runtime._scoped_operation(self.scope_id), self._runtime._locked(self.scope_id):
            if not self._runtime._topic_memory_processing_available:
                block = await self._runtime._topic_memory_recovery.get_block(self.scope_id, block_id)
                if block.retried_at is None:
                    raise TopicMemoryProcessingUnavailableError
                # Reading an old acceptance does not require a configured Worker.
                return TopicMemoryRetryResult(block=block)
            result = await self._runtime._topic_memory_recovery.retry(self.scope_id, block_id)
        if self._runtime.artifact_processing_supervisor is not None:
            try:
                self._runtime.artifact_processing_supervisor.wake(TOPIC_MEMORY_SOURCE_WINDOW_BINDING)
            except Exception:
                log_safely(
                    logger,
                    logging.WARNING,
                    "Topic Memory supervisor wake failed after retry acceptance",
                    extra={
                        "event": "topic_memory.retry.wake_failed",
                        "outcome": "accepted",
                        "unit": "topic-memory",
                    },
                )
        return result

    async def flush(self) -> TopicMemoryFlushResult:
        if not self._runtime._topic_memory_processing_available or self._runtime._topic_memory_flush is None:
            raise TopicMemoryProcessingUnavailableError
        async with self._runtime._scoped_operation(self.scope_id), self._runtime._locked(self.scope_id):
            accepted = await self._runtime._topic_memory_flush(self.scope_id)
        if accepted and self._runtime.artifact_processing_supervisor is not None:
            try:
                self._runtime.artifact_processing_supervisor.wake(TOPIC_MEMORY_SOURCE_WINDOW_BINDING)
            except Exception as error:
                log_safely(
                    logger,
                    logging.WARNING,
                    "Topic Memory supervisor wake failed after flush acceptance",
                    exc_info=error,
                    extra={
                        "event": "topic_memory.flush.wake_failed",
                        "outcome": "accepted",
                        "unit": "topic-memory",
                    },
                )
        return TopicMemoryFlushResult(status="accepted" if accepted else "idle")


class TopicMemoryApplication:
    """Select the scoped Topic Memory application service."""

    def __init__(self, runtime: BuiltinRuntime) -> None:
        self._runtime = runtime

    def for_scope(self, scope_id: str, /) -> ScopedTopicMemoryApplication:
        return ScopedTopicMemoryApplication(self._runtime, scope_id)


class BuiltinRuntime:
    """Add business-specific operations over composed built-in contexts."""

    def __init__(
        self,
        *,
        provider: PowerContextProvider[BuiltinSources, BuiltinArtifacts, BuiltinTriggers],
        capabilities: RuntimeCapabilities,
        primary_database: AsyncDatabase | None = None,
        owner_write_transactions: bool = False,
        handoff_committer: Callable[..., Awaitable[Handoff]] | None = None,
        extraction_diagnostics: ExtractionDiagnostics | None = None,
        code_service: CodeService | None = None,
        source_window_limit: int = 100,
        context_assembly_max_entries: int = 8,
        recall_sufficiency_policy: RecallSufficiencyPolicy | None = None,
        recall_embedding_timeout_seconds: float = 0.5,
        scope_cache_size: int = DEFAULT_SCOPE_CACHE_SIZE,
        scope_evictor: ScopeEvictor | None = None,
        scope_cache_observer: ScopeCacheObserver | None = None,
        review_service: ReviewServiceFactory | None = None,
        catalog_change_service: Callable[[str], CatalogChangeService] | None = None,
        profiles: RelationalProfileService | None = None,
        subject_sources: SubjectSourceService | None = None,
        generation_service: GenerationServiceFactory | None = None,
        experience_recall: ExperienceRecall | None = None,
        skill_recall: SkillRecall | None = None,
        skill_lister: SkillLister | None = None,
        skill_origin_reader: SkillOriginReader | None = None,
        skill_governance_reader: SkillGovernanceReader | None = None,
        skill_governance_updater: SkillGovernanceUpdater | None = None,
        skill_package_resolver: SkillPackageResolver | None = None,
        package_snapshot_resolver: PackageSnapshotResolver | None = None,
        skill_package_uploader: SkillPackageUploader | None = None,
        skill_usage_recorder: SkillUsageRecorder | None = None,
        experience_incubator: ExperienceIncubator | None = None,
        topic_memory_search: TopicMemorySearch | None = None,
        topic_memory_get: TopicMemoryGet | None = None,
        topic_memory_browse: TopicMemoryBrowse | None = None,
        topic_memory_flush: TopicMemoryFlush | None = None,
        topic_memory_recovery: TopicMemoryRecoveryService | None = None,
        topic_memory_embedding_model: EmbeddingModel | None = None,
        topic_memory_processing_available: bool = False,
        topic_memory_search_observer: TopicMemorySearchObserver | None = None,
        topic_memory_searcher: TopicMemorySearcher | None = None,
        artifact_search: ArtifactSearchService | None = None,
        external_skill_registry: ExternalSkillRegistryFactory | None = None,
        external_skill_importer: ExternalSkillImporter | None = None,
        skill_publication_service: SkillPublicationServiceFactory | None = None,
        remote_skill_distribution: RemoteSkillDistributionService | None = None,
        statistics_service: StatisticsServiceFactory | None = None,
        record_service: RecordService | None = None,
        bootstrap_receipts: BootstrapReceiptRepository | None = None,
        atomic_memory_application=None,
        artifact_merge_application: ArtifactMergeApplication | None = None,
        prompt_service: PromptService | None = None,
        recall_token_estimator: RecallTokenEstimator | None = None,
        recall_effort_sink: RecallEffortSink | None = None,
        decision_model: DecisionModel | None = None,
        publication_application: ArtifactPublicationApplication | None = None,
        scope_application: ScopeApplication | None = None,
        readiness: RuntimeReadinessChecks | None = None,
        clock: Clock | None = None,
        tracing: RuntimeTracing | None = None,
        remote_ingestion: RemoteIngestion | None = None,
        dream_service: DreamService | None = None,
        generation_concurrency: int = 4,
        archive_service: PortableBundleService | None = None,
        context_binding_codec: BindingCodec | None = None,
        inference_protection: InferenceProtectionConfig | None = None,
    ) -> None:
        if source_window_limit < 1:
            raise _RuntimeConfigurationError("source_window_limit")
        if context_assembly_max_entries < 1:
            raise _RuntimeConfigurationError("context_assembly_max_entries")
        if not recall_embedding_timeout_seconds > 0:
            raise _RuntimeConfigurationError("recall_embedding_timeout_seconds")
        if scope_cache_size < 1:
            raise _RuntimeConfigurationError("scope_cache_size")
        self._provider = provider
        self.context_binding_codec = context_binding_codec or BindingCodec()
        self.inference_protection = (
            InferenceProtectionConfig() if inference_protection is None else inference_protection
        )
        self._primary_database = primary_database
        self._owner_write_transactions = owner_write_transactions
        self._handoff_committer = handoff_committer
        self._capabilities = capabilities
        self._extraction_diagnostics = extraction_diagnostics
        self._review_service = review_service
        self._catalog_change_service = catalog_change_service
        self.profiles = profiles
        self.subject_sources = subject_sources
        self._generation_service = generation_service
        self._dream_service = dream_service
        self._review_action_authorizer: Callable[[str, str, Candidate[Any]], Awaitable[None]] | None = None
        self._catalog_action_authorizer: Callable[[str, str, TagDreamTarget], Awaitable[None]] | None = None
        self._review_evidence_authorizer: ScopedEvidenceAuthorizer | None = None
        self._review_evidence_batch_authorizer: ScopedEvidenceBatchAuthorizer | None = None
        self._review_authorization_context: AuthorizationContext = nullcontext
        self._generation_slots = asyncio.Semaphore(generation_concurrency)
        self._generation_owners: set[asyncio.Task[Any]] = set()
        self._experience_recall = experience_recall
        self._skill_recall = skill_recall
        self._skill_lister = skill_lister
        self._skill_origin_reader = skill_origin_reader
        self._skill_governance_reader = skill_governance_reader
        self._skill_governance_updater = skill_governance_updater
        self._skill_package_resolver = skill_package_resolver
        self._package_snapshot_resolver = package_snapshot_resolver
        self._skill_package_uploader = skill_package_uploader
        self._skill_usage_recorder = skill_usage_recorder
        self._experience_incubator = experience_incubator
        self._topic_memory_search = topic_memory_search
        self._topic_memory_get = topic_memory_get
        self._topic_memory_browse = topic_memory_browse
        self._topic_memory_flush = topic_memory_flush
        self._topic_memory_recovery = topic_memory_recovery
        self._topic_memory_embedding_model = topic_memory_embedding_model
        self._topic_memory_processing_available = topic_memory_processing_available
        self._topic_memory_search_observer = topic_memory_search_observer
        self._topic_memory_searcher = topic_memory_searcher
        if self._topic_memory_searcher is None and topic_memory_search is not None:
            self._topic_memory_searcher = TopicMemorySearcher(
                search=topic_memory_search,
                embedding_model=topic_memory_embedding_model,
                observer=topic_memory_search_observer,
            )
        self._artifact_search = artifact_search
        self._external_skill_registry = external_skill_registry
        self._external_skill_importer = external_skill_importer
        self._skill_publication_service = skill_publication_service
        self._remote_skill_distribution = remote_skill_distribution
        self._statistics_service = statistics_service
        self._record_service = record_service
        self._source_captures = SourceCaptureCoalescer()
        self._bootstrap_receipts = bootstrap_receipts
        self.atomic_memory = (
            None
            if atomic_memory_application is None
            else AtomicMemoryRuntimeApplication(self, atomic_memory_application)
        )
        self.artifact_merge = (
            None
            if artifact_merge_application is None
            else ArtifactMergeRuntimeApplication(self, artifact_merge_application)
        )
        self._prompt_service = prompt_service
        self._recall_token_estimator = recall_token_estimator
        self._recall_effort_sink = recall_effort_sink
        # Public read-only seam for the cross-family decision role; deterministic Runtime callers
        # (and tests) read it directly, and it is always fail-open wrapped before it gets here.
        self.decision_model = decision_model
        self.publications = publication_application
        self.scopes = scope_application
        self._scope_operations: dict[tuple[asyncio.Task[Any] | None, str], ScopeDescriptor] = {}
        self._readiness = RuntimeReadinessChecks() if readiness is None else readiness
        self._clock = _utc_now if clock is None else clock
        self._tracing = tracing
        self.source_window_limit = source_window_limit
        self.context_assembly_max_entries = context_assembly_max_entries
        self.recall_sufficiency_policy = recall_sufficiency_policy
        self.recall_embedding_timeout_seconds = recall_embedding_timeout_seconds
        self._scope_cache = ScopeCache(
            scope_cache_size,
            evictor=scope_evictor,
            observer=scope_cache_observer,
        )
        self._close_lock = asyncio.Lock()
        self._lifecycle = asyncio.Condition()
        self._active_operations = 0
        self._operation_depths: dict[asyncio.Task[Any], int] = {}
        self._closing = False
        self._closed = False
        self.sources = SourceApplication(self)
        self.ingestion = RemoteIngestionApplication(self, remote_ingestion)
        self.code = CodeApplication(self, code_service or CodeService(CodeConfig()))
        self.context = ContextApplication(self)
        self.bootstrap = BootstrapApplication(self)
        self.experience = ExperienceApplication(self)
        self.artifacts = ArtifactApplication(self)
        self.dream = DreamApplication(self)
        self.external_skills = ExternalSkillApplication(self)
        self.handoff = HandoffApplication(self)
        self.work = WorkApplication(self)
        self.topic_memory = TopicMemoryApplication(self)
        self.records = RecordApplication(self)
        self.prompts = PromptApplication(self)
        self.catalog_changes = (
            None if catalog_change_service is None else CatalogChangeApplication(self._catalog_review)
        )
        self.review = ReviewApplication(self)
        self.skill = SkillApplication(self)
        self.remote_skills = RemoteSkillApplication(self)
        self.statistics = StatisticsApplication(self)
        self.archive = archive_service
        self.handoff_report: HandoffReportApplication | None = None
        self.artifact_processing_supervisor: ArtifactProcessingSupervisors | None = None

    async def __aenter__(self) -> BuiltinRuntime:
        return self

    @property
    def primary_database(self) -> AsyncDatabase:
        """Borrow the primary database while the composed Runtime remains open."""

        if self._primary_database is None:
            raise _RuntimeStateError("database")
        return self._primary_database

    @property
    def owner_write_database(self) -> AsyncDatabase | None:
        """Return the database when composition guarantees owner commit hooks."""
        return self._primary_database if self._owner_write_transactions else None

    @asynccontextmanager
    async def read_snapshot(self, scope_id: str, *, flush_usage: bool = False) -> AsyncIterator[ScopeReadSnapshot]:
        """Borrow one built-in Scope read snapshot without granting remote authority.

        The caller owns the PEP and audit completion. Scope existence is included
        in bounded projections, avoiding an independent preflight read.
        """
        from powercontext.builtin.runtime.scope_reads import ScopeReadSnapshot

        scope = validate_scope_id(scope_id)
        async with self._operation():
            if self.atomic_memory is None:
                raise _RuntimeStateError("atomic-memory")
            with self._scope_cache.lease(scope), log_context({"scope": scope}):
                statistics = self._statistics(scope)
                if flush_usage:
                    await statistics.flush_model_usage()
                async with self.primary_database.transaction(consistent_snapshot=True) as connection:
                    yield ScopeReadSnapshot(
                        connection,
                        scope,
                        self.atomic_memory._application.for_scope(scope),
                        statistics,
                        self._clock(),
                        self._records(),
                    )

    async def __aexit__(self, exc_type: object, exc_value: object, traceback: object) -> None:
        await self.close()

    async def capabilities(self) -> RuntimeCapabilities:
        async with self._operation():
            return self._capabilities

    def extraction_status(self) -> ExtractionStatus | None:
        """Read local observations without querying storage or calling a model."""

        if self._extraction_diagnostics is None:
            return None
        return self._extraction_diagnostics.snapshot(self.artifact_processing_supervisor)

    def readiness_snapshot(self) -> RuntimeReadinessSnapshot:
        """Read dependency observations without probing storage or inference providers."""

        snapshot = self._readiness.snapshot()
        if (
            self._closing
            or self._closed
            or (
                self.artifact_processing_supervisor is not None
                and self.artifact_processing_supervisor.status.value == "degraded"
            )
        ):
            return replace(snapshot, status=RuntimeReadinessStatus.NOT_READY)
        return snapshot

    async def readiness(self) -> RuntimeReadiness:
        """Check whether the Runtime and its assembled dependencies can accept work."""

        async with self._operation():
            dependencies = await self._readiness.run()
        supervisor_status = (
            "disabled"
            if self.artifact_processing_supervisor is None
            else self.artifact_processing_supervisor.status.value
        )
        status = dependencies.status
        if supervisor_status == "degraded":
            status = RuntimeReadinessStatus.NOT_READY
        return RuntimeReadiness(
            status=status,
            checks={
                "runtime": ReadinessCheckStatus.READY,
                **dependencies.checks,
                "artifact_processing_supervisor": supervisor_status,
                **(
                    {}
                    if self.artifact_processing_supervisor is None
                    else {
                        f"artifact_processing.{family}": str(details["status"])
                        for family, details in self.artifact_processing_supervisor.family_status.items()
                    }
                ),
            },
        )

    def configure_evidence_authorization(
        self,
        *,
        dream: DreamAuthorizer,
        review: ScopedEvidenceAuthorizer,
        context: AuthorizationContext,
        attest_candidate: CandidateAttester,
        authorize_candidate: CandidateAttester | None = None,
        catalog_action: Callable[[str, str, TagDreamTarget], Awaitable[None]] | None = None,
        review_action: Callable[[str, str, Candidate[Any]], Awaitable[None]] | None = None,
        review_many: ScopedEvidenceBatchAuthorizer | None = None,
    ) -> None:
        """Bind a trusted Server adapter's current authorization policy."""

        self._review_action_authorizer = review_action
        self._catalog_action_authorizer = catalog_action
        self._review_evidence_authorizer = review
        self._review_evidence_batch_authorizer = review_many
        self._review_authorization_context = context
        if self._dream_service is not None:
            self._dream_service.authorize = dream
            self._dream_service.authorization_context = context
            self._dream_service.attest_candidate = attest_candidate
            self._dream_service.authorize_candidate = authorize_candidate

    async def close(self) -> None:
        """Stop accepting work and await in-flight operations without closing the provider."""

        async with self._close_lock:
            if self._closed:
                return
            async with self._lifecycle:
                self._closing = True
                await self._lifecycle.wait_for(lambda: self._active_operations == 0)
            if self.artifact_processing_supervisor is not None:
                await self.artifact_processing_supervisor.close()
            self._scope_cache.clear()
            self._closed = True

    @asynccontextmanager
    async def _operation(self) -> AsyncIterator[None]:
        task = asyncio.current_task()
        if task is None:
            raise RuntimeError("Runtime operations require an asyncio Task")  # noqa: TRY003
        async with self._lifecycle:
            depth = self._operation_depths.get(task, 0)
            if depth == 0:
                if self._closing or self._closed:
                    raise _RuntimeStateError("closed")
                self._active_operations += 1
            self._operation_depths[task] = depth + 1
        try:
            yield
        finally:
            async with self._lifecycle:
                depth = self._operation_depths[task] - 1
                if depth > 0:
                    self._operation_depths[task] = depth
                else:
                    del self._operation_depths[task]
                    self._active_operations -= 1
                    if self._active_operations == 0:
                        self._lifecycle.notify_all()

    @asynccontextmanager
    async def _scope_operation(self, scope_id: str) -> AsyncIterator[ScopeDescriptor]:
        scope = validate_scope_id(scope_id)
        async with self._operation():
            key = (asyncio.current_task(), scope)
            if key in self._scope_operations:
                yield self._scope_operations[key]
                return
            if self.scopes is None:
                raise _RuntimeStateError("scope")
            registered = await self.scopes.get(scope)
            with self._scope_cache.lease(scope):
                self._scope_operations[key] = registered
                try:
                    yield registered
                finally:
                    del self._scope_operations[key]

    @asynccontextmanager
    async def _scoped_operation(
        self,
        scope_id: str,
        *,
        generation_purpose: ModelUsagePurpose | None = None,
        embedding_purpose: ModelUsagePurpose | None = None,
    ) -> AsyncIterator[None]:
        scope = validate_scope_id(scope_id)
        async with self._scope_operation(scope), self._generation_slot(generation_purpose is not None):
            with bind_usage_reporter(
                self.statistics.for_scope(scope).record_model_usage,
                generation_purpose=generation_purpose,
                embedding_purpose=embedding_purpose,
            ):
                yield

    @asynccontextmanager
    async def _generation_slot(self, required: bool) -> AsyncIterator[None]:
        task = asyncio.current_task()
        if not required or task is None or task in self._generation_owners:
            yield
            return
        async with self._generation_slots:
            self._generation_owners.add(task)
            try:
                yield
            finally:
                self._generation_owners.remove(task)

    @asynccontextmanager
    async def _context(
        self,
        scope_id: str,
        *,
        generation_purpose: ModelUsagePurpose | None = None,
        embedding_purpose: ModelUsagePurpose | None = None,
    ) -> AsyncIterator[PowerContext[BuiltinSources, BuiltinArtifacts, BuiltinTriggers]]:
        async with self._scoped_operation(
            scope_id,
            generation_purpose=generation_purpose,
            embedding_purpose=embedding_purpose,
        ):
            # The stage covers provider resolution only; a third-party provider may do I/O here.
            with self._stage("scope.context", attributes={}):
                context = await self._provider.get(validate_scope_id(scope_id))
            yield context

    def _lock(self, scope_id: str) -> asyncio.Lock:
        return self._scope_cache.lock(validate_scope_id(scope_id))

    async def _flush_sources(self, scope_id: str, *, limit: int | None = None, context=None) -> MemoryFlushResult:
        from powercontext.builtin.runtime.relational import _RelationalTriggers

        async with self._context(
            scope_id,
            generation_purpose=ModelUsagePurpose.MEMORY_EXTRACTION,
            embedding_purpose=ModelUsagePurpose.MEMORY_INDEXING,
        ) as runtime_context:
            window_limit = self.source_window_limit if limit is None else limit
            # Relational triggers serialize activations and recheck cursor,
            # window and Artifact reads at commit. Capture may proceed while
            # their model prepares; custom triggers retain Runtime serialization.
            lock = nullcontext() if type(runtime_context.triggers) is _RelationalTriggers else self._locked(scope_id)
            async with lock:
                try:
                    result = await runtime_context.triggers.flush(limit=window_limit, atomic_context=context)
                except Exception as error:
                    if self._extraction_diagnostics is not None:
                        self._extraction_diagnostics.failed(error)
                    raise
                if result.processed and self._extraction_diagnostics is not None:
                    self._extraction_diagnostics.succeeded()
                return result

    @asynccontextmanager
    async def _locked(self, scope_id: str) -> AsyncIterator[None]:
        """Serialize writes for one scope and trace only the wait, not the critical section."""

        lock = self._lock(scope_id)
        acquired = False
        try:
            # Injected tracing must never leak the lock, so the release is armed before the stage is closed.
            with self._stage("scope.lock", attributes={"powercontext.scope.lock.contended": lock.locked()}):
                await lock.acquire()
                acquired = True
            yield
        finally:
            if acquired:
                lock.release()

    def _stage(
        self,
        name: str,
        *,
        attributes: Mapping[str, TraceAttribute],
    ) -> AbstractContextManager[RuntimeSpan | None]:
        if self._tracing is None:
            return nullcontext(None)
        return self._tracing.stage(name, attributes=attributes)

    def _review(self, scope_id: str) -> ReviewService:
        if self._review_service is None:
            raise _RuntimeStateError("review")
        scope = validate_scope_id(scope_id)
        service = self._review_service(scope)
        service.authorize_action = self._review_action_authorizer
        authorizer = self._review_evidence_authorizer
        if authorizer is not None:
            service.configure_authorization(lambda ref: authorizer(scope, ref), self._review_authorization_context)
        return service

    def _catalog_review(self, scope_id: str) -> CatalogChangeService:
        if self._catalog_change_service is None:
            raise _RuntimeStateError("catalog-review")
        scope = validate_scope_id(scope_id)
        service = self._catalog_change_service(scope)
        service.authorize_action = self._catalog_action_authorizer
        authorizer = self._review_evidence_authorizer
        if authorizer is not None:
            batch = self._review_evidence_batch_authorizer
            service.configure_authorization(
                lambda ref: authorizer(scope, ref),
                self._review_authorization_context,
                authorize_many=None if batch is None else lambda refs, connection: batch(scope, refs, connection),
            )
        return service

    def _records(self) -> RecordService:
        if self._record_service is None:
            raise _RuntimeStateError("records")
        return self._record_service

    def _generation(self, scope_id: str) -> ReviewedGenerationService:
        if self._generation_service is None:
            raise _RuntimeStateError("review")
        scope = validate_scope_id(scope_id)
        service = self._generation_service(scope)
        authorizer = self._review_evidence_authorizer
        if authorizer is not None:
            service.configure_authorization(lambda ref: authorizer(scope, ref), self._review_authorization_context)
        return service

    def _external_skills(self, scope_id: str) -> ExternalSkillRegistryService:
        if self._external_skill_registry is None:
            raise ExternalSkillRegistryUnavailableError
        return self._external_skill_registry(validate_scope_id(scope_id))

    def _skill_publications(
        self,
        scope_id: str,
        target: AgentSkillTarget,
        artifact: ArtifactRef,
    ) -> ManagedSkillPublicationService:
        if self._skill_publication_service is None:
            raise _RuntimeStateError("skill-publication")
        return self._skill_publication_service(validate_scope_id(scope_id), target.target_id, artifact.artifact_id)

    def _statistics(self, scope_id: str) -> RelationalScopedStatistics:
        if self._statistics_service is None:
            raise _RuntimeStateError("statistics")
        return self._statistics_service(validate_scope_id(scope_id))


def _contract_evidence(contract: WorkContract) -> tuple[HandoffCitation, ...]:
    return _claims_evidence(contract.facts)


def _outcome_evidence(outcome: TaskOutcome) -> tuple[HandoffCitation, ...]:
    citations = [*_claims_evidence(outcome.observations)]
    if outcome.stop_reason is not None:
        citations.extend(outcome.stop_reason.evidence)
    citations.extend(citation for check in outcome.checks for citation in check.evidence)
    citations.extend(HandoffArtifactCitation(artifact_ref=reference) for reference in outcome.produced_artifacts)
    return _unique_citations(citations)


def _claims_evidence(claims: tuple[WorkClaim | None, ...]) -> tuple[HandoffCitation, ...]:
    return _unique_citations(citation for claim in claims if claim is not None for citation in claim.evidence)


def _unique_citations(citations: Iterable[HandoffCitation]) -> tuple[HandoffCitation, ...]:
    unique: list[HandoffCitation] = []
    for citation in citations:
        if citation not in unique:
            unique.append(citation)
    return tuple(unique)


def _handoff_statement(claim: WorkClaim, boundary: HandoffSourceCitation) -> HandoffStatement:
    return HandoffStatement(
        text=claim.text,
        citations=_unique_citations((boundary, *claim.evidence)),
    )


def _unavailable_evidence(resolution: HandoffResolution) -> tuple[HandoffCitation, ...]:
    return _unique_citations(
        citation for check in resolution.evidence_checks for citation in check.unavailable_evidence
    )


def _utc_now() -> datetime:
    return datetime.now(UTC)
