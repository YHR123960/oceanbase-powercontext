# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Bounded, content-free failure diagnostics shared by every processing Family."""

from __future__ import annotations

import logging
from collections import deque
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager, suppress
from dataclasses import dataclass
from enum import StrEnum
from threading import Lock
from time import monotonic
from typing import Any, TypeVar

from sqlalchemy.exc import DBAPIError

from powercontext._logging import log_safely
from powercontext.limits import MAX_SCOPE_ID_LENGTH

_logger = logging.getLogger(__name__)
_FAILURE_LOG_BURST = 16
_FAILURE_LOG_WINDOW_SECONDS = 1
_failure_log_lock = Lock()
_failure_log_times: dict[tuple[str, str, str, str | None], deque[float]] = {}
_ErrorT = TypeVar("_ErrorT", bound=BaseException)


class ProcessingStage(StrEnum):
    """The processing stage that owned a failure."""

    GENERATION = "generation"
    EMBEDDING = "embedding"
    OUTPUT_PARSING = "output_parsing"
    BUSINESS_VALIDATION = "business_validation"
    PERSISTENCE = "persistence"
    USAGE_ACCOUNTING = "usage_accounting"


class ProcessingFailureReason(StrEnum):
    """A bounded reason, only when the observed evidence supports it."""

    CONTEXT_OVERFLOW = "context_overflow"
    OUTPUT_TRUNCATED = "output_truncated"
    RATE_LIMIT = "rate_limit"
    TIMEOUT = "timeout"
    SCHEMA_INVALID = "schema_invalid"
    PROVIDER_UNAVAILABLE = "provider_unavailable"
    CONFIGURATION = "configuration"
    INVALID_OUTPUT = "invalid_output"
    STORAGE_FAILURE = "storage_failure"
    USAGE_LIMIT = "usage_limit"


_MAX_COUNT = 2**31 - 1
_TEXT_LIMITS = {
    "token_estimator_id": 128,
    "provider_request_id": 128,
    "finish_reason": 64,
    "failure_location": 128,
    "cause_exception_type": 128,
}


def _enum(enum_type: type[StrEnum], value: object) -> Any:
    if value is None:
        return None
    try:
        return enum_type(value)
    except ValueError:
        return None


def _count(value: object) -> int | None:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0 or value > _MAX_COUNT:
        return None
    return value


def _text(value: object, limit: int) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = "".join(character for character in value if character.isprintable()).strip()
    if not cleaned:
        return None
    return cleaned[:limit]


@dataclass(frozen=True, slots=True)
class ProcessingDiagnostics:
    """Safe causal context for one processing failure.

    Every field is bounded: counts are non-negative, provider identifiers and
    reasons are printable and length-limited, and no field carries prompts,
    Source or Artifact bodies, model responses, credentials, or SQL parameters.
    """

    stage: ProcessingStage | None = None
    reason: ProcessingFailureReason | None = None
    input_item_count: int | None = None
    estimated_input_tokens: int | None = None
    token_estimator_id: str | None = None
    effective_budget: int | None = None
    provider_request_id: str | None = None
    finish_reason: str | None = None
    failure_location: str | None = None
    cause_exception_type: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "stage", _enum(ProcessingStage, self.stage))
        object.__setattr__(self, "reason", _enum(ProcessingFailureReason, self.reason))
        object.__setattr__(self, "input_item_count", _count(self.input_item_count))
        object.__setattr__(self, "estimated_input_tokens", _count(self.estimated_input_tokens))
        object.__setattr__(self, "effective_budget", _count(self.effective_budget))
        for name, limit in _TEXT_LIMITS.items():
            object.__setattr__(self, name, _text(getattr(self, name), limit))

    def log_fields(self) -> dict[str, str | int]:
        """Return only the allowlisted operational fields that are set."""

        fields: dict[str, str | int] = {}
        if self.stage is not None:
            fields["processing_stage"] = self.stage.value
        if self.reason is not None:
            fields["failure_reason"] = self.reason.value
        for name in (
            "input_item_count",
            "estimated_input_tokens",
            "token_estimator_id",
            "effective_budget",
            "provider_request_id",
            "finish_reason",
            "failure_location",
            "cause_exception_type",
        ):
            value = getattr(self, name)
            if value is not None:
                fields[name] = value
        return fields


def attach_diagnostics(error: _ErrorT, diagnostics: ProcessingDiagnostics | None) -> _ErrorT:
    """Attach safe diagnostics to an exception without changing its type or message."""

    if diagnostics is not None:
        setattr(error, "processing_diagnostics", diagnostics)  # noqa: B010 - dynamic exception attribute
    return error


def diagnostics_of(error: BaseException) -> ProcessingDiagnostics | None:
    value = getattr(error, "processing_diagnostics", None)
    return value if isinstance(value, ProcessingDiagnostics) else None


def _topic_memory_diagnostics(code: str) -> ProcessingDiagnostics | None:
    """Classify the bounded Topic Memory generation rejection vocabulary."""

    value = code.lower()
    if value == "embedding_unavailable":
        return ProcessingDiagnostics(
            stage=ProcessingStage.EMBEDDING,
            reason=ProcessingFailureReason.CONFIGURATION,
            failure_location=value,
        )
    if value in {"input_budget_exceeded", "reduction_input_budget_exceeded"}:
        return ProcessingDiagnostics(
            stage=ProcessingStage.BUSINESS_VALIDATION,
            reason=ProcessingFailureReason.CONTEXT_OVERFLOW,
            failure_location=value,
        )
    if value in {"window_provider_budget_exceeded", "window_attempt_limit"}:
        return ProcessingDiagnostics(
            stage=ProcessingStage.GENERATION,
            reason=ProcessingFailureReason.USAGE_LIMIT,
            failure_location=value,
        )
    if value == "reduction_output_budget_exceeded":
        return ProcessingDiagnostics(
            stage=ProcessingStage.GENERATION,
            reason=ProcessingFailureReason.USAGE_LIMIT,
            failure_location=value,
        )
    if value in {"output_budget_exceeded", "invalid_stage_budget", "invalid_max_tokens"}:
        return ProcessingDiagnostics(reason=ProcessingFailureReason.CONFIGURATION, failure_location=value)
    if value in {
        "source_window_changed",
        "invalid_window",
        "duplicate_operation",
        "window_attempt_superseded",
        "target_did_not_converge",
        "unaccepted_invocation",
        "invalid_invocation",
        "invalid_work_reservation",
    }:
        # Control-flow and concurrency rejections do not belong to a processing stage.
        return ProcessingDiagnostics(failure_location=value)
    if value in {"source_complexity_limit", "related_history_limit"}:
        # Source structure/character and history-item caps do not establish
        # that a model context window was exceeded.
        return ProcessingDiagnostics(
            stage=ProcessingStage.BUSINESS_VALIDATION,
            failure_location=value,
        )
    if value == "incomplete_target":
        return ProcessingDiagnostics(
            stage=ProcessingStage.PERSISTENCE,
            reason=ProcessingFailureReason.STORAGE_FAILURE,
            failure_location=value,
        )
    if value.startswith("invalid_") or value in {
        "unsupported_evidence",
        "reduction_did_not_progress",
        "duplicate_target",
        "identity_merge",
        "proposal_limit",
    }:
        return ProcessingDiagnostics(
            stage=ProcessingStage.BUSINESS_VALIDATION,
            reason=ProcessingFailureReason.INVALID_OUTPUT,
            failure_location=value,
        )
    return None


def _dream_error_diagnostics(code: str) -> ProcessingDiagnostics | None:
    """Classify the bounded Dream and Evidence rejection vocabulary."""

    value = code.lower()
    if value == "capability_unavailable":
        return ProcessingDiagnostics(
            stage=ProcessingStage.GENERATION,
            reason=ProcessingFailureReason.CONFIGURATION,
            failure_location=value,
        )
    if value == "budget_exceeded":
        return ProcessingDiagnostics(
            stage=ProcessingStage.GENERATION,
            reason=ProcessingFailureReason.USAGE_LIMIT,
            failure_location=value,
        )
    if value == "capacity_exceeded":
        return ProcessingDiagnostics(
            stage=ProcessingStage.BUSINESS_VALIDATION,
            reason=ProcessingFailureReason.USAGE_LIMIT,
            failure_location=value,
        )
    if value == "invalid_generation_output":
        return ProcessingDiagnostics(
            stage=ProcessingStage.BUSINESS_VALIDATION,
            reason=ProcessingFailureReason.INVALID_OUTPUT,
            failure_location=value,
        )
    if value in {
        "unsupported_target",
        "invalid_target",
        "invalid_dream_operation",
        "invalid_artifact_family",
        "invalid_idempotency_key",
        "evidence_unavailable",
        "reference_not_found",
        "invalid_memory_citation",
        "policy_changed",
        "evidence_limit_exceeded",
        "memory_entry_inactive",
        "source_not_eligible",
        "scope_not_found",
    }:
        return ProcessingDiagnostics(
            stage=ProcessingStage.BUSINESS_VALIDATION,
            failure_location=value,
        )
    if value in {"artifact_conflict", "attempt_conflict", "tag_precondition_failed"}:
        return ProcessingDiagnostics(failure_location=value)
    if value in {"access_revoked", "access_unavailable", "dream_request_unavailable", "generation_failed"}:
        return ProcessingDiagnostics(failure_location=value)
    if value in {"idempotency_conflict", "needs_evidence"}:
        return ProcessingDiagnostics(failure_location=value)
    return None


def _handoff_error_diagnostics(code: str) -> ProcessingDiagnostics | None:
    """Classify the bounded Handoff generation rejection vocabulary."""

    value = code.lower()
    if value in {"output", "evidence"}:
        return ProcessingDiagnostics(
            stage=ProcessingStage.BUSINESS_VALIDATION,
            reason=ProcessingFailureReason.INVALID_OUTPUT,
            failure_location=value,
        )
    if value == "budget":
        return ProcessingDiagnostics(
            stage=ProcessingStage.BUSINESS_VALIDATION,
            reason=ProcessingFailureReason.INVALID_OUTPUT,
            failure_location=value,
        )
    if value == "objective":
        return ProcessingDiagnostics(
            stage=ProcessingStage.BUSINESS_VALIDATION,
            reason=ProcessingFailureReason.INVALID_OUTPUT,
            failure_location=value,
        )
    if value in {"rollover_next_action", "rollover_quality"}:
        return ProcessingDiagnostics(
            stage=ProcessingStage.BUSINESS_VALIDATION,
            reason=ProcessingFailureReason.INVALID_OUTPUT,
            failure_location=value,
        )
    return None


def safe_classify_processing_error(error: BaseException) -> ProcessingDiagnostics | None:
    """Never let classification itself change a processing outcome."""

    try:
        return classify_processing_error(error)
    except Exception:
        return None


def classify_block_code(stage: str | None, code: str | None) -> ProcessingDiagnostics | None:
    """Classify a durable block that was observed without a Worker failure."""

    if not isinstance(code, str) or not code:
        return None
    try:
        if stage == "topic_memory":
            return _topic_memory_diagnostics(code)
        else:
            return None
    except Exception:
        return None


def safe_log_fields(diagnostics: ProcessingDiagnostics | None) -> dict[str, str | int]:
    """Never let a diagnostics field failure suppress the failure record."""

    if diagnostics is None:
        return {}
    try:
        return diagnostics.log_fields()
    except Exception:
        return {}


def processing_error_code(exception_type: type[BaseException] | str, error_code: str = "") -> str:
    """Expose only known categories, never exception messages or custom codes."""

    known_codes = {
        "InferenceConfigurationError": "model_configuration_error",
        "PydanticAIConfigurationError": "model_configuration_error",
        "InferenceTimeoutError": "model_timeout",
        "InferenceUnavailableError": "model_unavailable",
        "InvalidInferenceOutputError": "invalid_model_output",
        "AccessDeniedError": "access_denied",
        "AccessIdentityRequiredError": "access_identity_required",
        "AccessUnavailableError": "access_unavailable",
    }
    names = (exception_type,) if isinstance(exception_type, str) else (base.__name__ for base in exception_type.__mro__)
    for name in names:
        if name in known_codes:
            return known_codes[name]
    if error_code in {
        *known_codes.values(),
        "worker_timeout",
        "worker_crash",
        "invalid_worker_result",
        "missing_durable_acknowledgement",
        "invalid_topic_placeholder",
        "invalid_topic_coordination_content",
    }:
        return error_code
    return "processing_failed"


def allow_processing_failure_log(family: str, operation: str, code: str, reason: str | None) -> bool:
    """Apply the process log limit to a bounded diagnostic signature."""
    key = (family, operation, code, reason)
    with _failure_log_lock:
        times = _failure_log_times.setdefault(key, deque(maxlen=_FAILURE_LOG_BURST))
        now = monotonic()
        if len(times) == _FAILURE_LOG_BURST and now - times[0] < _FAILURE_LOG_WINDOW_SECONDS:
            return False
        times.append(now)
        return True


@asynccontextmanager
async def observe_processing_failure(
    family: str,
    operation: str,
    scope_id: str,
    /,
    *,
    input_item_count: int | None = None,
    storage_location: str | None = None,
) -> AsyncIterator[None]:
    """Observe one failed Artifact operation without changing its outcome."""
    try:
        yield
    except Exception as error:
        with suppress(Exception):
            diagnostics = safe_classify_processing_error(error)
            if diagnostics is None and storage_location is not None and isinstance(error, DBAPIError):
                with suppress(Exception):
                    diagnostics = ProcessingDiagnostics(
                        stage=ProcessingStage.PERSISTENCE,
                        reason=ProcessingFailureReason.STORAGE_FAILURE,
                        failure_location=storage_location,
                        cause_exception_type=None if error.orig is None else type(error.orig).__name__,
                    )
                    attach_diagnostics(error, diagnostics)
            fields = safe_log_fields(diagnostics)
            code = processing_error_code(type(error))
            reason = diagnostics.reason if diagnostics is not None else None
            if allow_processing_failure_log(family, operation, code, reason):
                log_safely(
                    _logger,
                    logging.WARNING,
                    "Artifact operation failed",
                    extra={
                        "event": "artifact.operation.failed",
                        "operation": operation,
                        "unit": "stage",
                        "outcome": "failure",
                        "family": family,
                        "scope": scope_id if len(scope_id) <= MAX_SCOPE_ID_LENGTH and scope_id.isprintable() else None,
                        "exception_type": _text(type(error).__name__, 128),
                        "error_code": code,
                        "input_item_count": _count(input_item_count),
                        **fields,
                    },
                )
        raise


def stage_for_operation(operation: object) -> ProcessingStage | None:
    if not isinstance(operation, str) or not operation:
        return None
    value = operation.lower()
    if "embed" in value or "index" in value:
        return ProcessingStage.EMBEDDING
    if value == "generation" or any(term in value for term in ("extract", "generate", "reconcile", "incubate")):
        return ProcessingStage.GENERATION
    return None


def classify_processing_error(error: BaseException) -> ProcessingDiagnostics | None:  # noqa: C901 - bounded vocabulary
    """Derive a bounded classification when no raise site attached one."""

    attached = diagnostics_of(error)
    if attached is not None:
        return attached

    names = {base.__name__ for base in type(error).__mro__}
    operation = getattr(error, "operation", None)
    stage = stage_for_operation(operation)
    if "InferenceTimeoutError" in names or isinstance(error, TimeoutError):
        return ProcessingDiagnostics(stage=stage, reason=ProcessingFailureReason.TIMEOUT)
    if "InferenceUnavailableError" in names:
        status_code = getattr(error, "status_code", None)
        reason = (
            ProcessingFailureReason.RATE_LIMIT if status_code == 429 else ProcessingFailureReason.PROVIDER_UNAVAILABLE
        )
        return ProcessingDiagnostics(stage=stage, reason=reason)
    if "InvalidInferenceOutputError" in names:
        detail = str(getattr(error, "detail", "") or "").lower()
        operation_value = operation.lower() if isinstance(operation, str) else ""
        if operation_value == "atomic-memory-input-budget":
            return ProcessingDiagnostics(
                stage=ProcessingStage.BUSINESS_VALIDATION,
                reason=ProcessingFailureReason.CONTEXT_OVERFLOW,
            )
        if any(term in detail for term in ("schema", "typed", "wrong output", "invalid output tree", "valid result")):
            return ProcessingDiagnostics(
                stage=ProcessingStage.OUTPUT_PARSING,
                reason=ProcessingFailureReason.SCHEMA_INVALID,
            )
        if "vector" in detail:
            return ProcessingDiagnostics(
                stage=ProcessingStage.EMBEDDING,
                reason=ProcessingFailureReason.INVALID_OUTPUT,
            )
        return ProcessingDiagnostics(
            stage=stage or ProcessingStage.OUTPUT_PARSING,
            reason=ProcessingFailureReason.INVALID_OUTPUT,
        )
    if "InferenceConfigurationError" in names:
        return ProcessingDiagnostics(stage=stage, reason=ProcessingFailureReason.CONFIGURATION)
    if "AtomicMemoryIndexError" in names:
        code = str(getattr(error, "code", "") or "").lower()
        if code == "embedding-profile":
            return ProcessingDiagnostics(
                stage=ProcessingStage.EMBEDDING,
                reason=ProcessingFailureReason.CONFIGURATION,
            )
        if code in {"embedding-input", "embedding-result", "embedding-values"}:
            return ProcessingDiagnostics(
                stage=ProcessingStage.EMBEDDING,
                reason=ProcessingFailureReason.INVALID_OUTPUT,
            )
        if code in {
            "content",
            "prepared-content",
            "limit",
            "mode",
            "admission",
            "threshold",
            "batch-size",
            "vector-search",
        }:
            return ProcessingDiagnostics(
                stage=ProcessingStage.BUSINESS_VALIDATION,
                reason=ProcessingFailureReason.INVALID_OUTPUT,
            )
        if code == "state":
            return ProcessingDiagnostics(stage=ProcessingStage.BUSINESS_VALIDATION)
        if code in {
            "family",
            "dialect",
            "oceanbase",
            "sqlite",
            "sqlite-fts",
            "sqlite-vector",
            "oceanbase-fts",
            "oceanbase-vector",
            "vector-schema",
            "current-schema",
            "authority-schema",
            "migration-pending",
            "maintenance-required",
        }:
            return ProcessingDiagnostics(reason=ProcessingFailureReason.CONFIGURATION)
        if code in {"authority-orphan", "authority-head", "authority-content", "incomplete-vector"}:
            return ProcessingDiagnostics(
                stage=ProcessingStage.PERSISTENCE,
                reason=ProcessingFailureReason.STORAGE_FAILURE,
            )
        if code == "publication":
            return ProcessingDiagnostics(reason=ProcessingFailureReason.CONFIGURATION)
        return None
    if "TopicMemoryGenerationError" in names:
        return _topic_memory_diagnostics(str(getattr(error, "code", "") or ""))
    if "TopicMemoryProjectionError" in names:
        code = str(getattr(error, "code", "") or "").lower()
        if code in {"content", "chunks", "lexical", "vector-incomplete"}:
            return ProcessingDiagnostics(
                stage=ProcessingStage.BUSINESS_VALIDATION,
                reason=ProcessingFailureReason.INVALID_OUTPUT,
                failure_location=code,
            )
        if code in {"fts", "vector-unconfigured", "embedding-profile"}:
            return ProcessingDiagnostics(
                stage=ProcessingStage.PERSISTENCE,
                reason=ProcessingFailureReason.CONFIGURATION,
                failure_location=code,
            )
        if code == "embedding-values":
            return ProcessingDiagnostics(
                stage=ProcessingStage.EMBEDDING,
                reason=ProcessingFailureReason.INVALID_OUTPUT,
                failure_location=code,
            )
        return ProcessingDiagnostics(stage=ProcessingStage.PERSISTENCE, failure_location=code)
    if "TopicMemoryStorageInvariantError" in names:
        code = str(getattr(error, "code", "") or "").lower()
        return ProcessingDiagnostics(
            stage=ProcessingStage.PERSISTENCE,
            reason=ProcessingFailureReason.STORAGE_FAILURE,
            failure_location=code or None,
        )
    if "TopicMemoryCapabilityError" in names:
        capability = str(getattr(error, "capability", "") or "").lower()
        return ProcessingDiagnostics(
            stage=ProcessingStage.PERSISTENCE,
            reason=ProcessingFailureReason.CONFIGURATION,
            failure_location=capability or None,
        )
    if "DreamError" in names:
        return _dream_error_diagnostics(str(getattr(error, "code", "") or ""))
    if "InvalidHandoffGenerationError" in names:
        return _handoff_error_diagnostics(str(getattr(error, "code", "") or ""))
    if "HandoffGenerationUnavailableError" in names:
        return ProcessingDiagnostics(
            stage=ProcessingStage.GENERATION,
            reason=ProcessingFailureReason.CONFIGURATION,
        )
    if "HandoffEvidenceUnavailableError" in names:
        return ProcessingDiagnostics(
            stage=ProcessingStage.BUSINESS_VALIDATION, failure_location="handoff_evidence_unavailable"
        )
    if "HandoffScopeMismatchError" in names:
        return ProcessingDiagnostics(
            stage=ProcessingStage.BUSINESS_VALIDATION, failure_location="handoff_scope_mismatch"
        )
    publication = _publication_error_diagnostics(names)
    if publication is not None:
        return publication
    if "PromptError" in names:
        return _prompt_error_diagnostics(getattr(error, "code", None))
    if "EvidenceResolutionError" in names:
        code = str(getattr(error, "code", "") or "").lower()
        return _dream_error_diagnostics(code)
    return None


def _publication_error_diagnostics(names: set[str]) -> ProcessingDiagnostics | None:
    for exception_type, location in (
        ("ArtifactTargetConflictError", "artifact_target_conflict"),
        ("ArtifactRevisionPreconditionError", "artifact_revision_precondition"),
        ("ArtifactPublicationConflictError", "artifact_publication_conflict"),
        ("ArtifactAlreadyExistsError", "artifact_already_exists"),
        ("RevisionConflictError", "artifact_revision_conflict"),
        ("CandidateConflictError", "candidate_version_conflict"),
        ("CandidateTerminalError", "candidate_terminal"),
        ("BaseValueConflictError", "artifact_write_conflict"),
    ):
        if exception_type in names:
            return ProcessingDiagnostics(failure_location=location)
    for exception_type, location in (
        ("InvalidBaseAccessRequestError", "invalid_artifact_write"),
        ("InvalidCandidateError", "invalid_candidate"),
        ("ScopeNotFoundError", "scope_not_found"),
    ):
        if exception_type in names:
            return ProcessingDiagnostics(stage=ProcessingStage.BUSINESS_VALIDATION, failure_location=location)
    return None


def _prompt_error_diagnostics(code: object) -> ProcessingDiagnostics | None:
    if not isinstance(code, str):
        return None
    if code == "prompt_customization_unavailable":
        return ProcessingDiagnostics(reason=ProcessingFailureReason.CONFIGURATION, failure_location=code)
    if code == "invalid_prompt_demonstrations":
        return ProcessingDiagnostics(
            stage=ProcessingStage.BUSINESS_VALIDATION,
            reason=ProcessingFailureReason.INVALID_OUTPUT,
            failure_location=code,
        )
    if code in {
        "legacy_memory_prompt_unsupported",
        "unknown_prompt_key",
        "prompt_definition_incompatible",
        "invalid_prompt_content",
        "invalid_handoff_generation",
    }:
        return ProcessingDiagnostics(stage=ProcessingStage.BUSINESS_VALIDATION, failure_location=code)
    return None


__all__ = [
    "ProcessingDiagnostics",
    "ProcessingFailureReason",
    "ProcessingStage",
    "allow_processing_failure_log",
    "attach_diagnostics",
    "classify_block_code",
    "classify_processing_error",
    "diagnostics_of",
    "observe_processing_failure",
    "processing_error_code",
    "safe_classify_processing_error",
    "safe_log_fields",
    "stage_for_operation",
]
