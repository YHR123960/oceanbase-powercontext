# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Host-local projections owned by the installed Client package."""

from __future__ import annotations

from collections.abc import Callable
from enum import StrEnum
from pathlib import Path

from powercontext.artifacts import ArtifactRef
from powercontext.client.projections.claude_code import project_skill as export_claude_code_skill
from powercontext.client.projections.codex import project_skill as export_codex_skill
from powercontext.http import SkillProposal


class SkillExportTarget(StrEnum):
    """Agent integrations supported by managed Skill export."""

    CODEX = "codex"
    CLAUDE_CODE = "claude_code"


_SkillExporter = Callable[[ArtifactRef, SkillProposal, Path], Path]
_SKILL_EXPORTERS: dict[SkillExportTarget, _SkillExporter] = {
    SkillExportTarget.CODEX: export_codex_skill,
    SkillExportTarget.CLAUDE_CODE: export_claude_code_skill,
}


def export_skill(
    artifact: ArtifactRef,
    content: SkillProposal,
    target: SkillExportTarget,
    destination: Path,
    /,
) -> Path:
    """Export one exact managed Skill Revision for an Agent integration."""

    return _SKILL_EXPORTERS[target](artifact, content, destination)


__all__ = ["SkillExportTarget", "export_skill"]
