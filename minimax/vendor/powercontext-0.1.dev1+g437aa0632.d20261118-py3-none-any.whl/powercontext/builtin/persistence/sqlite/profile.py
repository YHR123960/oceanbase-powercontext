# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""One-engine SQLite profile using SQLAlchemy's aiosqlite dialect."""

from __future__ import annotations

import asyncio
import sqlite3
from collections.abc import AsyncIterator, Callable
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Literal, cast
from urllib.parse import parse_qsl, unquote, urlsplit
from weakref import WeakKeyDictionary, WeakSet

import aiosqlite
import sqlite_vec
from aiosqlite import Connection, Cursor
from aiosqlite.context import Result
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import Table, event
from sqlalchemy.engine import URL, AdaptedConnection, ExceptionContext, make_url
from sqlalchemy.engine.interfaces import DBAPIConnection
from sqlalchemy.exc import OperationalError
from sqlalchemy.ext.asyncio import AsyncConnection, AsyncEngine, create_async_engine
from sqlalchemy.pool import ConnectionPoolEntry, StaticPool

from powercontext.builtin.persistence.database import AsyncDatabase
from powercontext.builtin.persistence.dream_schema import assert_dream_schema_ready
from powercontext.builtin.persistence.errors import PersistenceError
from powercontext.builtin.persistence.schema import create_tables
from powercontext.builtin.persistence.topic_memory_recovery_schema import BUDGET, prepare_topic_memory_recovery_schema

_WARMUP_RETRY_SECONDS = 0.05
_WARMUP_LOCKS: WeakKeyDictionary[asyncio.AbstractEventLoop, dict[str, asyncio.Lock]] = WeakKeyDictionary()


class SQLiteConfig(BaseModel):
    """Validated component configuration for a SQLite database profile."""

    model_config = ConfigDict(extra="forbid")

    kind: Literal["sqlite"] = "sqlite"
    url: str = "sqlite+aiosqlite:///:memory:"
    busy_timeout_ms: int = Field(default=5_000, ge=0)
    journal_mode: Literal["WAL", "DELETE", "MEMORY"] = "WAL"
    foreign_keys: bool = True
    echo: bool = False

    @field_validator("url")
    @classmethod
    def require_async_sqlite(cls, value: str) -> str:
        """Reject sync or non-SQLite dialects at the configuration boundary."""

        url = make_url(value)
        if url.drivername != "sqlite+aiosqlite":
            raise ValueError("SQLite profile URL must use sqlite+aiosqlite")  # noqa: TRY003
        return value

    @property
    def is_in_memory(self) -> bool:
        """Return whether this profile stores its database only in process memory."""

        return _storage_kind(self.url) == "memory"

    @property
    def is_persistent(self) -> bool:
        """Return whether data survives closing the last connection."""

        return _storage_kind(self.url) == "persistent"


class SQLiteProfile:
    """An initialized SQLite database profile."""

    def __init__(self, *, database: AsyncDatabase, tables: tuple[Table, ...]) -> None:
        self.database = database
        self.tables = tables

    @classmethod
    @asynccontextmanager
    async def open(
        cls,
        config: SQLiteConfig,
        *,
        tables: tuple[Table, ...],
        load_vector_extension: bool = False,
        _archive_recovery: bool = False,
    ) -> AsyncIterator[SQLiteProfile]:
        """Create, initialize and exclusively own one SQLite engine."""

        if sqlite3.sqlite_version_info < (3, 38, 0):
            raise PersistenceError(  # noqa: TRY003
                "SQLite 3.38.0 or newer is required for retrieval; "
                f"this Python uses SQLite {sqlite3.sqlite_version}. Upgrade Python's SQLite library."
            )
        _create_database_directory(config.url)
        engine_options: dict[str, object] = {"echo": config.echo, "hide_parameters": True}
        if not config.is_persistent:
            engine_options["poolclass"] = StaticPool
        engine = _create_sqlite_engine(config.url, **engine_options)
        _configure_sqlite(engine, config, load_vector_extension=load_vector_extension)
        database = AsyncDatabase.own(engine, shared_connection=not config.is_persistent)
        profile = cls(database=database, tables=tables)
        try:
            await assert_dream_schema_ready(engine, _archive_recovery=_archive_recovery)
            if tables:
                await prepare_topic_memory_recovery_schema(
                    engine, initialize=any(table.name == BUDGET for table in tables)
                )
            await _warm_sqlite(engine, config)
            async with database.transaction() as connection:
                await create_tables(connection, tables)
            yield profile
        finally:
            await database.close()

    @classmethod
    @asynccontextmanager
    async def open_readonly(
        cls,
        config: SQLiteConfig,
        *,
        load_vector_extension: bool = False,
    ) -> AsyncIterator[SQLiteProfile]:
        """Read an existing persistent database without schema or journal initialization.

        SQLite's normal WAL locking remains enabled so committed WAL data is
        visible. Its shared-memory coordination may use the WAL/SHM sidecars.
        """

        if not config.is_persistent:
            raise ValueError("read-only SQLite inspection requires a persistent database")  # noqa: TRY003
        engine = _create_sqlite_engine(_readonly_sqlite_url(config.url), echo=config.echo, hide_parameters=True)
        _configure_sqlite(engine, config, load_vector_extension=load_vector_extension, read_only=True)
        database = AsyncDatabase.own(engine)
        try:
            await database.ping()
            yield cls(database=database, tables=())
        finally:
            await database.close()


def _storage_kind(value: str) -> Literal["memory", "temporary", "persistent"]:
    url = make_url(value)
    # Match the driver's effective URI flag and filename, including boolean aliases.
    args, options = url.get_dialect()().create_connect_args(url)
    filename = str(args[0])
    if filename == ":memory:":
        return "memory"
    if not filename:
        return "temporary"
    if options.get("uri") and filename.startswith("file:"):
        # SQLite recognizes only lowercase file:, and does not strip literal URI controls.
        uri = urlsplit(filename.replace("\t", "%09").replace("\n", "%0A").replace("\r", "%0D"))
        # SQLite terminates decoded filenames and parameter strings at the first NUL.
        path = unquote(uri.path).partition("\0")[0]
        parameters = {name.partition("\0")[0]: value.partition("\0")[0] for name, value in parse_qsl(uri.query)}
        if path == ":memory:" or parameters.get("mode") == "memory" or parameters.get("vfs") == "memdb":
            return "memory"
        if not path:
            return "temporary"
    return "persistent"


def _readonly_sqlite_url(value: str) -> URL:
    url = make_url(value)
    database = url.database or ""
    uri = str(url.query.get("uri", "false")).lower() in {"1", "true", "yes", "on", "t", "y"}
    filename = database if uri and database.startswith("file:") else Path(database).absolute().as_uri()
    query = {key: option for key, option in url.query.items() if key not in {"immutable", "nolock"}}
    return url.set(database=filename, query={**query, "mode": "ro", "uri": "true"})


def _create_database_directory(value: str) -> None:
    if _storage_kind(value) != "persistent":
        return
    database = make_url(value).database
    if not database or database == ":memory:":
        return
    Path(database).expanduser().resolve().parent.mkdir(parents=True, exist_ok=True)


def _create_sqlite_engine(url: str | URL, **options: Any) -> AsyncEngine:
    if aiosqlite.__version__ != "0.22.1":
        return create_async_engine(url, **options)
    parsed = make_url(url)
    args, kwargs = parsed.get_dialect()().create_connect_args(parsed)

    async def connect() -> Connection:
        driver = aiosqlite.connect(*args, **kwargs)
        stop = _make_sqlite_stop_idempotent(driver)
        try:
            return await driver
        except BaseException as error:
            if driver._thread.ident is None:
                raise
            # Failed connects never reach SQLAlchemy's connect event. Drain the
            # driver's final callback before its caller can close the event loop.
            stopped = stop()
            interrupted = None
            if stopped is not None:
                while not stopped.done():
                    try:
                        await asyncio.shield(stopped)
                    except asyncio.CancelledError as cancellation:
                        interrupted = cancellation
                stopped.result()
            if interrupted is not None:
                raise interrupted from error
            raise

    return create_async_engine(url, async_creator=connect, **options)


def _configure_sqlite(
    engine: AsyncEngine,
    config: SQLiteConfig,
    *,
    load_vector_extension: bool,
    read_only: bool = False,
) -> None:
    @event.listens_for(engine.sync_engine, "connect")
    def set_pragmas(dbapi_connection: DBAPIConnection, connection_record: ConnectionPoolEntry) -> None:
        driver = cast(Connection, cast(AdaptedConnection, dbapi_connection).driver_connection)
        connection_record.info["_powercontext_sqlite_cursors"] = _track_sqlite_cursors(driver)
        if aiosqlite.__version__ == "0.22.1":
            connection_record.info["_powercontext_sqlite_stop"] = _make_sqlite_stop_idempotent(driver)
        if load_vector_extension:
            dbapi_connection.run_async(_load_sqlite_vec)
            connection_record.info["powercontext_sqlite_vec_loaded"] = True
        cursor = dbapi_connection.cursor()
        try:
            cursor.execute(f"PRAGMA busy_timeout = {config.busy_timeout_ms}")
            cursor.execute(f"PRAGMA foreign_keys = {'ON' if config.foreign_keys else 'OFF'}")
            if read_only:
                cursor.execute("PRAGMA query_only = ON")
        finally:
            cursor.close()

    @event.listens_for(engine.sync_engine, "handle_error")
    def interrupt_cancelled_statement(context: ExceptionContext) -> None:
        connection = context.connection
        if (
            isinstance(context.original_exception, asyncio.CancelledError)
            and connection is not None
            and not connection.closed
            and not connection.invalidated
        ):
            driver = cast(Connection, connection.connection.driver_connection)
            if driver._running and driver._connection is not None:
                # Cancelling an await does not stop SQLite's native statement or disconnect its worker.
                driver._connection.interrupt()
                # SQLite rolls the entire native transaction back when an INSERT,
                # UPDATE or DELETE is interrupted, so writes that already reported
                # success are gone while SQLAlchemy still trusts the transaction.
                # Record it here; the transaction must not commit later work on top
                # of that rollback.
                connection.info["_powercontext_sqlite_interrupted"] = True
                context.is_disconnect = False


def _track_sqlite_cursors(connection: Connection) -> WeakSet[Cursor]:
    original_cursor = connection.cursor
    cursors: WeakSet[Cursor] = WeakSet()

    async def open_cursor() -> Cursor:
        result = await original_cursor()
        cursors.add(result)
        return result

    def cursor() -> Result[Cursor]:
        return Result(open_cursor())

    connection.cursor = cursor
    return cursors


def _make_sqlite_stop_idempotent(connection: Connection) -> Callable[[], asyncio.Future[Any] | None]:
    existing = getattr(connection, "_powercontext_sqlite_stop", None)
    if existing is not None:
        return existing
    original_stop = connection.stop
    requested = False
    stopped: asyncio.Future[Any] | None = None

    def stop_once() -> asyncio.Future[Any] | None:
        nonlocal requested, stopped
        # aiosqlite 0.22.1 can enqueue a second stop after its worker has exited.
        if not requested:
            stopped = original_stop()
            requested = True
        return asyncio.shield(stopped) if stopped is not None else None

    setattr(connection, "stop", stop_once)  # noqa: B010 - patch one connection; the shared aiosqlite class stays untouched
    setattr(connection, "_powercontext_sqlite_stop", stop_once)  # noqa: B010 - retain the waiter across pool admission
    return stop_once


async def ensure_sqlite_vector_extension(connection: AsyncConnection) -> None:
    """Load vector functions only when this connection first serves vector search."""
    if not connection.info.get("powercontext_sqlite_vec_loaded"):
        raw = await connection.get_raw_connection()
        await _load_sqlite_vec(cast(Connection, raw.driver_connection))
        connection.info["powercontext_sqlite_vec_loaded"] = True


async def _load_sqlite_vec(connection: Connection) -> None:
    await connection.enable_load_extension(True)
    try:
        await connection.load_extension(sqlite_vec.loadable_path())
    finally:
        await connection.enable_load_extension(False)


async def _warm_sqlite(engine: AsyncEngine, config: SQLiteConfig) -> None:
    """Set the database-wide journal mode before concurrent schema initialization."""

    async with _warmup_lock(config.url):
        loop = asyncio.get_running_loop()
        deadline = loop.time() + config.busy_timeout_ms / 1_000
        while True:
            try:
                async with engine.connect() as connection:
                    await connection.exec_driver_sql(f"PRAGMA journal_mode = {config.journal_mode}")
                    await connection.commit()
            except OperationalError as error:
                remaining = deadline - loop.time()
                if not is_sqlite_lock_error(error) or remaining <= 0:
                    raise
                await asyncio.sleep(min(_WARMUP_RETRY_SECONDS, remaining))
            else:
                return


def _warmup_lock(value: str) -> asyncio.Lock:
    if _storage_kind(value) != "persistent":
        return asyncio.Lock()
    loop = asyncio.get_running_loop()
    locks = _WARMUP_LOCKS.setdefault(loop, {})
    key = str(Path(make_url(value).database or "").expanduser().resolve())
    return locks.setdefault(key, asyncio.Lock())


def is_sqlite_lock_error(error: OperationalError) -> bool:
    """Recognize SQLite contention, including shared-cache table/schema locks."""

    original = error.orig
    return isinstance(original, sqlite3.OperationalError) and (getattr(original, "sqlite_errorcode", 0) & 0xFF) in (
        sqlite3.SQLITE_BUSY,
        sqlite3.SQLITE_LOCKED,
    )
