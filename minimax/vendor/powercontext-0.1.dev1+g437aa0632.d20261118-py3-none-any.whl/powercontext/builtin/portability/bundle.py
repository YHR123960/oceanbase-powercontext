# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Portable, verified logical bundles for built-in relational storage.

The archive deliberately contains domain rows only.  Database files, search
indexes, trigger cursors, usage statistics, and host-local skill registrations
are deployment details and are not portable state.
"""

# Error reason strings are the public inspection/validation contract.
# ruff: noqa: TRY003

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import re
import shutil
import sqlite3
import tempfile
import zipfile
import zlib
from collections import Counter
from collections.abc import AsyncIterator, Awaitable, Callable, Iterable, Iterator, Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from dataclasses import field as dataclass_field
from datetime import UTC, date, datetime
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, Literal, cast
from uuid import NAMESPACE_URL, UUID, uuid5

from pydantic import TypeAdapter, ValidationError
from sqlalchemy import (
    BigInteger,
    DateTime,
    Integer,
    PrimaryKeyConstraint,
    String,
    UniqueConstraint,
    and_,
    insert,
    literal_column,
    or_,
    select,
    tuple_,
    union_all,
    update,
)
from sqlalchemy import inspect as sqlalchemy_inspect
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncConnection

from powercontext.artifacts import StableHandle
from powercontext.builtin.artifacts.experience.recurrence import (
    RecurrenceMatch,
    RecurrenceObservation,
    canonical_digest,
    match_key,
    observation_identity,
    selection_key,
    verdict_key,
)
from powercontext.builtin.artifacts.skill.package import SkillPackageError, capture_skill_archive
from powercontext.builtin.persistence.atomic_memory_evidence_schema import (
    ATOMIC_MEMORY_EVIDENCE_HISTORY_TABLE,
    SOURCE_EVIDENCE_BINDINGS_TABLE,
)
from powercontext.builtin.persistence.candidates import decode_candidate_proposal_envelope
from powercontext.builtin.persistence.database import AsyncDatabase
from powercontext.builtin.persistence.errors import (
    IdentityMismatchError,
    InvalidStoredPayloadError,
    RepositoryNotFoundError,
)
from powercontext.builtin.persistence.tables import (
    ARTIFACT_HANDLES_TABLE,
    ARTIFACT_HEADS_TABLE,
    ARTIFACT_LINEAGE_ARTIFACTS_TABLE,
    ARTIFACT_LINEAGE_SOURCES_TABLE,
    ARTIFACT_PUBLICATIONS_TABLE,
    ARTIFACT_SOURCE_LOCATORS_TABLE,
    ARTIFACT_TAGS_TABLE,
    ARTIFACTS_TABLE,
    CANDIDATE_HEADS_TABLE,
    CANDIDATE_VERSIONS_TABLE,
    MEMORY_ENTRY_HEADS_TABLE,
    MEMORY_ENTRY_VERSIONS_TABLE,
    PORTABLE_RESTORE_RECEIPTS_TABLE,
    PROFILE_POLICIES_TABLE,
    RECURRENCE_MATCH_TABLE,
    RECURRENCE_OBSERVATION_TABLE,
    SCOPE_CONTEXT_REFERENCES_TABLE,
    SCOPE_CREATION_REQUESTS_TABLE,
    SCOPE_EXTERNAL_REFERENCES_TABLE,
    SCOPES_TABLE,
    SKILL_PACKAGES_TABLE,
    SOURCE_DEFINITION_MANIFESTS_TABLE,
    SOURCE_JOURNAL_HEADS_TABLE,
    SOURCES_TABLE,
    TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE,
)
from powercontext.builtin.records import ArtifactRevisionActor, InvalidBaseAccessRequestError
from powercontext.builtin.scope.models import ScopeExternalReference
from powercontext.builtin.sources.observation_validation import (
    validate_source_definition_manifest,
    validate_source_observation,
)
from powercontext.builtin.tags import normalize_tags
from powercontext.errors import SourceError
from powercontext.sources import SourceDefinitionManifest, SourceLocator, SourceObservation, SourceRef
from powercontext.sources.evidence import MemoryEvidenceDeclaration, SourceEvidence

FORMAT_VERSION = 1
_RECORDS_NAME = "records.ndjson"
_MANIFEST_NAME = "manifest.json"
_SHA256 = "sha256:"
_MAX_ARCHIVE_BYTES = 512 * 1024 * 1024
_MAX_RECORDS_BYTES = 2 * 1024 * 1024 * 1024
_MAX_RECORDS = 2_000_000
_MAX_LINE_BYTES = 8 * 1024 * 1024
_MAX_MANIFEST_BYTES = 256 * 1024
_TARGET_BATCH_RECORDS = 100
_TARGET_BATCH_PARAMETERS = 900
_TARGET_BATCH_KEY_BYTES = 1024 * 1024
_HEX_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")
_ABSOLUTE_HOST_PATH = re.compile(r"^(?:/|file:/+|[A-Za-z]:[\\/]|\\\\)")
_SENSITIVE_KEYS = frozenset({
    "access_token",
    "api_key",
    "apikey",
    "bearer_token",
    "credential",
    "credentials",
    "password",
    "provider_secret",
    "refresh_token",
    "secret",
    "token",
})
_EXCLUDED_RECORD_CLASSES = (
    "access_bindings",
    "audit_records",
    "credentials_and_provider_secrets",
    "evaluation_receipts",
    "external_skill_registrations",
    "host_local_installation_state",
    "legacy_memory_migration_history",
    "restore_receipts",
    "scope_default_selection",
    "search_projections",
    "source_cursors",
    "usage_statistics",
)

RecordType = Literal[
    "scope",
    "scope_context_reference",
    "scope_external_reference",
    "scope_creation_request",
    "source_definition",
    "source_journal_head",
    "source",
    "source_evidence_binding",
    "skill_package",
    "artifact_revision",
    "artifact_handle",
    "artifact_lineage_source",
    "artifact_source_locator",
    "artifact_lineage_artifact",
    "artifact_publication",
    "artifact_head",
    "memory_entry_version",
    "memory_entry_head",
    "atomic_memory_evidence_history",
    "candidate_version",
    "candidate_head",
    "topic_memory_publication",
    "profile_policy",
    "artifact_tag",
    "recurrence_match",
    "recurrence_observation",
]
ProjectionRebuilder = Callable[[tuple[str, ...]], Awaitable[None]]
ExportAuthorizer = Callable[[tuple[str, ...]], Awaitable[None]]
ProgressObserver = Callable[["BundleProgress"], None]


class BundleFormatError(ValueError):
    """The supplied archive is malformed, corrupt, or unsupported."""


class BundleConflictError(ValueError):
    """A target immutable identity exists with different canonical content."""


class BundleCompatibilityError(BundleFormatError):
    """The target does not support the bundle's otherwise valid requirements."""


class BundleRecoveryRequiredError(RuntimeError):
    """A committed restore needs its projections rebuilt before normal startup."""

    def __init__(self) -> None:
        super().__init__("portable restore projections are incomplete; finish archive restore before serving requests")


@dataclass(frozen=True, slots=True)
class BundleInspection:
    """Content-free facts established by parsing and verifying a bundle."""

    bundle_id: str
    scopes: tuple[str, ...]
    record_count: int
    records_by_type: Mapping[str, int]
    total_digest: str
    format_version: int
    producer_version: str


@dataclass(frozen=True, slots=True)
class BundleValidation(BundleInspection):
    """Target compatibility established without performing writes."""

    already_present: int
    conflicts: int
    projections_supported: bool
    compatible: bool
    required_source_types: tuple[str, ...]
    unsupported_source_types: tuple[str, ...]
    required_artifact_families: tuple[str, ...]
    unsupported_artifact_families: tuple[str, ...]
    reader_version: str


@dataclass(frozen=True, slots=True)
class BundleReceipt:
    """Content-free result of an export or restore."""

    bundle_id: str
    record_count: int
    total_digest: str
    inserted: int = 0
    already_present: int = 0
    projections_ready: bool = False
    status: Literal["exported", "authoritative_restored", "ready"] = "exported"


@dataclass(frozen=True, slots=True)
class BundleProgress:
    """Content-free progress suitable for terminals and automation logs."""

    phase: Literal["export", "inspect", "validate", "target", "restore", "projections"]
    processed: int
    total: int | None


@dataclass(frozen=True, slots=True)
class _Record:
    record_type: RecordType
    identity: Mapping[str, str | int]
    payload: Mapping[str, Any]
    digest: str
    # The digest an earlier-schema archive wrote, which its total digest covers; ``digest`` is the current schema's.
    archived_digest: str | None = None


@dataclass(frozen=True, slots=True)
class _TargetLookup:
    """Only keys and the expected digest survive between streamed archive rows."""

    identities: tuple[Mapping[str, Any], ...]
    digest: str


@dataclass(frozen=True, slots=True)
class _RecordSpec:
    """Stable logical fields and their current relational persistence adapter."""

    table: Any
    identity: tuple[str, ...]
    payload: tuple[str, ...]
    scope_field: str | None = "scope_id"
    schema_version: int = 1
    # Payload fields of earlier schema versions still accepted on restore; fields they lack restore as null.
    earlier_payloads: dict[int, tuple[str, ...]] = dataclass_field(default_factory=dict)


_SPECS: dict[RecordType, _RecordSpec] = {
    "scope": _RecordSpec(SCOPES_TABLE, ("scope_id",), ("title", "summary", "parent_scope_id", "version")),
    "scope_context_reference": _RecordSpec(SCOPE_CONTEXT_REFERENCES_TABLE, ("scope_id", "referenced_scope_id"), ()),
    "scope_external_reference": _RecordSpec(
        SCOPE_EXTERNAL_REFERENCES_TABLE,
        ("scope_id", "ordinal"),
        ("kind", "value", "value_digest"),
    ),
    "scope_creation_request": _RecordSpec(
        SCOPE_CREATION_REQUESTS_TABLE,
        ("idempotency_key",),
        ("request_digest", "scope_id"),
    ),
    "source_definition": _RecordSpec(
        SOURCE_DEFINITION_MANIFESTS_TABLE,
        ("definition_name", "definition_version"),
        ("fingerprint", "manifest"),
        scope_field=None,
    ),
    "source_journal_head": _RecordSpec(SOURCE_JOURNAL_HEADS_TABLE, ("scope_id",), ("position",)),
    "source": _RecordSpec(
        SOURCES_TABLE,
        ("scope_id", "source_type", "source_id"),
        ("payload", "journal_position"),
    ),
    "source_evidence_binding": _RecordSpec(
        SOURCE_EVIDENCE_BINDINGS_TABLE,
        ("scope_id", "source_type", "source_id"),
        ("material_digest", "definition_name", "definition_version", "manifest_fingerprint", "declaration"),
    ),
    "skill_package": _RecordSpec(
        SKILL_PACKAGES_TABLE,
        ("scope_id", "tree_digest"),
        (
            "archive_digest",
            "archive_bytes",
            "manifest",
            "file_count",
            "uncompressed_size",
            "archive_size",
        ),
    ),
    "artifact_revision": _RecordSpec(
        ARTIFACTS_TABLE,
        ("scope_id", "family", "artifact_id", "revision"),
        ("content", "created_at", "created_by", "restored_from_revision", "rollback_reason", "metadata"),
        schema_version=3,
        earlier_payloads={2: ("content", "created_at", "created_by", "restored_from_revision", "rollback_reason")},
    ),
    "artifact_handle": _RecordSpec(
        ARTIFACT_HANDLES_TABLE,
        ("scope_id", "family", "handle_key"),
        ("artifact_id", "revision"),
    ),
    "artifact_lineage_source": _RecordSpec(
        ARTIFACT_LINEAGE_SOURCES_TABLE,
        ("scope_id", "family", "artifact_id", "revision", "ordinal"),
        ("source_type", "source_id"),
    ),
    "artifact_source_locator": _RecordSpec(
        ARTIFACT_SOURCE_LOCATORS_TABLE,
        ("scope_id", "family", "artifact_id", "revision", "ordinal"),
        ("locator",),
    ),
    "artifact_lineage_artifact": _RecordSpec(
        ARTIFACT_LINEAGE_ARTIFACTS_TABLE,
        ("scope_id", "family", "artifact_id", "revision", "ordinal"),
        ("upstream_family", "upstream_artifact_id", "upstream_revision", "is_merge_input"),
        schema_version=2,
    ),
    "artifact_publication": _RecordSpec(
        ARTIFACT_PUBLICATIONS_TABLE,
        ("target_scope_id", "target_family", "target_artifact_id", "target_revision"),
        (
            "source_scope_id",
            "source_family",
            "source_artifact_id",
            "source_revision",
            "content_digest",
            "idempotency_key",
        ),
        scope_field="target_scope_id",
    ),
    "artifact_head": _RecordSpec(
        ARTIFACT_HEADS_TABLE,
        ("scope_id", "family", "artifact_id"),
        ("revision", "lifecycle_state", "replacement_artifact_id", "governance_generation", "merged_into_id"),
        schema_version=2,
    ),
    "memory_entry_version": _RecordSpec(
        MEMORY_ENTRY_VERSIONS_TABLE,
        ("scope_id", "memory_artifact_id", "entry_version_id"),
        (
            "family",
            "entry_id",
            "version",
            "previous_version_id",
            "kind",
            "text",
            "source_refs",
            "artifact_refs",
            "entry_content_hash",
            "created_in_revision",
        ),
    ),
    "memory_entry_head": _RecordSpec(
        MEMORY_ENTRY_HEADS_TABLE,
        ("scope_id", "memory_artifact_id", "entry_id"),
        ("family", "head_revision", "entry_version_id", "entry_content_hash"),
    ),
    "atomic_memory_evidence_history": _RecordSpec(
        ATOMIC_MEMORY_EVIDENCE_HISTORY_TABLE,
        ("scope_id", "artifact_id", "revision"),
        ("sources",),
    ),
    "candidate_version": _RecordSpec(
        CANDIDATE_VERSIONS_TABLE,
        ("scope_id", "candidate_id", "version"),
        (
            "family",
            "proposal",
            "source_refs",
            "artifact_refs",
            "target_family",
            "target_artifact_id",
            "target_revision",
            "reason",
        ),
    ),
    "candidate_head": _RecordSpec(
        CANDIDATE_HEADS_TABLE,
        ("scope_id", "candidate_id"),
        (
            "family",
            "version",
            "status",
            "result_family",
            "result_artifact_id",
            "result_revision",
            "decision_reason",
            "candidate_kind",
            "result_payload",
        ),
        schema_version=2,
    ),
    "topic_memory_publication": _RecordSpec(
        TOPIC_MEMORY_REVISION_PUBLICATIONS_TABLE,
        ("scope_id", "family", "artifact_id", "revision"),
        ("published_at",),
    ),
    "profile_policy": _RecordSpec(
        PROFILE_POLICIES_TABLE,
        ("scope_id",),
        ("generation_enabled", "activation_mode", "pending_candidate_id", "version", "updated_at"),
    ),
    "artifact_tag": _RecordSpec(
        ARTIFACT_TAGS_TABLE,
        ("scope_id", "family", "artifact_id", "target_type", "target_id", "tag_key"),
        ("tag_key_hash", "tag", "assigned_at"),
    ),
    # Use ledger uniqueness identities so a changed decision is a conflict,
    # even when its content-derived match key or observation ID also changes.
    "recurrence_match": _RecordSpec(
        RECURRENCE_MATCH_TABLE,
        ("scope_id", "task_outcome_source_type", "task_outcome_source_id", "failure_item_kind", "failure_item_index"),
        (
            "match_key",
            "task_outcome_position",
            "failure_item_digest",
            "candidate_set_mode",
            "candidate_set_digest",
            "result",
            "target_family",
            "target_artifact_id",
            "target_revision",
            "signature_key",
            "payload",
        ),
    ),
    "recurrence_observation": _RecordSpec(
        RECURRENCE_OBSERVATION_TABLE,
        ("scope_id", "verdict_key"),
        (
            "observation_id",
            "selection_key",
            "event",
            "match_basis",
            "family",
            "artifact_id",
            "revision",
            "signature_key",
            "signature_key_hash",
            "task_outcome_source_type",
            "task_outcome_source_id",
            "task_outcome_position",
            "payload",
        ),
    ),
}

# Parent rows always precede their dependent rows.  This matters for SQLite as
# well as for MySQL/OceanBase foreign-key enforcement.
_EXPORT_ORDER: tuple[RecordType, ...] = tuple(_SPECS)


class PortableBundleService:
    """Export and restore complete scopes without depending on a DB dialect.

    The service is intentionally application-facing rather than a database-file
    utility.  Callers must perform authorization before calling :meth:`export`;
    records are never enumerated before the scope arguments are validated.
    """

    def __init__(
        self,
        database: AsyncDatabase,
        /,
        *,
        projection_rebuilder: ProjectionRebuilder | None = None,
        supported_source_types: Iterable[str] | None = None,
        supported_artifact_families: Iterable[str] | None = None,
        artifact_content_decoder: Callable[[Mapping[str, Any]], object] | None = None,
        candidate_decoder: Callable[[Mapping[str, Any]], object] | None = None,
        source_decoder: Callable[[Mapping[str, Any]], object] | None = None,
    ) -> None:
        self._database = database
        self._projection_rebuilder = projection_rebuilder
        self._artifact_content_decoder = artifact_content_decoder
        self._candidate_decoder = candidate_decoder
        self._source_decoder = source_decoder
        self._family_decoders: dict[str, Callable[[Mapping[str, Any]], object]] = {}
        self._supported_source_types = None if supported_source_types is None else frozenset(supported_source_types)
        self._supported_artifact_families = (
            None if supported_artifact_families is None else frozenset(supported_artifact_families)
        )

    def register_artifact_family(self, family: str, decoder: Callable[[Mapping[str, Any]], object]) -> None:
        """Add a loaded family's storage decoder to validation and restoration."""

        self._family_decoders[family] = decoder
        if self._supported_artifact_families is not None:
            self._supported_artifact_families = self._supported_artifact_families | {family}

    async def export(
        self,
        scopes: Iterable[str],
        output: Path,
        /,
        *,
        authorize: ExportAuthorizer,
        progress: ProgressObserver | None = None,
        compress: bool = True,
    ) -> BundleReceipt:
        """Write a verified archive containing all portable records for scopes.

        A single read transaction provides a consistent snapshot on supported
        relational backends.  The resulting ZIP is written only after the
        snapshot has been completely read, so a failed export never presents a
        partially finalized archive at ``output``.
        """

        selected = _validate_scopes(scopes)
        # Authorization is deliberately outside the snapshot transaction and
        # before the first database query or pagination operation.
        await authorize(selected)
        output.parent.mkdir(parents=True, exist_ok=True)
        records_path = _temporary_path(output.parent, suffix=".records.ndjson")
        archive_path = _temporary_path(output.parent, suffix=".pcb")
        try:
            with records_path.open("wb") as stream:
                async with self._database.transaction(consistent_snapshot=True) as connection:
                    await _validate_export_destination(connection, output)
                    await _validate_selected_scopes(connection, selected)
                    count, records_by_type, digest = await self._stream_export(
                        connection, selected, stream, progress=progress
                    )
            bundle_id = str(uuid5(NAMESPACE_URL, f"powercontext:portable:v{FORMAT_VERSION}:{digest}"))
            manifest = {
                "format_version": FORMAT_VERSION,
                "bundle_id": bundle_id,
                "producer": {"name": "powercontext", "version": _producer_version()},
                "scopes": list(selected),
                "record_count": count,
                "records_by_type": dict(sorted(records_by_type.items())),
                "excluded_record_classes": list(_EXCLUDED_RECORD_CLASSES),
                "total_digest": digest,
            }
            compression = zipfile.ZIP_DEFLATED if compress else zipfile.ZIP_STORED
            with zipfile.ZipFile(
                archive_path, "w", compression=compression, compresslevel=9 if compress else None
            ) as archive:
                with (
                    records_path.open("rb") as source,
                    archive.open(_zip_info(_RECORDS_NAME, compression), "w") as target,
                ):
                    shutil.copyfileobj(source, target, length=1024 * 1024)
                archive.writestr(_zip_info(_MANIFEST_NAME, compression), _canonical_json(manifest))
            # Publish only an archive with valid structure and complete dependencies.
            # Reject missing dependencies and size-limit breaches
            # without replacing a previous usable backup at the destination.
            _parse_bundle(archive_path)
            with _validate_dependencies(archive_path, candidate_decoder=self._candidate_decoder):
                archive_path.replace(output)
            return BundleReceipt(bundle_id=bundle_id, record_count=count, total_digest=digest)
        finally:
            records_path.unlink(missing_ok=True)
            archive_path.unlink(missing_ok=True)

    @staticmethod
    async def inspect(source: Path, /, *, progress: ProgressObserver | None = None) -> BundleInspection:
        """Verify structure and checksums without touching the target database."""

        return _parse_bundle(source, progress=progress, phase="inspect")

    async def validate(
        self,
        source: Path,
        /,
        *,
        supported_source_types: Iterable[str] | None = None,
        progress: ProgressObserver | None = None,
    ) -> BundleValidation:
        """Verify bundle integrity, dependencies, and optional adapter support."""

        inspection = _parse_bundle(source, progress=progress, phase="validate")
        with _validate_dependencies(source, candidate_decoder=self._candidate_decoder) as (
            required_sources,
            required_families,
            index,
        ):
            configured = (
                self._supported_source_types if supported_source_types is None else frozenset(supported_source_types)
            )
            missing_sources = () if configured is None else tuple(sorted(required_sources - configured))
            missing_families = (
                ()
                if self._supported_artifact_families is None
                else tuple(sorted(required_families - self._supported_artifact_families))
            )
            already_present, conflicts = await self._target_compatibility(
                source,
                supported_source_types=configured,
                total=inspection.record_count,
                progress=progress,
                dependency_index=index,
            )
        return BundleValidation(
            bundle_id=inspection.bundle_id,
            scopes=inspection.scopes,
            record_count=inspection.record_count,
            records_by_type=inspection.records_by_type,
            total_digest=inspection.total_digest,
            format_version=inspection.format_version,
            producer_version=inspection.producer_version,
            already_present=already_present,
            conflicts=conflicts,
            projections_supported=self._projection_rebuilder is not None,
            compatible=not missing_sources and not missing_families and conflicts == 0,
            required_source_types=tuple(sorted(required_sources)),
            unsupported_source_types=missing_sources,
            required_artifact_families=tuple(sorted(required_families)),
            unsupported_artifact_families=missing_families,
            reader_version=_producer_version(),
        )

    async def restore(
        self,
        source: Path,
        /,
        *,
        supported_source_types: Iterable[str] | None = None,
        progress: ProgressObserver | None = None,
    ) -> BundleReceipt:
        """Restore a validated bundle atomically, skipping identical records.

        Existing rows are compared using the same portable record encoding.  A
        difference at the same primary identity aborts the entire transaction;
        no existing revision or head is overwritten.
        """

        with tempfile.TemporaryDirectory(prefix="powercontext-restore-") as directory:
            snapshot = Path(directory) / "bundle.pcb"
            try:
                if (await asyncio.to_thread(source.stat)).st_size > _MAX_ARCHIVE_BYTES:
                    raise BundleFormatError("bundle exceeds resource limit")
                with source.open("rb") as original, snapshot.open("wb") as target:
                    copied = 0
                    while chunk := original.read(min(1024 * 1024, _MAX_ARCHIVE_BYTES - copied + 1)):
                        copied += len(chunk)
                        if copied > _MAX_ARCHIVE_BYTES:
                            raise BundleFormatError("bundle exceeds resource limit")
                        target.write(chunk)
            except OSError as error:
                raise BundleFormatError("cannot read portable bundle") from error
            return await self._restore_snapshot(
                snapshot, supported_source_types=supported_source_types, progress=progress
            )

    async def _restore_snapshot(
        self, source: Path, /, *, supported_source_types: Iterable[str] | None, progress: ProgressObserver | None
    ) -> BundleReceipt:
        validation = await self.validate(source, supported_source_types=supported_source_types, progress=progress)
        if validation.conflicts:
            raise BundleConflictError(f"target contains {validation.conflicts} conflicting record identities")
        if not validation.compatible:
            raise BundleCompatibilityError("target is not compatible with bundle requirements")
        try:
            with _staged_records(source) as staged:
                async with self._database.transaction() as connection:
                    inserted, existing = await self._write_records(
                        connection, staged, total=validation.record_count, progress=progress
                    )
                    await self._write_restore_receipt(
                        connection,
                        validation,
                        inserted=inserted,
                        already_present=existing,
                        projections_ready=False,
                    )
        except IntegrityError as error:
            raise BundleConflictError("target constraint conflict during transactional restore") from error
        projections_ready = False
        if self._projection_rebuilder is not None:
            _report_progress(progress, "projections", 0, 1)
            await self._projection_rebuilder(validation.scopes)
            projections_ready = True
            _report_progress(progress, "projections", 1, 1)
            async with self._database.transaction() as connection:
                await self._write_restore_receipt(
                    connection,
                    validation,
                    inserted=inserted,
                    already_present=existing,
                    projections_ready=True,
                )
        return BundleReceipt(
            bundle_id=validation.bundle_id,
            record_count=validation.record_count,
            total_digest=validation.total_digest,
            inserted=inserted,
            already_present=existing,
            projections_ready=projections_ready,
            status="ready" if projections_ready else "authoritative_restored",
        )

    async def _write_restore_receipt(
        self,
        connection: AsyncConnection,
        inspection: BundleInspection,
        /,
        *,
        inserted: int,
        already_present: int,
        projections_ready: bool,
    ) -> None:
        row = (
            (
                await connection.execute(
                    select(PORTABLE_RESTORE_RECEIPTS_TABLE).where(
                        PORTABLE_RESTORE_RECEIPTS_TABLE.c.bundle_id == inspection.bundle_id
                    )
                )
            )
            .mappings()
            .one_or_none()
        )
        if row is not None and (
            str(row["total_digest"]) != inspection.total_digest
            or int(row["format_version"]) != inspection.format_version
            or int(row["record_count"]) != inspection.record_count
        ):
            raise BundleConflictError("restore receipt bundle identity conflict")
        values = {
            "format_version": inspection.format_version,
            "total_digest": inspection.total_digest,
            "record_count": inspection.record_count,
            "status": "ready" if projections_ready else "authoritative_restored",
            "inserted": inserted,
            "already_present": already_present,
            "projections_ready": projections_ready,
            "updated_at": datetime.now(UTC),
        }
        if row is None:
            await connection.execute(
                insert(PORTABLE_RESTORE_RECEIPTS_TABLE).values(bundle_id=inspection.bundle_id, **values)
            )
        else:
            await connection.execute(
                update(PORTABLE_RESTORE_RECEIPTS_TABLE)
                .where(PORTABLE_RESTORE_RECEIPTS_TABLE.c.bundle_id == inspection.bundle_id)
                .values(**values)
            )

    async def _target_compatibility(
        self,
        source: Path,
        /,
        *,
        supported_source_types: frozenset[str] | None,
        total: int,
        progress: ProgressObserver | None,
        dependency_index: sqlite3.Connection,
    ) -> tuple[int, int]:
        already_present = 0
        conflicts = 0
        async with self._database.transaction() as connection:
            existing_tables = await connection.run_sync(
                lambda sync_connection: {
                    spec.table.name
                    for spec in _SPECS.values()
                    if sqlalchemy_inspect(sync_connection).has_table(spec.table.name)
                }
            )
            checked_types: set[RecordType] = set()
            pending: dict[RecordType, list[_TargetLookup]] = {}
            pending_parameters = pending_bytes = processed = 0

            async def flush() -> None:
                nonlocal already_present, conflicts, processed
                for kind, lookups in pending.items():
                    present, different = await _check_target_batch(connection, kind, lookups)
                    already_present += present
                    conflicts += different
                    processed += len(lookups)
                    _report_progress(progress, "target", processed, total, force=True)
                pending.clear()

            for record in _iter_records(source):
                self._validate_target_content(record, supported_source_types=supported_source_types)
                spec = _SPECS[record.record_type]
                table = spec.table
                if table.name not in existing_tables:
                    processed += 1
                    _report_progress(progress, "target", processed, total)
                    continue
                if record.record_type not in checked_types:
                    columns = await connection.run_sync(
                        lambda sync_connection, table_name=table.name: {
                            column["name"] for column in sqlalchemy_inspect(sync_connection).get_columns(table_name)
                        }
                    )
                    if not {*spec.identity, *spec.payload} <= columns:
                        raise BundleCompatibilityError(
                            "target schema lacks required archive fields; start the current Runtime to upgrade it"
                        )
                    checked_types.add(record.record_type)
                keys = (record.identity, *_unique_identities(record))
                parameters = sum(len(identity) for identity in keys)
                size = len(_canonical_json(keys)) + len(record.digest)
                if pending and (
                    len(pending.get(record.record_type, ())) >= _TARGET_BATCH_RECORDS
                    or pending_parameters + parameters > _TARGET_BATCH_PARAMETERS
                    or pending_bytes + size > _TARGET_BATCH_KEY_BYTES
                ):
                    await flush()
                    pending_parameters = pending_bytes = 0
                pending.setdefault(record.record_type, []).append(_TargetLookup(keys, record.digest))
                pending_parameters += parameters
                pending_bytes += size
            await flush()
            if (
                conflicts == 0
                and ARTIFACT_PUBLICATIONS_TABLE.name in existing_tables
                and not await _validate_target_publications(connection, dependency_index)
            ):
                conflicts += 1
            if (
                conflicts == 0
                and ARTIFACT_TAGS_TABLE.name in existing_tables
                and not await _validate_target_tag_sets(connection, dependency_index)
            ):
                conflicts += 1
        return already_present, conflicts

    def _validate_target_content(self, record: _Record, /, *, supported_source_types: frozenset[str] | None) -> None:
        if record.record_type == "source":
            self._validate_source(record, supported_source_types=supported_source_types)
            return
        if record.record_type == "candidate_version":
            if self._candidate_decoder is None:
                raise BundleFormatError("target cannot validate Candidate proposals")
            return
        if record.record_type != "artifact_revision":
            return
        family = str(record.identity["family"])
        decoder = self._family_decoders.get(family, self._artifact_content_decoder)
        if decoder is None:
            return
        if self._supported_artifact_families is not None and family not in self._supported_artifact_families:
            return
        try:
            decoder(_row_values(record))
        except InvalidStoredPayloadError as error:
            raise BundleFormatError("Artifact content does not match the target family decoder") from error

    def _validate_source(self, record: _Record, /, *, supported_source_types: frozenset[str] | None) -> None:
        if (
            _source_observation(record) is None
            and supported_source_types is not None
            and record.identity["source_type"] not in supported_source_types
        ):
            return
        if self._source_decoder is None:
            raise BundleFormatError("target cannot validate Source payloads")
        try:
            self._source_decoder(_row_values(record))
        except (
            InvalidStoredPayloadError,
            IdentityMismatchError,
            RepositoryNotFoundError,
            SourceError,
            ValueError,
        ) as error:
            raise BundleFormatError("Source payload does not match the target Source decoder") from error

    async def _write_records(
        self,
        connection: AsyncConnection,
        staged: sqlite3.Connection,
        /,
        *,
        total: int,
        progress: ProgressObserver | None,
    ) -> tuple[int, int]:
        """Replay records in dependency order inside the caller transaction."""
        inserted = 0
        existing = 0
        processed = 0
        for record in _ordered_scope_records(_staged_type_records(staged, "scope")):
            added, skipped = await self._write_batch(connection, "scope", (record,))
            inserted += added
            existing += skipped
            processed += 1
            _report_progress(progress, "restore", processed, total)
        # The disk index was built before acquiring the target write transaction.
        for record_type in _EXPORT_ORDER:
            if record_type == "scope":
                continue
            for records in _staged_batches(staged, record_type):
                added, skipped = await self._write_batch(connection, record_type, records)
                inserted += added
                existing += skipped
                processed += len(records)
                _report_progress(progress, "restore", processed, total)
        return inserted, existing

    async def _write_batch(
        self, connection: AsyncConnection, kind: RecordType, records: tuple[_Record, ...]
    ) -> tuple[int, int]:
        spec = _SPECS[kind]
        keys = spec.identity
        identities = [
            tuple(_database_value(record.identity[key], spec.table.c[key]) for key in keys) for record in records
        ]
        rows = (
            await connection.execute(
                select(spec.table).where(tuple_(*(spec.table.c[key] for key in keys)).in_(identities))
            )
        ).mappings()
        present = {
            _identity_key(record.identity): record.digest
            for row in rows
            for record in (_record_from_row(kind, cast(Mapping[str, Any], dict(row))),)
        }
        values = []
        for record in records:
            digest = present.get(_identity_key(record.identity))
            if digest is not None:
                if digest != record.digest:
                    raise BundleConflictError(f"immutable identity conflict: {kind}")
            else:
                values.append(_row_values(record))
        if values:
            await connection.execute(insert(spec.table), values)
        return len(values), len(records) - len(values)

    async def _stream_export(
        self,
        connection: AsyncConnection,
        scopes: tuple[str, ...],
        stream: Any,
        *,
        progress: ProgressObserver | None,
    ) -> tuple[int, Counter[str], str]:
        count = 0
        records_by_type: Counter[str] = Counter()
        digest = _DigestAccumulator()
        for record_type in _EXPORT_ORDER:
            async for row in _export_rows(connection, record_type, scopes):
                record = _record_from_row(record_type, cast(Mapping[str, Any], dict(row)))
                _validate_record_safe(record)
                stream.write(_canonical_json(_record_document(record)) + b"\n")
                digest.add(record.digest)
                count += 1
                records_by_type[record.record_type] += 1
                _report_progress(progress, "export", count, None)
        _report_progress(progress, "export", count, count)
        return count, records_by_type, digest.value()


async def _check_target_batch(
    connection: AsyncConnection, kind: RecordType, lookups: list[_TargetLookup]
) -> tuple[int, int]:
    spec = _SPECS[kind]
    table = spec.table
    statements = []
    for ordinal, lookup in enumerate(lookups):
        predicate = or_(
            *(
                and_(*(table.c[key] == _database_value(value, table.c[key]) for key, value in identity.items()))
                for identity in lookup.identities
            )
        )
        # Carry the archive ordinal through SQL so matching retains the target's
        # comparison semantics (including collation), not Python key equality.
        statements.append(
            select(
                literal_column(str(ordinal)).label("_archive_ordinal"),
                *(table.c[field] for field in (*spec.identity, *spec.payload)),
            ).where(predicate)
        )
    present = [False] * len(lookups)
    different = [False] * len(lookups)
    # execute() buffers rows in some drivers even without .all(). Bound the
    # cursor to one target row: its payload can dwarf the incoming archive row.
    async with connection.stream(union_all(*statements), execution_options={"yield_per": 1}) as rows:
        async for row in rows.mappings():
            ordinal = int(row["_archive_ordinal"])
            present[ordinal] = True
            if not different[ordinal]:
                different[ordinal] = (
                    _record_from_row(kind, cast(Mapping[str, Any], row)).digest != lookups[ordinal].digest
                )
    return sum(found and not conflict for found, conflict in zip(present, different, strict=True)), sum(different)


async def _export_rows(
    connection: AsyncConnection, kind: RecordType, scopes: tuple[str, ...]
) -> AsyncIterator[Mapping[str, Any]]:
    spec = _SPECS[kind]
    if spec.scope_field is not None:
        predicate = spec.table.c[spec.scope_field].in_(scopes)
        if kind in {"memory_entry_version", "memory_entry_head"}:
            predicate &= (
                select(ARTIFACTS_TABLE.c.artifact_id)
                .where(
                    ARTIFACTS_TABLE.c.scope_id == spec.table.c.scope_id,
                    ARTIFACTS_TABLE.c.family == spec.table.c.family,
                    ARTIFACTS_TABLE.c.artifact_id == spec.table.c.memory_artifact_id,
                )
                .exists()
            )
        rows = await connection.stream(
            select(spec.table).where(predicate).order_by(*(spec.table.c[field] for field in spec.identity))
        )
        async for row in rows.mappings():
            yield cast(Mapping[str, Any], row)
        return

    # Definition manifests are global, but export authority is scope-bound.
    # Include immutable manifests referenced by observations or retained bindings.
    table = SOURCE_DEFINITION_MANIFESTS_TABLE
    for name, definition_version in sorted(await _referenced_definitions(connection, scopes)):
        row = (
            (
                await connection.execute(
                    select(table).where(
                        table.c.definition_name == name, table.c.definition_version == definition_version
                    )
                )
            )
            .mappings()
            .one_or_none()
        )
        if row is None:
            raise BundleFormatError("evidence or observation references missing Source definition")
        yield cast(Mapping[str, Any], row)


async def _referenced_definitions(connection: AsyncConnection, scopes: tuple[str, ...]) -> set[tuple[str, str]]:
    """Collect Definition identities whose immutable manifest must travel with the scope."""

    definitions: set[tuple[str, str]] = set()
    async for row in _export_rows(connection, "source", scopes):
        observation = _source_observation(_record_from_row("source", row))
        if observation is not None:
            definitions.add((observation.source_type, observation.definition_version))
    async for binding in _export_rows(connection, "source_evidence_binding", scopes):
        if binding["manifest_fingerprint"] is not None:
            definitions.add((str(binding["definition_name"]), str(binding["definition_version"])))
    async for row in _export_rows(connection, "atomic_memory_evidence_history", scopes):
        record = _record_from_row("atomic_memory_evidence_history", row)
        definitions.update(
            (source.definition_name, source.definition_version)
            for source in _evidence_history_value(record)
            if source.manifest_fingerprint is not None
        )
    return definitions


def _source_observation(record: _Record) -> SourceObservation | None:
    try:
        value = json.loads(cast(bytes, _database_value(record.payload["payload"])))
    except (ValueError, UnicodeDecodeError):
        return None  # Native Source payloads are interpreted by their adapter.
    if not isinstance(value, dict):
        return None
    if value.get("encoding") == "powercontext-source-v1":
        if value.get("representation") != "observation":
            return None
        value = value.get("value")
    elif "definition_fingerprint" not in value or "source_type" not in value:
        return None  # Legacy native payload.
    try:
        observation = SourceObservation.model_validate_json(_canonical_json(value))
    except ValueError as error:
        raise BundleFormatError("invalid Source observation") from error
    if (observation.source_type, observation.name) != (record.identity["source_type"], record.identity["source_id"]):
        raise BundleFormatError("Source observation identity mismatch")
    return observation


def _source_definition(record: _Record) -> SourceDefinitionManifest:
    try:
        manifest = SourceDefinitionManifest.model_validate_json(
            cast(bytes, _database_value(record.payload["manifest"]))
        )
        validate_source_definition_manifest(manifest)
    except (SourceError, ValueError) as error:
        raise BundleFormatError("invalid Source definition manifest") from error
    if (manifest.name, manifest.version, manifest.fingerprint) != (
        record.identity["definition_name"],
        record.identity["definition_version"],
        record.payload["fingerprint"],
    ):
        raise BundleFormatError("Source definition identity mismatch")
    return manifest


def _record_from_row(record_type: RecordType, row: Mapping[str, Any]) -> _Record:
    spec = _SPECS[record_type]
    identity = {field: _json_value(row[field]) for field in spec.identity}
    payload = {field: _json_value(row[field]) for field in spec.payload}
    canonical = {
        "record_type": record_type,
        "schema_version": spec.schema_version,
        "identity": identity,
        "payload": payload,
    }
    return _Record(record_type=record_type, identity=identity, payload=payload, digest=_digest(canonical))


async def _validate_export_destination(connection: AsyncConnection, output: Path, /) -> None:
    if connection.dialect.name != "sqlite":
        return
    destination = await asyncio.to_thread(output.resolve)
    for row in await connection.exec_driver_sql("PRAGMA database_list"):
        if not row[2]:
            continue
        database = await asyncio.to_thread(Path(row[2]).resolve)
        reserved_names = {database.name.casefold() + suffix for suffix in ("", "-wal", "-shm", "-journal")}
        if (
            await asyncio.to_thread(destination.exists) and await asyncio.to_thread(destination.samefile, database)
        ) or (
            destination.name.casefold() in reserved_names
            and await asyncio.to_thread(destination.parent.samefile, database.parent)
        ):
            raise BundleFormatError("export destination overlaps the source database or its journal")


def _record_document(record: _Record) -> dict[str, Any]:
    return {
        "record_type": record.record_type,
        "schema_version": _SPECS[record.record_type].schema_version,
        "identity": dict(record.identity),
        "payload": dict(record.payload),
        "digest": record.digest,
    }


def _row_values(record: _Record) -> dict[str, Any]:
    table = _SPECS[record.record_type].table
    values = {key: _database_value(value, table.c[key]) for key, value in record.identity.items()}
    values.update({key: _database_value(value, table.c[key]) for key, value in record.payload.items()})
    # Projections are intentionally excluded from logical bundles.  Heads may
    # use NULL searchable text; Memory projections are rebuilt by the runtime.
    if record.record_type == "artifact_head":
        values["searchable_text"] = None
    elif record.record_type == "memory_entry_head":
        values["searchable_text"] = str(record.payload["entry_content_hash"])
    elif record.record_type == "scope":
        values["scope_id_search"] = str(record.identity["scope_id"])
        values["title_search"] = str(record.payload["title"])
        values["summary_search"] = str(record.payload["summary"])
    elif record.record_type == "scope_external_reference":
        values["value_search"] = str(record.payload["value"])
    elif record.record_type == "skill_package":
        values["created_at"] = datetime.now(UTC)
    return values


def _parse_bundle(
    source: Path,
    *,
    progress: ProgressObserver | None = None,
    phase: Literal["inspect", "validate"] = "inspect",
) -> BundleInspection:
    try:
        if source.stat().st_size > _MAX_ARCHIVE_BYTES:
            raise BundleFormatError("bundle exceeds resource limit")
        with zipfile.ZipFile(source) as archive:
            _validate_container(archive)
            with archive.open(_MANIFEST_NAME) as stream:
                manifest = json.loads(stream.read(_MAX_MANIFEST_BYTES + 1), parse_constant=_reject_json_constant)
            _validate_manifest(manifest)
    except (
        OSError,
        EOFError,
        ValueError,
        RecursionError,
        NotImplementedError,
        zipfile.BadZipFile,
        zlib.error,
    ) as error:
        if isinstance(error, BundleFormatError):
            raise
        raise BundleFormatError("cannot read portable bundle") from error
    count = 0
    counts: Counter[str] = Counter()
    digest = _DigestAccumulator()
    scope_ids: list[str] = []
    for record in _iter_records(source):
        if record.record_type == "scope":
            scope_ids.append(str(record.identity["scope_id"]))
        count += 1
        counts[record.record_type] += 1
        digest.add(record.archived_digest or record.digest)
        _report_progress(progress, phase, count, manifest["record_count"])
    expected_count = manifest["record_count"]
    if count != expected_count:
        raise BundleFormatError("manifest record count does not match records")
    if digest.value() != manifest["total_digest"]:
        raise BundleFormatError("bundle total digest does not match records")
    sorted_counts = dict(sorted(counts.items()))
    if sorted_counts != manifest["records_by_type"]:
        raise BundleFormatError("manifest record classes do not match records")
    inspection = BundleInspection(
        bundle_id=manifest["bundle_id"],
        scopes=tuple(manifest["scopes"]),
        record_count=count,
        records_by_type=sorted_counts,
        total_digest=digest.value(),
        format_version=manifest["format_version"],
        producer_version=manifest["producer"]["version"],
    )
    if tuple(sorted(scope_ids)) != inspection.scopes:
        raise BundleFormatError("manifest scopes do not match scope records")
    return inspection


@contextmanager
def _staged_records(source: Path) -> Iterator[sqlite3.Connection]:
    """Index verified records on disk before acquiring the target write transaction."""
    with tempfile.TemporaryDirectory(prefix="powercontext-records-") as directory:
        connection = sqlite3.connect(Path(directory) / "records.db")
        try:
            connection.execute("CREATE TABLE records (sequence INTEGER PRIMARY KEY, kind TEXT, document BLOB)")
            connection.executemany(
                "INSERT INTO records(kind, document) VALUES (?, ?)",
                ((record.record_type, _canonical_json(_record_document(record))) for record in _iter_records(source)),
            )
            connection.execute("CREATE INDEX records_kind ON records(kind, sequence)")
            connection.commit()
            yield connection
        finally:
            connection.close()


def _staged_type_records(staged: sqlite3.Connection, kind: RecordType) -> Iterator[_Record]:
    for row in staged.execute("SELECT document FROM records WHERE kind = ? ORDER BY sequence", (kind,)):
        yield _parse_record(json.loads(row[0]))


def _staged_batches(staged: sqlite3.Connection, kind: RecordType) -> Iterator[tuple[_Record, ...]]:
    batch: list[_Record] = []
    size = 0
    for row in staged.execute("SELECT document FROM records WHERE kind = ? ORDER BY sequence", (kind,)):
        batch.append(_parse_record(json.loads(row[0])))
        size += len(row[0])
        if len(batch) >= 100 or size >= 1024 * 1024:
            yield tuple(batch)
            batch.clear()
            size = 0
    if batch:
        yield tuple(batch)


def _ordered_scope_records(records: Iterable[_Record], /) -> tuple[_Record, ...]:
    pending = {str(record.identity["scope_id"]): record for record in records}
    ordered: list[_Record] = []
    while pending:
        ready = sorted(
            scope_id
            for scope_id, record in pending.items()
            if record.payload["parent_scope_id"] is None or record.payload["parent_scope_id"] not in pending
        )
        if not ready:
            raise BundleFormatError("scope hierarchy contains a cycle")
        for scope_id in ready:
            ordered.append(pending.pop(scope_id))
    return tuple(ordered)


def _iter_records(source: Path, /) -> Iterator[_Record]:
    """Yield verified records without retaining the archive body in memory."""

    try:
        with zipfile.ZipFile(source) as archive, archive.open(_RECORDS_NAME) as stream:
            count = 0
            while line := stream.readline(_MAX_LINE_BYTES + 1):
                if len(line) > _MAX_LINE_BYTES:
                    raise BundleFormatError("record line exceeds size limit")
                if not line.strip():
                    continue
                count += 1
                if count > _MAX_RECORDS:
                    raise BundleFormatError("record count exceeds limit")
                yield _parse_record(json.loads(line, parse_constant=_reject_json_constant))
    except (
        OSError,
        EOFError,
        ValueError,
        RecursionError,
        NotImplementedError,
        zipfile.BadZipFile,
        zlib.error,
    ) as error:
        if isinstance(error, BundleFormatError):
            raise
        raise BundleFormatError("cannot read portable bundle") from error


def _validate_container(archive: zipfile.ZipFile) -> None:
    items = archive.infolist()
    names = [item.filename for item in items]
    if len(items) != 2 or set(names) != {_MANIFEST_NAME, _RECORDS_NAME}:
        raise BundleFormatError("bundle must contain only manifest.json and records.ndjson")
    if any(
        item.is_dir()
        or item.flag_bits & 1
        or item.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}
        or item.compress_size > _MAX_ARCHIVE_BYTES
        for item in items
    ):
        raise BundleFormatError("bundle exceeds resource limits")
    if archive.getinfo(_MANIFEST_NAME).file_size > _MAX_MANIFEST_BYTES:
        raise BundleFormatError("manifest exceeds resource limit")
    if archive.getinfo(_RECORDS_NAME).file_size > _MAX_RECORDS_BYTES:
        raise BundleFormatError("records exceed resource limit")


def _validate_manifest(manifest: object) -> None:  # noqa: C901 - manifest fields have independent constraints.
    if not isinstance(manifest, dict):
        raise BundleFormatError("manifest must be an object")
    manifest = cast(dict[str, object], manifest)
    required = {
        "format_version",
        "bundle_id",
        "producer",
        "scopes",
        "record_count",
        "records_by_type",
        "excluded_record_classes",
        "total_digest",
    }
    if set(manifest) != required:
        raise BundleFormatError("manifest has unknown or missing fields")
    if type(manifest["format_version"]) is not int or manifest["format_version"] != FORMAT_VERSION:
        raise BundleFormatError("unsupported bundle format version")
    if (
        not isinstance(manifest["bundle_id"], str)
        or isinstance(manifest["record_count"], bool)
        or not isinstance(manifest["record_count"], int)
        or manifest["record_count"] < 0
        or manifest["record_count"] > _MAX_RECORDS
    ):
        raise BundleFormatError("manifest has invalid identity or record count")
    try:
        bundle_id = UUID(manifest["bundle_id"])
    except ValueError as error:
        raise BundleFormatError("manifest has invalid bundle identity") from error
    if str(bundle_id) != manifest["bundle_id"]:
        raise BundleFormatError("manifest has invalid bundle identity")
    producer = manifest["producer"]
    if not isinstance(producer, dict):
        raise BundleFormatError("manifest has invalid producer")
    typed_producer = cast(dict[str, object], producer)
    producer_version = typed_producer.get("version")
    if (
        set(typed_producer) != {"name", "version"}
        or typed_producer.get("name") != "powercontext"
        or not isinstance(producer_version, str)
        or not producer_version
    ):
        raise BundleFormatError("manifest has invalid producer")
    scopes = manifest["scopes"]
    if not isinstance(scopes, list) or not all(isinstance(scope, str) for scope in scopes):
        raise BundleFormatError("manifest has invalid scopes")
    typed_scopes = cast(list[str], scopes)
    if _validate_scopes(typed_scopes) != tuple(typed_scopes):
        raise BundleFormatError("manifest has invalid scopes")
    counts = manifest["records_by_type"]
    if (
        not isinstance(counts, dict)
        or any(
            key not in _SPECS or isinstance(value, bool) or not isinstance(value, int) or value < 0
            for key, value in counts.items()
        )
        or sum(cast(dict[str, int], counts).values()) != manifest["record_count"]
        or manifest["excluded_record_classes"] != list(_EXCLUDED_RECORD_CLASSES)
        or not _valid_digest(manifest["total_digest"])
    ):
        raise BundleFormatError("manifest has invalid checksums")


def _parse_record(value: object) -> _Record:
    if not isinstance(value, dict):
        raise BundleFormatError("record must be an object")
    value = cast(dict[str, object], value)
    if set(value) != {"record_type", "schema_version", "identity", "payload", "digest"}:
        raise BundleFormatError("record has unknown or missing fields")
    record_type = value.get("record_type")
    if (
        not isinstance(record_type, str)
        or record_type not in _SPECS
        or type(value.get("schema_version")) is not int
        or (
            value["schema_version"] != _SPECS[cast(RecordType, record_type)].schema_version
            and value["schema_version"] not in _SPECS[cast(RecordType, record_type)].earlier_payloads
        )
    ):
        raise BundleFormatError("unsupported record type or schema")
    identity = value.get("identity")
    payload = value.get("payload")
    digest = value.get("digest")
    if not isinstance(identity, dict) or not isinstance(payload, dict) or not isinstance(digest, str):
        raise BundleFormatError("record has invalid fields")
    identity = cast(dict[str, str | int], identity)
    payload = cast(dict[str, Any], payload)
    typed = cast(RecordType, record_type)
    spec = _SPECS[typed]
    version = cast(int, value["schema_version"])
    fields = spec.payload if version == spec.schema_version else spec.earlier_payloads[version]
    if (
        set(identity) != set(spec.identity)
        or set(payload) != set(fields)
        or any(type(item) is not spec.table.c[field].type.python_type for field, item in identity.items())
        or not _valid_digest(digest)
    ):
        raise BundleFormatError("record has invalid identity or digest")
    canonical = {
        "record_type": typed,
        "schema_version": version,
        "identity": identity,
        "payload": payload,
    }
    if _digest(canonical) != digest:
        raise BundleFormatError("record digest does not match content")
    if version == spec.schema_version:
        record = _Record(record_type=typed, identity=identity, payload=payload, digest=digest)
    else:
        # Staging and target comparisons use the current schema, so the verified record is re-identified in it.
        payload = {name: payload.get(name) for name in spec.payload}
        current = {**canonical, "schema_version": spec.schema_version, "payload": payload}
        record = _Record(
            record_type=typed, identity=identity, payload=payload, digest=_digest(current), archived_digest=digest
        )
    _validate_record_values(record)
    _validate_record_safe(record)
    return record


def _validate_record_values(record: _Record, /) -> None:  # noqa: C901 - one versioned schema contract.
    identity = record.identity
    payload = record.payload
    for field, value in {**identity, **payload}.items():
        column_type = _SPECS[record.record_type].table.c[field].type
        if (
            isinstance(value, str)
            and isinstance(column_type, String)
            and column_type.length is not None
            and len(value) > column_type.length
        ):
            raise BundleFormatError("record string exceeds its portable storage limit")
        if isinstance(value, int) and not isinstance(value, bool) and isinstance(column_type, Integer):
            bits = 63 if isinstance(column_type, BigInteger) else 31
            if not -(1 << bits) <= value < (1 << bits):
                raise BundleFormatError("record integer exceeds its portable storage limit")
    if any(isinstance(value, str) and (not value or value != value.strip()) for value in identity.values()):
        raise BundleFormatError("record identity contains an invalid string")
    positive_identity_fields = {"revision", "version"}
    for field, value in identity.items():
        if isinstance(value, int) and (value < 0 or (field in positive_identity_fields and value == 0)):
            raise BundleFormatError("record identity contains an invalid integer")

    def strings(*fields: str, nullable: tuple[str, ...] = ()) -> None:
        for field in fields:
            value = payload[field]
            if field in nullable and value is None:
                continue
            if not isinstance(value, str):
                raise BundleFormatError("record payload has an invalid string field")

    def integers(*fields: str, positive: bool = False) -> None:
        for field in fields:
            value = payload[field]
            if isinstance(value, bool) or not isinstance(value, int) or value < int(positive):
                raise BundleFormatError("record payload has an invalid integer field")

    def bytes_values(*fields: str, nullable: tuple[str, ...] = ()) -> None:
        for field in fields:
            value = payload[field]
            if field in nullable and value is None:
                continue
            encoded = cast(dict[str, object], value).get("base64") if isinstance(value, dict) else None
            if not isinstance(value, dict) or set(value) != {"base64"} or not isinstance(encoded, str):
                raise BundleFormatError("record payload has an invalid binary field")
            try:
                decoded = base64.b64decode(encoded, validate=True)
            except ValueError as error:
                raise BundleFormatError("record payload has an invalid binary field") from error
            if base64.b64encode(decoded).decode("ascii") != encoded:
                raise BundleFormatError("record payload has a non-canonical binary field")

    kind = record.record_type
    if kind == "scope":
        strings("title", "summary", "parent_scope_id", nullable=("parent_scope_id",))
        integers("version", positive=True)
    elif kind == "scope_context_reference":
        if identity["scope_id"] == identity["referenced_scope_id"]:
            raise BundleFormatError("scope cannot reference itself")
    elif kind == "scope_external_reference":
        strings("kind", "value", "value_digest")
        try:
            ScopeExternalReference(kind=payload["kind"], value=payload["value"])
        except ValidationError as error:
            raise BundleFormatError("scope external reference has invalid domain values") from error
        if payload["value_digest"] != hashlib.sha256(payload["value"].encode()).hexdigest():
            raise BundleFormatError("scope external reference has invalid value digest")
    elif kind == "scope_creation_request":
        strings("request_digest", "scope_id")
    elif kind == "source_journal_head":
        integers("position")
    elif kind == "source_definition":
        strings("fingerprint")
        bytes_values("manifest")
        _source_definition(record)
    elif kind == "source_evidence_binding":
        strings("material_digest", "definition_name", "definition_version")
        strings("manifest_fingerprint", nullable=("manifest_fingerprint",))
        bytes_values("declaration")
        try:
            MemoryEvidenceDeclaration.model_validate_json(cast(bytes, _database_value(payload["declaration"])))
        except (ValidationError, ValueError, TypeError) as error:
            raise BundleFormatError("Source evidence binding has an invalid declaration") from error
        if (
            payload["definition_name"] != identity["source_type"]
            or not _valid_digest(payload["material_digest"])
            or (payload["manifest_fingerprint"] is not None and not _valid_digest(payload["manifest_fingerprint"]))
        ):
            raise BundleFormatError("Source evidence binding identity or digest is invalid")
    elif kind == "atomic_memory_evidence_history":
        bytes_values("sources")
        sources = _evidence_history_value(record)
        if any(
            not _valid_digest(source.material_digest)
            or source.definition_name != source.source_ref.source_type
            or (source.manifest_fingerprint is not None and not _valid_digest(source.manifest_fingerprint))
            for source in sources
        ):
            raise BundleFormatError("Atomic Memory evidence has invalid bindings")
    elif kind == "source":
        bytes_values("payload")
        integers("journal_position", positive=True)
    elif kind in {"recurrence_match", "recurrence_observation"}:
        bytes_values("payload")
        _recurrence_value(record)
    elif kind == "skill_package":
        strings("archive_digest")
        bytes_values("archive_bytes", "manifest")
        integers("file_count", "uncompressed_size", "archive_size", positive=True)
        if not all(
            isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value)
            for value in (identity["tree_digest"], payload["archive_digest"])
        ):
            raise BundleFormatError("Skill package has invalid digest")
    elif kind == "artifact_revision":
        bytes_values("content")
        bytes_values("metadata", nullable=("metadata",))
        strings("created_at", "created_by", "rollback_reason", nullable=("created_at", "created_by", "rollback_reason"))
        if payload["created_at"] is not None:
            _validate_datetime_text(payload["created_at"])
        if payload["created_by"] is not None:
            try:
                ArtifactRevisionActor.model_validate_json(payload["created_by"])
            except ValueError as error:
                raise BundleFormatError("Artifact revision has invalid actor metadata") from error
        restored = payload["restored_from_revision"]
        if restored is not None and (type(restored) is not int or not 0 < restored < int(identity["revision"])):
            raise BundleFormatError("Artifact revision has invalid rollback metadata")
    elif kind == "artifact_handle":
        strings("artifact_id")
        integers("revision", positive=True)
        try:
            StableHandle(family=str(identity["family"]), key=str(identity["handle_key"]))
        except ValueError as error:
            raise BundleFormatError("artifact handle is invalid") from error
    elif kind == "artifact_lineage_source":
        strings("source_type", "source_id")
    elif kind == "artifact_source_locator":
        bytes_values("locator")
        try:
            TypeAdapter(SourceLocator).validate_python(_decoded_bytes_json(payload["locator"], "Source locator"))
        except ValidationError as error:
            raise BundleFormatError("Source locator has invalid domain values") from error
    elif kind == "artifact_lineage_artifact":
        strings("upstream_family", "upstream_artifact_id")
        integers("upstream_revision", positive=True)
        if type(payload["is_merge_input"]) is not bool:
            raise BundleFormatError("artifact lineage has an invalid merge marker")
    elif kind == "artifact_publication":
        strings("source_scope_id", "source_family", "source_artifact_id", "content_digest", "idempotency_key")
        integers("source_revision", positive=True)
    elif kind == "artifact_head":
        strings(
            "lifecycle_state",
            "replacement_artifact_id",
            "merged_into_id",
            nullable=("replacement_artifact_id", "merged_into_id"),
        )
        integers("revision", positive=True)
        integers("governance_generation")
        if payload["lifecycle_state"] not in {"active", "deprecated", "retired"} or (
            payload["replacement_artifact_id"] is not None
            and (
                payload["lifecycle_state"] != "deprecated"
                or payload["replacement_artifact_id"] == identity["artifact_id"]
            )
        ):
            raise BundleFormatError("artifact head has invalid governance state")
        if payload["merged_into_id"] is not None and (
            payload["lifecycle_state"] != "deprecated"
            or not payload["merged_into_id"]
            or payload["merged_into_id"] == identity["artifact_id"]
            or payload["replacement_artifact_id"] is not None
        ):
            raise BundleFormatError("artifact head has invalid merge state")
    elif kind == "memory_entry_version":
        strings(
            "family",
            "entry_id",
            "previous_version_id",
            "kind",
            "text",
            "entry_content_hash",
            nullable=("previous_version_id",),
        )
        integers("version", "created_in_revision", positive=True)
        bytes_values("source_refs", "artifact_refs")
    elif kind == "memory_entry_head":
        strings("family", "entry_version_id", "entry_content_hash")
        integers("head_revision", positive=True)
    elif kind == "candidate_version":
        strings(
            "family",
            "target_family",
            "target_artifact_id",
            "reason",
            nullable=("target_family", "target_artifact_id", "reason"),
        )
        bytes_values("proposal", "source_refs", "artifact_refs")
        target = (payload["target_family"], payload["target_artifact_id"], payload["target_revision"])
        if target != (None, None, None) and (
            target[0] is None
            or target[1] is None
            or isinstance(target[2], bool)
            or not isinstance(target[2], int)
            or target[2] < 1
        ):
            raise BundleFormatError("candidate version has an incomplete target")
    elif kind == "candidate_head":
        if payload["candidate_kind"] != "artifact" or payload["result_payload"] is not None:
            raise BundleFormatError("tag Candidates are not supported by portable archives")
        strings(
            "family",
            "status",
            "result_family",
            "result_artifact_id",
            "decision_reason",
            nullable=("result_family", "result_artifact_id", "decision_reason"),
        )
        integers("version", positive=True)
        result = (payload["result_family"], payload["result_artifact_id"], payload["result_revision"])
        status = payload["status"]
        valid = (
            (status == "pending" and result == (None, None, None) and payload["decision_reason"] is None)
            or (status == "rejected" and result == (None, None, None) and payload["decision_reason"] is not None)
            or (
                status == "approved"
                and all(value is not None for value in result)
                and isinstance(result[2], int)
                and not isinstance(result[2], bool)
                and result[2] > 0
                and payload["decision_reason"] is None
            )
        )
        if not valid:
            raise BundleFormatError("candidate head has invalid decision state")
    elif kind == "topic_memory_publication":
        strings("published_at")
        _validate_datetime_text(payload["published_at"])
        if identity["family"] != "topic-memory":
            raise BundleFormatError("topic memory publication has invalid family")
    elif kind == "profile_policy":
        if not isinstance(payload["generation_enabled"], bool):
            raise BundleFormatError("profile policy has invalid generation state")
        strings("activation_mode", "pending_candidate_id", "updated_at", nullable=("pending_candidate_id",))
        _validate_datetime_text(payload["updated_at"])
        integers("version", positive=True)
        if payload["activation_mode"] not in {"automatic", "review_required"}:
            raise BundleFormatError("profile policy has invalid activation mode")
    elif kind == "artifact_tag":
        bytes_values("tag_key_hash")
        strings("tag", "assigned_at")
        _validate_datetime_text(payload["assigned_at"])
        if identity["target_type"] not in {"artifact", "memory_entry"}:
            raise BundleFormatError("artifact tag has invalid target type")
        if identity["target_type"] == "artifact" and identity["target_id"] != identity["artifact_id"]:
            raise BundleFormatError("artifact tag has invalid target")
        if identity["target_type"] == "memory_entry" and identity["family"] != "memory":
            raise BundleFormatError("artifact tag has invalid target")
        try:
            normalized = normalize_tags((payload["tag"],))
        except InvalidBaseAccessRequestError as error:
            raise BundleFormatError("artifact tag has invalid label") from error
        if identity["tag_key"] not in normalized:
            raise BundleFormatError("artifact tag label does not match its normalized key")
        if _database_value(payload["tag_key_hash"]) != hashlib.sha256(str(identity["tag_key"]).encode()).digest():
            raise BundleFormatError("artifact tag has invalid key hash")


def _recurrence_value(record: _Record, /) -> RecurrenceMatch | RecurrenceObservation:
    """Check frozen payloads against their indexed fields and idempotency keys."""
    model = RecurrenceMatch if record.record_type == "recurrence_match" else RecurrenceObservation
    try:
        value = model.model_validate_json(cast(bytes, _database_value(record.payload["payload"])), strict=True)
    except (ValidationError, ValueError, TypeError) as error:
        raise BundleFormatError("recurrence payload is invalid") from error
    expected = {
        "scope_id": value.scope_id,
        "task_outcome_source_type": value.task_outcome_ref.source_type,
        "task_outcome_source_id": value.task_outcome_ref.source_id,
        "task_outcome_position": value.task_outcome_position,
        "signature_key": value.signature_key,
    }
    if isinstance(value, RecurrenceMatch):
        ref = value.artifact_ref
        expected.update({
            "match_key": match_key(value),
            "failure_item_kind": value.failure_ref.item_kind,
            "failure_item_index": value.failure_ref.item_index,
            "failure_item_digest": value.failure_ref.item_digest,
            "candidate_set_mode": value.candidate_set_mode,
            "candidate_set_digest": value.candidate_set_digest,
            "result": value.result,
            "target_family": None if ref is None else ref.family,
            "target_artifact_id": None if ref is None else ref.artifact_id,
            "target_revision": None if ref is None else ref.revision,
        })
    else:
        if value.observation_id != canonical_digest(observation_identity(value)):
            raise BundleFormatError("recurrence observation has an invalid identity")
        expected.update({
            "observation_id": value.observation_id,
            "selection_key": selection_key(value),
            "verdict_key": verdict_key(value),
            "event": value.event,
            "match_basis": value.match_basis,
            "family": value.artifact_ref.family,
            "artifact_id": value.artifact_ref.artifact_id,
            "revision": value.artifact_ref.revision,
            "signature_key_hash": _json_value(hashlib.sha256(value.signature_key.encode()).digest()),
        })
    actual = {**record.identity, **record.payload}
    if any(type(actual[key]) is not type(field) or actual[key] != field for key, field in expected.items()):
        raise BundleFormatError("recurrence payload does not match its indexed fields")
    return value


def _evidence_history_value(record: _Record, /) -> tuple[SourceEvidence, ...]:
    try:
        value = json.loads(cast(bytes, _database_value(record.payload["sources"])))
    except (ValueError, UnicodeDecodeError, TypeError) as error:
        raise BundleFormatError("Atomic Memory evidence payload is not valid JSON") from error
    if not isinstance(value, list):
        raise BundleFormatError("Atomic Memory evidence payload is not a list")
    try:
        return tuple(SourceEvidence.model_validate(item) for item in value)
    except ValidationError as error:
        raise BundleFormatError("Atomic Memory evidence payload has an invalid Source entry") from error


def _validate_datetime_text(value: object, /) -> None:
    try:
        parsed = datetime.fromisoformat(cast(str, value))
    except ValueError as error:
        raise BundleFormatError("record payload has an invalid datetime field") from error
    if parsed.tzinfo is not None or parsed.isoformat() != value:
        raise BundleFormatError("record payload has a non-canonical datetime field")


async def _validate_selected_scopes(connection: AsyncConnection, scopes: tuple[str, ...], /) -> None:
    selected = set(scopes)
    rows = tuple(
        (
            await connection.execute(
                select(SCOPES_TABLE.c.scope_id, SCOPES_TABLE.c.parent_scope_id).where(
                    SCOPES_TABLE.c.scope_id.in_(scopes)
                )
            )
        ).mappings()
    )
    if {str(row["scope_id"]) for row in rows} != selected:
        raise BundleFormatError("one or more selected scopes do not exist")
    if any(row["parent_scope_id"] is not None and str(row["parent_scope_id"]) not in selected for row in rows):
        raise BundleFormatError("selected scope set omits a required parent scope")
    referenced = (
        await connection.execute(
            select(SCOPE_CONTEXT_REFERENCES_TABLE.c.referenced_scope_id).where(
                SCOPE_CONTEXT_REFERENCES_TABLE.c.scope_id.in_(scopes)
            )
        )
    ).scalars()
    if any(str(scope_id) not in selected for scope_id in referenced):
        raise BundleFormatError("selected scope set omits a referenced context scope")
    publication_sources = (
        await connection.execute(
            select(ARTIFACT_PUBLICATIONS_TABLE.c.source_scope_id).where(
                ARTIFACT_PUBLICATIONS_TABLE.c.target_scope_id.in_(scopes)
            )
        )
    ).scalars()
    if any(str(scope_id) not in selected for scope_id in publication_sources):
        raise BundleFormatError("selected scope set omits an Artifact publication source scope")


def _validate_record_safe(record: _Record, /) -> None:
    """Reject secret-shaped configuration and host paths without echoing content."""

    # Source payloads are preserved evidence: capture metadata such as `cwd` is history, not host configuration.
    host_paths = record.record_type != "source"
    for field, value in record.payload.items():
        encoded = cast(dict[str, object], value).get("base64") if isinstance(value, dict) else None
        if isinstance(encoded, str):
            try:
                decoded = json.loads(base64.b64decode(encoded, validate=True), parse_constant=_reject_json_constant)
            except BundleFormatError:
                raise
            except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
                continue
            _validate_safe_value(decoded, field, host_paths=host_paths)
        else:
            _validate_safe_value(value, field, host_paths=host_paths)


def _validate_safe_value(value: object, key: str | None = None, *, host_paths: bool) -> None:
    normalized = "" if key is None else key.casefold().replace("-", "_")
    sensitive_suffixes = ("_api_key", "_credential", "_credentials", "_password", "_secret", "_token")
    if (normalized in _SENSITIVE_KEYS or normalized.endswith(sensitive_suffixes)) and value is not None and value != "":
        raise BundleFormatError("bundle contains a credential-shaped field")
    if normalized == "authorization" and isinstance(value, str) and value.casefold().startswith(("bearer ", "basic ")):
        raise BundleFormatError("bundle contains a credential-shaped field")
    if (
        host_paths
        and isinstance(value, str)
        and (
            normalized.endswith(("_path", "_directory", "_home", "_root"))
            or normalized in {"cwd", "directory", "home", "path", "root", "working_directory", "workspace"}
        )
        and _ABSOLUTE_HOST_PATH.match(value)
    ):
        raise BundleFormatError("bundle contains an absolute host path")
    if isinstance(value, dict):
        for child_key, child in value.items():
            _validate_safe_value(child, str(child_key), host_paths=host_paths)
    elif isinstance(value, list):
        for child in value:
            _validate_safe_value(child, key, host_paths=host_paths)


@contextmanager
def _validate_dependencies(
    source: Path, /, *, candidate_decoder: Callable[[Mapping[str, Any]], object] | None = None
) -> Iterator[tuple[set[str], set[str], sqlite3.Connection]]:
    """Validate dependencies with disk-backed identities and bounded metadata."""

    heads, packages = _dependency_metadata(source)
    required_sources: set[str] = set()
    required_families: set[str] = set()
    with _identity_index(source) as index:

        def contains(record_type: str, identity: Mapping[str, object]) -> bool:
            return (
                index.execute(
                    "SELECT 1 FROM identities WHERE record_type = ? AND identity = ?",
                    (record_type, _identity_key(identity)),
                ).fetchone()
                is not None
            )

        for record in _iter_records(source):
            _validate_record_dependencies(record, contains)
            _validate_candidate_record(record, index, candidate_decoder)
            _validate_observation_record(record, index)
            _validate_skill_package_dependency(record, packages)
            if record.record_type == "source":
                if int(record.payload["journal_position"]) > heads.get(str(record.identity["scope_id"]), -1):
                    raise BundleFormatError("source journal snapshot is inconsistent")
                if _source_observation(record) is None:
                    required_sources.add(str(record.identity["source_type"]))
            required_families.update(_required_artifact_families((record,)))
        _validate_publication_chains(index)
        _validate_tag_sets(index)
        yield required_sources, required_families, index


def _index_publication_dependencies(index: sqlite3.Connection, record: _Record, /) -> None:
    if record.record_type == "artifact_revision":
        index.execute(
            "INSERT OR IGNORE INTO publication_nodes (identity) VALUES (?)",
            (_identity_key({"target_" + field: value for field, value in record.identity.items()}),),
        )
        return
    if record.record_type != "artifact_publication":
        return
    target = _identity_key(record.identity)
    source = _identity_key({
        "target_" + field: record.payload["source_" + field]
        for field in ("scope_id", "family", "artifact_id", "revision")
    })
    index.execute(
        "INSERT OR IGNORE INTO publication_edges (target, source, digest) VALUES (?, ?, ?)",
        (target, source, record.payload["content_digest"]),
    )


def _validate_publication_chains(index: sqlite3.Connection, /) -> None:
    if (
        index.execute(
            "SELECT 1 FROM publication_edges AS edge JOIN publication_edges AS parent ON edge.source = parent.target "
            "WHERE edge.digest != parent.digest LIMIT 1"
        ).fetchone()
        is not None
    ):
        raise BundleFormatError("publication chain has inconsistent content digests")
    while pending := index.execute("SELECT target FROM publication_edges WHERE state = 0 LIMIT 1").fetchone():
        current = pending[0]
        while edge := index.execute(
            "SELECT source, state FROM publication_edges WHERE target = ?", (current,)
        ).fetchone():
            if edge[1] == 1:
                raise BundleFormatError("publication chain contains a cycle")
            if edge[1] == 2:
                break
            index.execute("UPDATE publication_edges SET state = 1 WHERE target = ?", (current,))
            current = edge[0]
        index.execute("UPDATE publication_edges SET state = 2 WHERE state = 1")


async def _validate_target_publications(connection: AsyncConnection, index: sqlite3.Connection, /) -> bool:
    table = ARTIFACT_PUBLICATIONS_TABLE
    fields = _SPECS["artifact_publication"].identity
    pending = index.execute("SELECT identity FROM publication_nodes ORDER BY identity")
    while batch := pending.fetchmany(100):
        identities = [json.loads(row[0]) for row in batch]
        rows = (
            await connection.execute(
                select(table).where(
                    tuple_(*(table.c[field] for field in fields)).in_([
                        tuple(identity[field] for field in fields) for identity in identities
                    ])
                )
            )
        ).mappings()
        for row in rows:
            target = _identity_key({field: row[field] for field in fields})
            if index.execute("SELECT 1 FROM publication_edges WHERE target = ?", (target,)).fetchone() is None:
                return False
    return True


def _index_tag_set(index: sqlite3.Connection, record: _Record, /) -> None:
    if record.record_type != "artifact_tag":
        return
    target = _identity_key({field: value for field, value in record.identity.items() if field != "tag_key"})
    index.execute(
        "INSERT OR IGNORE INTO tag_labels (target, tag_key, label) VALUES (?, ?, ?)",
        (target, record.identity["tag_key"], record.payload["tag"]),
    )
    index.execute(
        "INSERT OR IGNORE INTO identities (record_type, identity) VALUES ('artifact_tag_target', ?)", (target,)
    )


def _validate_tag_sets(index: sqlite3.Connection, /) -> None:
    current: str | None = None
    labels: list[str] = []
    for target, label in index.execute("SELECT target, label FROM tag_labels ORDER BY target, tag_key"):
        if current != target:
            current = target
            labels.clear()
        labels.append(label)
        try:
            normalize_tags(tuple(labels))
        except InvalidBaseAccessRequestError as error:
            raise BundleFormatError("artifact tag set has invalid labels") from error


async def _validate_target_tag_sets(connection: AsyncConnection, index: sqlite3.Connection, /) -> bool:
    table = ARTIFACT_TAGS_TABLE
    fields = tuple(field for field in _SPECS["artifact_tag"].identity if field != "tag_key")
    pending = index.execute(
        "SELECT identity FROM identities WHERE record_type = 'artifact_tag_target' ORDER BY identity"
    )
    while batch := pending.fetchmany(100):
        identities = [json.loads(row[0]) for row in batch]
        rows = (
            await connection.execute(
                select(table).where(
                    tuple_(*(table.c[field] for field in fields)).in_([
                        tuple(identity[field] for field in fields) for identity in identities
                    ])
                )
            )
        ).mappings()
        for row in rows:
            record = _record_from_row("artifact_tag", cast(Mapping[str, Any], row))
            try:
                _validate_record_values(record)
            except BundleFormatError:
                return False
            _index_tag_set(index, record)
    try:
        _validate_tag_sets(index)
    except BundleFormatError:
        return False
    return True


def _validate_observation_record(record: _Record, index: sqlite3.Connection, /) -> None:
    if record.record_type != "source":
        return
    observation = _source_observation(record)
    if observation is None:
        return
    identity = {"definition_name": observation.source_type, "definition_version": observation.definition_version}
    document = index.execute(
        "SELECT document FROM identities WHERE record_type = 'source_definition' AND identity = ?",
        (_identity_key(identity),),
    ).fetchone()
    if document is None:
        raise BundleFormatError("observation references missing Source definition")
    manifest = _source_definition(_parse_record(json.loads(document[0])))
    try:
        validate_source_observation(observation, manifest)
    except (SourceError, ValueError) as error:
        raise BundleFormatError("Source observation does not match its definition manifest") from error


def _validate_candidate_record(
    record: _Record,
    index: sqlite3.Connection,
    decoder: Callable[[Mapping[str, Any]], object] | None,
) -> None:
    if decoder is None or record.record_type not in {"candidate_version", "candidate_head"}:
        return
    version = record
    if record.record_type == "candidate_head":
        identity = {**record.identity, "version": record.payload["version"]}
        document = index.execute(
            "SELECT document FROM identities WHERE record_type = 'candidate_version' AND identity = ?",
            (_identity_key(identity),),
        ).fetchone()
        if document is None:
            raise BundleFormatError("candidate head references missing version")
        version = _parse_record(json.loads(document[0]))
    values = {
        **_row_values(version),
        "status": "pending",
        "result_family": None,
        "result_artifact_id": None,
        "result_revision": None,
        "decision_reason": None,
    }
    if record.record_type == "candidate_head":
        values.update(_row_values(record))
    try:
        decoder(values)
    except (InvalidStoredPayloadError, ValueError) as error:
        raise BundleFormatError("Candidate proposal or envelope does not match the target decoder") from error


def _validate_record_dependencies(  # noqa: C901 - logical record kinds have distinct dependency edges.
    record: _Record,
    contains: Callable[[str, Mapping[str, object]], bool],
    /,
) -> None:
    payload = record.payload
    identity = record.identity
    scope_field = _SPECS[record.record_type].scope_field
    if scope_field is None:
        return
    scope = identity.get(scope_field, payload.get(scope_field))
    if not isinstance(scope, str):
        raise BundleFormatError("record has invalid scope identity")
    if record.record_type != "scope" and not contains("scope", {"scope_id": scope}):
        raise BundleFormatError("record references missing scope")
    if record.record_type == "scope":
        parent = payload["parent_scope_id"]
        if parent is not None and not contains("scope", {"scope_id": parent}):
            raise BundleFormatError("scope references missing parent")
    elif record.record_type == "scope_context_reference":
        if not contains("scope", {"scope_id": identity["referenced_scope_id"]}):
            raise BundleFormatError("scope context references missing scope")
    elif record.record_type == "source":
        if not contains("source_journal_head", {"scope_id": scope}):
            raise BundleFormatError("source has no journal head")
        observation = _source_observation(record)
        if observation is not None and not contains(
            "source_definition_fingerprint",
            {
                "definition_name": observation.source_type,
                "definition_version": observation.definition_version,
                "fingerprint": observation.definition_fingerprint,
            },
        ):
            raise BundleFormatError("observation references missing or mismatched Source definition")
    elif record.record_type == "source_evidence_binding":
        if not contains(
            "source",
            {"scope_id": scope, "source_type": identity["source_type"], "source_id": identity["source_id"]},
        ):
            raise BundleFormatError("Source evidence binding references missing Source")
        fingerprint = payload["manifest_fingerprint"]
        if fingerprint is not None and not contains(
            "source_definition_fingerprint",
            {
                "definition_name": payload["definition_name"],
                "definition_version": payload["definition_version"],
                "fingerprint": fingerprint,
            },
        ):
            raise BundleFormatError("Source evidence binding references missing Source definition")
    elif record.record_type == "atomic_memory_evidence_history":
        if not contains(
            "artifact_revision",
            {
                "scope_id": scope,
                "family": "atomic-memory",
                "artifact_id": identity["artifact_id"],
                "revision": identity["revision"],
            },
        ):
            raise BundleFormatError("Atomic Memory evidence references missing exact Artifact revision")
        for source in _evidence_history_value(record):
            if not contains("source", {"scope_id": scope, **source.source_ref.model_dump()}):
                raise BundleFormatError("Atomic Memory evidence references missing Source")
            fingerprint = source.manifest_fingerprint
            if fingerprint is not None and not contains(
                "source_definition_fingerprint",
                {
                    "definition_name": source.definition_name,
                    "definition_version": source.definition_version,
                    "fingerprint": fingerprint,
                },
            ):
                raise BundleFormatError("Atomic Memory evidence references missing Source definition")
    elif record.record_type in {"recurrence_match", "recurrence_observation"}:
        value = _recurrence_value(record)
        if not contains(
            "source_position",
            {
                "scope_id": scope,
                **value.task_outcome_ref.model_dump(),
                "position": value.task_outcome_position,
            },
        ):
            raise BundleFormatError("recurrence references missing or mismatched Source")
        if isinstance(value, RecurrenceMatch):
            refs = value.candidate_refs
        else:
            refs = (value.artifact_ref,) if value.handoff_ref is None else (value.artifact_ref, value.handoff_ref)
            if value.handoff_receipt_ref is not None and not contains(
                "source", {"scope_id": scope, **value.handoff_receipt_ref.model_dump()}
            ):
                raise BundleFormatError("recurrence references missing receipt Source")
            if value.recurrence_match_digest is not None and not contains(
                "recurrence_match_digest", {"scope_id": scope, "match_key": value.recurrence_match_digest}
            ):
                raise BundleFormatError("recurrence references missing frozen match")
        for ref in refs:
            if not contains("artifact_revision", {"scope_id": scope, **ref.model_dump()}):
                raise BundleFormatError("recurrence references missing exact Artifact revision")
    elif record.record_type == "artifact_revision":
        restored = payload["restored_from_revision"]
        if restored is not None and not contains("artifact_revision", {**identity, "revision": restored}):
            raise BundleFormatError("Artifact rollback references missing revision")
        if identity["family"] == "topic-memory" and not contains("topic_memory_publication", identity):
            raise BundleFormatError("Topic Memory revision has no publication metadata")
    elif record.record_type == "topic_memory_publication":
        if not contains("artifact_revision", identity):
            raise BundleFormatError("topic memory publication references missing revision")
    elif record.record_type == "profile_policy":
        candidate_id = payload["pending_candidate_id"]
        if candidate_id is not None and not contains(
            "candidate_head", {"scope_id": scope, "candidate_id": candidate_id}
        ):
            raise BundleFormatError("profile policy references missing candidate")
    elif record.record_type == "artifact_tag":
        if not contains(
            "artifact_head",
            {"scope_id": scope, "family": identity["family"], "artifact_id": identity["artifact_id"]},
        ):
            raise BundleFormatError("artifact tag references missing artifact head")
        if identity["target_type"] == "memory_entry" and not contains(
            "memory_entry_target",
            {"scope_id": scope, "memory_artifact_id": identity["artifact_id"], "entry_id": identity["target_id"]},
        ):
            raise BundleFormatError("artifact tag references missing memory entry")
    elif record.record_type == "artifact_source_locator":
        if not contains("artifact_lineage_source", identity):
            raise BundleFormatError("Source locator references missing lineage")
    elif record.record_type == "artifact_lineage_source":
        if not contains(
            "artifact_revision",
            {
                "scope_id": scope,
                "family": identity["family"],
                "artifact_id": identity["artifact_id"],
                "revision": identity["revision"],
            },
        ):
            raise BundleFormatError("artifact lineage references missing revision")
        if not contains(
            "source",
            {"scope_id": scope, "source_type": payload["source_type"], "source_id": payload["source_id"]},
        ):
            raise BundleFormatError("artifact lineage references missing source")
    elif record.record_type == "artifact_lineage_artifact":
        if not contains(
            "artifact_revision",
            {
                "scope_id": scope,
                "family": identity["family"],
                "artifact_id": identity["artifact_id"],
                "revision": identity["revision"],
            },
        ):
            raise BundleFormatError("artifact lineage references missing revision")
        if not contains(
            "artifact_revision",
            {
                "scope_id": scope,
                "family": payload["upstream_family"],
                "artifact_id": payload["upstream_artifact_id"],
                "revision": payload["upstream_revision"],
            },
        ):
            raise BundleFormatError("record references missing artifact revision")
    elif record.record_type == "artifact_publication":
        if not contains("scope", {"scope_id": payload["source_scope_id"]}):
            raise BundleFormatError("Artifact publication references missing source scope")
        target_exists = contains(
            "artifact_revision",
            {
                "scope_id": identity["target_scope_id"],
                "family": identity["target_family"],
                "artifact_id": identity["target_artifact_id"],
                "revision": identity["target_revision"],
            },
        )
        source_exists = contains(
            "artifact_revision",
            {
                "scope_id": payload["source_scope_id"],
                "family": payload["source_family"],
                "artifact_id": payload["source_artifact_id"],
                "revision": payload["source_revision"],
            },
        )
        if not target_exists or not source_exists:
            raise BundleFormatError("Artifact publication references missing revision")
    elif record.record_type == "memory_entry_version":
        if not contains(
            "artifact_revision",
            {
                "scope_id": scope,
                "family": payload["family"],
                "artifact_id": identity["memory_artifact_id"],
                "revision": payload["created_in_revision"],
            },
        ):
            raise BundleFormatError("record references missing artifact revision")
        previous = payload["previous_version_id"]
        if previous is not None and not contains(
            "memory_entry_version",
            {
                "scope_id": scope,
                "memory_artifact_id": identity["memory_artifact_id"],
                "entry_version_id": previous,
            },
        ):
            raise BundleFormatError("memory version references missing previous version")
    elif record.record_type == "artifact_handle":
        if not contains(
            "artifact_revision",
            {
                "scope_id": scope,
                "family": identity["family"],
                "artifact_id": payload["artifact_id"],
                "revision": payload["revision"],
            },
        ):
            raise BundleFormatError("artifact handle references missing revision")
    elif record.record_type == "artifact_head":
        if not contains("artifact_revision", {**identity, "revision": payload["revision"]}):
            raise BundleFormatError("artifact head references missing revision")
        if payload["replacement_artifact_id"] is not None and not contains(
            "artifact_head", {**identity, "artifact_id": payload["replacement_artifact_id"]}
        ):
            raise BundleFormatError("artifact head references missing replacement")
        if payload["merged_into_id"] is not None and not contains(
            "artifact_head", {**identity, "artifact_id": payload["merged_into_id"]}
        ):
            raise BundleFormatError("artifact head references missing merge result")
    elif record.record_type == "memory_entry_head":
        if not contains(
            "memory_entry_version",
            {
                "scope_id": scope,
                "memory_artifact_id": identity["memory_artifact_id"],
                "entry_version_id": payload["entry_version_id"],
            },
        ):
            raise BundleFormatError("memory head references missing entry version")
        if not contains(
            "artifact_revision",
            {
                "scope_id": scope,
                "family": payload["family"],
                "artifact_id": identity["memory_artifact_id"],
                "revision": payload["head_revision"],
            },
        ):
            raise BundleFormatError("memory head references missing artifact revision")
    elif record.record_type == "candidate_version":
        target_family = payload["target_family"]
        if target_family is not None and not contains(
            "artifact_revision",
            {
                "scope_id": scope,
                "family": target_family,
                "artifact_id": payload["target_artifact_id"],
                "revision": payload["target_revision"],
            },
        ):
            raise BundleFormatError("candidate references missing target revision")
    elif record.record_type == "candidate_head":
        if not contains(
            "candidate_version",
            {"scope_id": scope, "candidate_id": identity["candidate_id"], "version": payload["version"]},
        ):
            raise BundleFormatError("candidate head references missing version")
        if not contains(
            "candidate_version_family",
            {**identity, "version": payload["version"], "family": payload["family"]},
        ):
            raise BundleFormatError("candidate head family does not match version")
        result_family = payload["result_family"]
        if result_family is not None and not contains(
            "artifact_revision",
            {
                "scope_id": scope,
                "family": result_family,
                "artifact_id": payload["result_artifact_id"],
                "revision": payload["result_revision"],
            },
        ):
            raise BundleFormatError("candidate head references missing result revision")
    _validate_embedded_references(record, contains)


def _dependency_metadata(source: Path, /) -> tuple[dict[str, int], dict[tuple[str, str], tuple[str, int, int, int]]]:
    heads: dict[str, int] = {}
    packages: dict[tuple[str, str], tuple[str, int, int, int]] = {}
    scopes: list[_Record] = []
    for record in _iter_records(source):
        if record.record_type == "scope":
            scopes.append(record)
        if record.record_type == "source_journal_head":
            heads[str(record.identity["scope_id"])] = int(record.payload["position"])
        if record.record_type != "skill_package":
            continue
        try:
            snapshot = capture_skill_archive(cast(bytes, _database_value(record.payload["archive_bytes"])))
        except SkillPackageError as error:
            raise BundleFormatError("Skill package archive is invalid") from error
        expected = {
            "tree_digest": record.identity["tree_digest"],
            **{
                field: record.payload[field]
                for field in ("archive_digest", "file_count", "uncompressed_size", "archive_size")
            },
        }
        if snapshot.reference.model_dump() != expected or snapshot.manifest_bytes != _database_value(
            record.payload["manifest"]
        ):
            raise BundleFormatError("Skill package bytes do not match metadata")
        packages[(str(record.identity["scope_id"]), str(record.identity["tree_digest"]))] = (
            snapshot.reference.archive_digest,
            snapshot.reference.file_count,
            snapshot.reference.uncompressed_size,
            snapshot.reference.archive_size,
        )
    _ordered_scope_records(scopes)
    return heads, packages


def _validate_skill_package_dependency(
    record: _Record, packages: Mapping[tuple[str, str], tuple[str, int, int, int]], /
) -> None:
    if record.record_type == "artifact_revision" and record.identity["family"] == "skill":
        content = _decoded_bytes_json(record.payload["content"], "Skill content")
    elif record.record_type == "candidate_version" and record.payload["family"] == "skill":
        try:
            proposal, _audit = decode_candidate_proposal_envelope(
                cast(bytes, _database_value(record.payload["proposal"]))
            )
        except InvalidStoredPayloadError as error:
            raise BundleFormatError("Candidate proposal envelope is invalid") from error
        content = json.loads(proposal)
    else:
        return
    package = content.get("package") if isinstance(content, dict) else None
    if package is None:
        return
    if not isinstance(package, dict):
        raise BundleFormatError("Skill package reference is invalid")
    typed_package = cast(dict[str, object], package)
    tree_digest = typed_package.get("tree_digest")
    archive_digest = typed_package.get("archive_digest")
    sizes = (
        typed_package.get("file_count"),
        typed_package.get("uncompressed_size"),
        typed_package.get("archive_size"),
    )
    if (
        not isinstance(tree_digest, str)
        or not isinstance(archive_digest, str)
        or any(isinstance(value, bool) or not isinstance(value, int) for value in sizes)
    ):
        raise BundleFormatError("Skill package reference is invalid")
    expected = (archive_digest, cast(int, sizes[0]), cast(int, sizes[1]), cast(int, sizes[2]))
    key = (str(record.identity["scope_id"]), tree_digest)
    if packages.get(key) != expected:
        raise BundleFormatError("Skill artifact references missing or mismatched package")


def _decoded_bytes_json(value: object, name: str, /) -> object:
    encoded = cast(dict[str, object], value).get("base64") if isinstance(value, dict) else None
    if not isinstance(encoded, str):
        raise BundleFormatError(f"{name} is not encoded bytes")
    try:
        return json.loads(base64.b64decode(encoded, validate=True), parse_constant=_reject_json_constant)
    except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise BundleFormatError(f"{name} is not valid JSON") from error


def _unique_identities(record: _Record, /) -> Iterator[dict[str, Any]]:
    """Yield physical uniqueness keys not already covered by the logical identity."""

    spec = _SPECS[record.record_type]
    values = {**record.identity, **record.payload}
    constraints = (
        constraint.columns
        for constraint in spec.table.constraints
        if isinstance(constraint, PrimaryKeyConstraint | UniqueConstraint)
    )
    indexes = (index.columns for index in spec.table.indexes if index.unique)
    for columns in (*constraints, *indexes):
        fields = tuple(column.name for column in columns)
        if set(spec.identity).issubset(fields):
            continue
        identity = {field: values[field] for field in fields}
        # SQL unique keys permit multiple rows when a participating value is NULL.
        if all(value is not None for value in identity.values()):
            yield identity


@contextmanager
def _identity_index(source: Path, /) -> Iterator[sqlite3.Connection]:
    index_path = _temporary_path(Path(tempfile.gettempdir()), suffix=".identities.sqlite3")
    connection: sqlite3.Connection | None = None
    try:
        connection = sqlite3.connect(index_path)
        connection.execute(
            "CREATE TABLE identities (record_type TEXT NOT NULL, identity TEXT NOT NULL, document BLOB, "
            "PRIMARY KEY (record_type, identity))"
        )
        connection.execute(
            "CREATE TABLE publication_edges (target TEXT PRIMARY KEY, source TEXT NOT NULL, digest TEXT NOT NULL, "
            "state INTEGER NOT NULL DEFAULT 0)"
        )
        connection.execute("CREATE INDEX publication_edges_state ON publication_edges(state, target)")
        connection.execute("CREATE TABLE publication_nodes (identity TEXT PRIMARY KEY)")
        connection.execute(
            "CREATE TABLE tag_labels (target TEXT NOT NULL, tag_key TEXT NOT NULL, label TEXT NOT NULL, "
            "PRIMARY KEY (target, tag_key))"
        )
        for record in _iter_records(source):
            try:
                connection.execute(
                    "INSERT INTO identities (record_type, identity, document) VALUES (?, ?, ?)",
                    (
                        record.record_type,
                        _identity_key(record.identity),
                        _canonical_json(_record_document(record))
                        if record.record_type in {"candidate_version", "source_definition"}
                        else None,
                    ),
                )
                for identity in _unique_identities(record):
                    connection.execute(
                        "INSERT INTO identities (record_type, identity) VALUES (?, ?)",
                        (record.record_type + ":unique", _identity_key(identity)),
                    )
            except sqlite3.IntegrityError as error:
                raise BundleFormatError("bundle contains duplicate immutable or unique identity") from error
            _index_publication_dependencies(connection, record)
            _index_tag_set(connection, record)
            if record.record_type == "candidate_version":
                connection.execute(
                    "INSERT INTO identities (record_type, identity) VALUES (?, ?)",
                    (
                        "candidate_version_family",
                        _identity_key({**record.identity, "family": record.payload["family"]}),
                    ),
                )
            if record.record_type == "source":
                connection.execute(
                    "INSERT INTO identities (record_type, identity) VALUES (?, ?)",
                    (
                        "source_position",
                        _identity_key({
                            **record.identity,
                            "position": record.payload["journal_position"],
                        }),
                    ),
                )
            if record.record_type == "recurrence_match":
                connection.execute(
                    "INSERT INTO identities (record_type, identity) VALUES (?, ?)",
                    (
                        "recurrence_match_digest",
                        _identity_key({
                            "scope_id": record.identity["scope_id"],
                            "match_key": record.payload["match_key"],
                        }),
                    ),
                )
            if record.record_type == "source_definition":
                connection.execute(
                    "INSERT INTO identities (record_type, identity) VALUES (?, ?)",
                    (
                        "source_definition_fingerprint",
                        _identity_key({**record.identity, "fingerprint": record.payload["fingerprint"]}),
                    ),
                )
            if record.record_type == "memory_entry_version":
                # Tags survive retirement; inactive entries no longer have a
                # search projection but retain their authoritative versions.
                connection.execute(
                    "INSERT OR IGNORE INTO identities (record_type, identity) VALUES (?, ?)",
                    (
                        "memory_entry_target",
                        _identity_key({
                            "scope_id": record.identity["scope_id"],
                            "memory_artifact_id": record.identity["memory_artifact_id"],
                            "entry_id": record.payload["entry_id"],
                        }),
                    ),
                )
        connection.commit()

        yield connection
    finally:
        if connection is not None:
            connection.close()
        index_path.unlink(missing_ok=True)


def _validate_embedded_references(
    record: _Record,
    contains: Callable[[str, Mapping[str, object]], bool],
) -> None:
    if record.record_type not in {"memory_entry_version", "candidate_version"}:
        return
    scope_id = record.identity["scope_id"]
    for reference in _reference_items(record.payload["source_refs"], "source"):
        if not contains(
            "source",
            {
                "scope_id": scope_id,
                "source_type": reference["source_type"],
                "source_id": reference["source_id"],
            },
        ):
            raise BundleFormatError("record references missing source")
    for reference in _reference_items(record.payload["artifact_refs"], "artifact"):
        if not contains(
            "artifact_revision",
            {
                "scope_id": scope_id,
                "family": reference["family"],
                "artifact_id": reference["artifact_id"],
                "revision": reference["revision"],
            },
        ):
            raise BundleFormatError("record references missing artifact revision")


def _reference_items(value: object, kind: Literal["source", "artifact"], /) -> tuple[Mapping[str, object], ...]:
    encoded = cast(dict[str, object], value).get("base64") if isinstance(value, dict) else None
    if not isinstance(value, dict) or set(value) != {"base64"} or not isinstance(encoded, str):
        raise BundleFormatError(f"{kind} references are not encoded bytes")
    try:
        decoded = json.loads(base64.b64decode(encoded, validate=True), parse_constant=_reject_json_constant)
    except (ValueError, json.JSONDecodeError) as error:
        raise BundleFormatError(f"{kind} references are not valid JSON") from error
    if not isinstance(decoded, list):
        raise BundleFormatError(f"{kind} references must be an array")
    fields = {"source_type", "source_id"} if kind == "source" else {"family", "artifact_id", "revision"}
    references: list[Mapping[str, object]] = []
    for item in decoded:
        if kind == "source":
            if not isinstance(item, dict) or set(item) not in (fields, fields | {"locator"}):
                raise BundleFormatError("source reference has invalid fields")
            try:
                SourceRef.model_validate(item, strict=True)
            except ValidationError as error:
                raise BundleFormatError("source reference has invalid domain values") from error
            references.append(cast(Mapping[str, object], item))
            continue
        if (
            not isinstance(item, dict)
            or set(item) != fields
            or any(isinstance(field, bool) or not isinstance(field, str | int) for field in item.values())
        ):
            raise BundleFormatError(f"{kind} reference has invalid fields")
        references.append(cast(Mapping[str, object], item))
    return tuple(references)


def _required_artifact_families(records: Iterable[_Record]) -> set[str]:
    families: set[str] = set()
    for record in records:
        identity = record.identity
        payload = record.payload
        if record.record_type in {
            "artifact_revision",
            "artifact_handle",
            "artifact_lineage_source",
            "artifact_source_locator",
            "artifact_lineage_artifact",
            "artifact_head",
            "topic_memory_publication",
            "artifact_tag",
        }:
            families.add(str(identity["family"]))
        if record.record_type == "profile_policy":
            families.add("profile")
        if record.record_type == "artifact_publication":
            families.update((str(identity["target_family"]), str(payload["source_family"])))
        if record.record_type in {"artifact_lineage_artifact", "candidate_version", "candidate_head"}:
            for field in ("upstream_family", "target_family", "result_family"):
                value = payload.get(field)
                if value is not None:
                    families.add(str(value))
        if record.record_type in {"memory_entry_version", "memory_entry_head", "candidate_version", "candidate_head"}:
            families.add(str(payload["family"]))
    return families


def _validate_scopes(scopes: Iterable[str]) -> tuple[str, ...]:
    if isinstance(scopes, str):
        raise BundleFormatError("scopes must be an iterable of scope IDs")
    try:
        values = tuple(scopes)
    except TypeError as error:
        raise BundleFormatError("scopes must be an iterable of scope IDs") from error
    if not values or any(not isinstance(scope, str) or not scope.strip() or scope != scope.strip() for scope in values):
        raise BundleFormatError("scopes must contain at least one non-empty trimmed scope ID")
    selected = tuple(sorted(set(values)))
    return selected


def _identity_key(identity: Mapping[str, object], /) -> str:
    return _canonical_json(identity).decode("utf-8")


class _DigestAccumulator:
    """Incrementally hash a deterministic ordered record-digest sequence."""

    def __init__(self) -> None:
        self._hash = hashlib.sha256()
        self._first = True

    def add(self, digest: str, /) -> None:
        if not self._first:
            self._hash.update(b"\n")
        self._hash.update(digest.encode("ascii"))
        self._first = False

    def value(self) -> str:
        return _SHA256 + self._hash.hexdigest()


def _temporary_path(directory: Path, /, *, suffix: str) -> Path:
    with tempfile.NamedTemporaryFile(
        prefix=".powercontext-archive-", suffix=suffix, dir=directory, delete=False
    ) as handle:
        return Path(handle.name)


def _zip_info(name: str, compression: int, /) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    info.compress_type = compression
    info.external_attr = 0o600 << 16
    return info


def _digest(value: object) -> str:
    return _SHA256 + hashlib.sha256(_canonical_json(value)).hexdigest()


def _canonical_json(value: object) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _json_value(value: object) -> Any:
    if isinstance(value, bytes | bytearray | memoryview):
        return {"base64": base64.b64encode(bytes(value)).decode("ascii")}
    if isinstance(value, datetime | date):
        return value.isoformat()
    return value


def _database_value(value: object, column: Any | None = None) -> object:
    encoded = cast(dict[str, object], value).get("base64") if isinstance(value, dict) else None
    if isinstance(value, dict) and set(value) == {"base64"} and isinstance(encoded, str):
        try:
            return base64.b64decode(encoded, validate=True)
        except ValueError as error:
            raise BundleFormatError("invalid base64 column value") from error
    if isinstance(value, str) and column is not None and isinstance(column.type, DateTime):
        try:
            return datetime.fromisoformat(value)
        except ValueError as error:
            raise BundleFormatError("invalid datetime column value") from error
    return value


def _valid_digest(value: object) -> bool:
    return isinstance(value, str) and _HEX_DIGEST.fullmatch(value) is not None


def _reject_json_constant(_value: str, /) -> None:
    raise BundleFormatError("bundle contains a non-standard JSON value")


def _report_progress(
    observer: ProgressObserver | None,
    phase: Literal["export", "inspect", "validate", "target", "restore", "projections"],
    processed: int,
    total: int | None,
    *,
    force: bool = False,
) -> None:
    if observer is not None and (force or processed in {0, 1, total} or processed % 1_000 == 0):
        observer(BundleProgress(phase=phase, processed=processed, total=total))


def _producer_version() -> str:
    try:
        return version("powercontext")
    except PackageNotFoundError:
        return "unknown"
