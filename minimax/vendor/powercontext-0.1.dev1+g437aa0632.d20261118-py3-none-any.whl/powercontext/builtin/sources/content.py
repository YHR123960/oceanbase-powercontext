# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""A neutral captured-text Source for runtime integrations."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, JsonValue, field_validator

from powercontext.artifacts import ArtifactRef
from powercontext.limits import MAX_ARTIFACT_FAMILY_LENGTH
from powercontext.sources import TEXT_EVIDENCE_PROJECTION_KEY, AdapterSourceDefinition, TextEvidenceV1
from powercontext.sources.models import Source, SourceMaterialization

CONTENT_SOURCE_NAME = "content"
WORKING_NOTE_SOURCE_KIND = "working_note"
NonEmptyText = Annotated[str, Field(min_length=1)]


class ContentCapture(BaseModel):
    """Text supplied by an integration with a caller-stable identity."""

    source_id: NonEmptyText
    content: NonEmptyText
    metadata: dict[str, JsonValue] = Field(default_factory=dict)

    @field_validator("source_id", "content")
    @classmethod
    def reject_blank_text(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("content text must not be blank")  # noqa: TRY003
        return value


class ContentSourceTarget(BaseModel):
    """Exact Artifact revision to which one system Source is bound."""

    scope_id: str
    family: Annotated[str, Field(min_length=1, max_length=MAX_ARTIFACT_FAMILY_LENGTH)]
    artifact_id: str
    revision: Annotated[int, Field(ge=1)] = 1

    @field_validator("family")
    @classmethod
    def require_canonical_family(cls, value: str) -> str:
        if value != value.strip():
            raise ValueError("family must not contain leading or trailing whitespace")  # noqa: TRY003
        return value


class ArtifactRestorationWrite(BaseModel):
    """Exact content source and committed result of one restoration write."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    before_ref: ArtifactRef
    content_from_ref: ArtifactRef
    after_ref: ArtifactRef
    lifecycle_state: Literal["active", "retired"]


class ArtifactRestorationOutcome(BaseModel):
    """One successful restoration group retained with its primary revision."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    operation: Literal["restore", "undo_merge"]
    target: ArtifactRef
    writes: tuple[ArtifactRestorationWrite, ...]
    undo_merge_results: tuple[ArtifactRef, ...]


class ContentSourceInternal(BaseModel):
    """Server-owned Source purpose data never exposed by the base REST API."""

    role: Literal["lineage_only"]
    operation: Literal["artifact_create", "artifact_replace", "artifact_restore", "artifact_undo_merge"]
    target: ContentSourceTarget
    restoration_outcome: ArtifactRestorationOutcome | None = None


class ContentSource(Source):
    """Captured content that can be used as Artifact evidence."""

    content: str
    metadata: dict[str, JsonValue] = Field(default_factory=dict)
    working_note: bool = False
    wire_content: JsonValue | None = None
    wire_content_present: bool = False
    internal: ContentSourceInternal | None = None
    # Set only by the Work acknowledgement writer, never from capture metadata.
    handoff_receipt: bool = False

    @property
    def is_working_note(self) -> bool:
        """Whether this captured Source is explicitly session-local work state."""

        return self.working_note

    def is_working_note_active(self, *, now: datetime | None = None) -> bool:
        """Whether a Working Note remains eligible for an explicit consumer."""

        if not self.is_working_note:
            return False
        expires_at = self.metadata.get("expires_at")
        if expires_at is None:
            return True
        if not isinstance(expires_at, str):
            return False
        try:
            expiry = datetime.fromisoformat(expires_at)
        except ValueError:
            return False
        if expiry.tzinfo is None or expiry.utcoffset() is None:
            return False
        return expiry > (datetime.now(UTC) if now is None else now)


class ContentSourceAdapter:
    """Resolve and read the runtime's built-in captured-text Source."""

    input_class = ContentCapture
    name = CONTENT_SOURCE_NAME
    source_class = ContentSource

    async def resolve(self, value: ContentCapture, /) -> ContentSource:
        return ContentSource(
            name=value.source_id,
            materialization=SourceMaterialization.CAPTURED,
            content=value.content,
            metadata=value.metadata,
        )

    async def read(self, source: ContentSource, /) -> ContentCapture:
        if not isinstance(source.content, str):
            raise TypeError("system Content Sources cannot be read as integration captures")  # noqa: TRY003
        return ContentCapture(
            source_id=source.name,
            content=source.content,
            metadata=source.metadata,
        )


class ContentTextEvidenceProjection:
    """Expose captured text without coupling consumers to ``ContentSource``."""

    name = TEXT_EVIDENCE_PROJECTION_KEY.name
    version = TEXT_EVIDENCE_PROJECTION_KEY.version
    source_class = ContentSource
    output_class: type[BaseModel] = TextEvidenceV1

    def project(self, source: ContentSource, /) -> TextEvidenceV1:
        return TextEvidenceV1(
            source_type=CONTENT_SOURCE_NAME,
            source_id=source.name,
            content=source.content,
            metadata=source.metadata,
        )


CONTENT_SOURCE_ADAPTER = ContentSourceAdapter()
CONTENT_SOURCE_DEFINITION = AdapterSourceDefinition(
    CONTENT_SOURCE_ADAPTER,
    projections=(ContentTextEvidenceProjection(),),
)
