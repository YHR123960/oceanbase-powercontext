# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Scoped product statistics values."""

from __future__ import annotations

from datetime import date, datetime
from enum import StrEnum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from powercontext.artifacts import ArtifactRef
from powercontext.builtin.inference import TokenEstimatorProfile
from powercontext.builtin.scope.models import ScopeSelection


class StatisticsPeriod(StrEnum):
    """Bounded UTC periods supported by the product statistics contract."""

    TODAY = "today"
    SEVEN_DAYS = "7d"
    THIRTY_DAYS = "30d"


class ModelUsageOperation(StrEnum):
    """Stable model-operation categories exposed by statistics."""

    GENERATION = "generation"
    EMBEDDING = "embedding"


class ModelUsagePurpose(StrEnum):
    """Business purpose responsible for one model capability call."""

    MEMORY_EXTRACTION = "memory_extraction"
    MEMORY_INDEXING = "memory_indexing"
    MEMORY_RECALL = "memory_recall"
    EXPERIENCE_GENERATION = "experience_generation"
    SKILL_GENERATION = "skill_generation"
    HANDOFF_GENERATION = "handoff_generation"
    PROFILE_GENERATION = "profile_generation"
    PROMPT_GENERATION = "prompt_generation"
    TOPIC_MEMORY_GENERATION = "topic_memory_generation"
    TOPIC_MEMORY_RECALL = "topic_memory_recall"
    TOPIC_MEMORY_INDEXING = "topic_memory_indexing"


class FamilyCount(BaseModel):
    """Current Artifact count for one open family value."""

    family: str
    total: int = Field(ge=0)


class CandidateFamilyCount(BaseModel):
    """Current Candidate status counts for one family."""

    family: str
    total: int = Field(ge=0)
    pending: int = Field(ge=0)
    approved: int = Field(ge=0)
    rejected: int = Field(ge=0)


class MemoryKindCount(BaseModel):
    """Current Memory entry state counts for one open kind value."""

    kind: str
    total: int = Field(ge=0)
    active: int = Field(ge=0)
    inactive: int = Field(ge=0)


class SourceInventoryStatistics(BaseModel):
    """Current Source journal and Memory cursor positions."""

    total: int = Field(ge=0)
    memory_processed: int = Field(ge=0)
    memory_pending: int = Field(ge=0)


class ArtifactInventoryStatistics(BaseModel):
    """Current Artifact heads grouped by family."""

    total: int = Field(ge=0)
    by_family: tuple[FamilyCount, ...] = ()


class CandidateInventoryStatistics(BaseModel):
    """Current Candidate heads grouped by status and family."""

    total: int = Field(ge=0)
    pending: int = Field(ge=0)
    approved: int = Field(ge=0)
    rejected: int = Field(ge=0)
    by_family: tuple[CandidateFamilyCount, ...] = ()


class MemoryEntryInventoryStatistics(BaseModel):
    """Atomic Memory heads grouped by kind; inactive covers forgotten, merged and retired."""

    total: int = Field(ge=0)
    active: int = Field(ge=0)
    inactive: int = Field(ge=0)
    by_kind: tuple[MemoryKindCount, ...] = ()


class MemoryInventoryStatistics(BaseModel):
    """Current Memory-specific inventory."""

    entries: MemoryEntryInventoryStatistics


class InventoryStatistics(BaseModel):
    """Current product content inventory for one scope."""

    sources: SourceInventoryStatistics
    artifacts: ArtifactInventoryStatistics
    candidates: CandidateInventoryStatistics
    memory: MemoryInventoryStatistics


class ModelUsageValue(BaseModel):
    """Provider-reported usage for one model-operation category."""

    requests: int = Field(ge=0)
    input_tokens: int | None = Field(default=None, ge=0)
    output_tokens: int | None = Field(default=None, ge=0)


class ModelUsageStatistics(BaseModel):
    """Generation and embedding usage for one interval."""

    generation: ModelUsageValue
    embedding: ModelUsageValue


class ModelUsagePurposeBreakdown(BaseModel):
    """Generation and embedding usage attributed to one business purpose."""

    purpose: ModelUsagePurpose
    generation: ModelUsageValue
    embedding: ModelUsageValue


class ResolvedUsagePeriod(BaseModel):
    """Inclusive UTC dates selected by a period preset."""

    preset: StatisticsPeriod
    start_date: date
    end_date: date
    timezone: Literal["UTC"] = "UTC"


class ModelUsageDay(BaseModel):
    """One zero-filled UTC model-usage bucket."""

    date: date
    generation: ModelUsageValue
    embedding: ModelUsageValue
    by_purpose: tuple[ModelUsagePurposeBreakdown, ...]


class UsageStatistics(BaseModel):
    """Resolved period, totals, and daily model usage."""

    period: ResolvedUsagePeriod
    totals: ModelUsageStatistics
    by_purpose: tuple[ModelUsagePurposeBreakdown, ...]
    daily: tuple[ModelUsageDay, ...]


class RecallEffortMeasurement(BaseModel):
    """One content-free recall observation, ready for additive daily persistence.

    This internal measurement is not part of the statistics overview or any
    transport response. Its reason vocabulary excludes arbitrary query text.
    """

    model_config = ConfigDict(frozen=True, extra="forbid", strict=True)

    policy_id: str = Field(min_length=1, max_length=128)
    assessment: Literal[
        "sufficient",
        "no-content",
        "budget-floor",
        "rerank-enabled",
        "thin-candidates",
        "thin-families",
        "weak-top-1",
        "weak-lexical",
        "at-max-rounds",
        "expansion-failed",
    ]
    preparations: Literal[1] = 1
    rounds: int = Field(ge=1, le=3)
    expanded_preparations: int = Field(ge=0, le=1)
    admission_expansions: int = Field(ge=0, le=1)
    policy_floor_expansions: int = Field(ge=0, le=1)
    candidate_round_samples: int = Field(ge=1, le=3)
    candidates_assessed: int = Field(ge=0)
    final_candidate_pool: int = Field(ge=0)
    added_embeddings: int = Field(ge=0)
    added_generation_calls: int = Field(ge=0)
    truncated_items: int = Field(ge=0)
    dropped_items: int = Field(ge=0)
    dropped_below_min_bytes: int = Field(ge=0)
    dropped_no_fitting_truncation: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_accounting(self) -> RecallEffortMeasurement:
        if self.dropped_items != self.dropped_below_min_bytes + self.dropped_no_fitting_truncation:
            raise ValueError("recall effort drop subclasses must sum to dropped_items")  # noqa: TRY003
        if self.rounds != self.candidate_round_samples:
            raise ValueError("recall effort needs one candidate sample per committed round")  # noqa: TRY003
        if self.rounds != 1 + self.admission_expansions + self.policy_floor_expansions:
            raise ValueError("recall effort rounds must match committed expansions")  # noqa: TRY003
        if self.expanded_preparations != int(self.rounds > 1):
            raise ValueError("recall effort expanded preparation count must match rounds")  # noqa: TRY003
        return self


class RecallTokenMeasurement(BaseModel):
    """One successful context preparation measured with one estimator profile."""

    estimator: TokenEstimatorProfile
    ready: bool
    comparable: bool
    baseline_tokens: int = Field(ge=0)
    recalled_tokens: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_comparability(self) -> RecallTokenMeasurement:
        if self.comparable and not self.ready:
            raise ValueError("only ready context can be comparable")  # noqa: TRY003
        if not self.comparable and (self.baseline_tokens or self.recalled_tokens):
            raise ValueError("non-comparable context cannot contribute token estimates")  # noqa: TRY003
        return self


class RecallTokenValue(BaseModel):
    """Additive recall-token values for one interval."""

    preparations: int = Field(ge=0)
    ready_preparations: int = Field(ge=0)
    comparable_preparations: int = Field(ge=0)
    baseline_tokens: int = Field(ge=0)
    recalled_tokens: int = Field(ge=0)
    token_reduction: int

    @model_validator(mode="after")
    def validate_preparation_counts(self) -> RecallTokenValue:
        if self.comparable_preparations > self.ready_preparations:
            raise ValueError("comparable preparations cannot exceed ready preparations")  # noqa: TRY003
        if self.ready_preparations > self.preparations:
            raise ValueError("ready preparations cannot exceed total preparations")  # noqa: TRY003
        return self


class RecallTokenDay(RecallTokenValue):
    """One zero-filled UTC recall-token bucket."""

    date: date


class RecallTokenStatistics(BaseModel):
    """Estimated recall token reduction under one deployment-fixed profile."""

    period: ResolvedUsagePeriod
    estimator: TokenEstimatorProfile | None
    totals: RecallTokenValue
    daily: tuple[RecallTokenDay, ...]


MAX_RECURRENCE_TOP_REVISIONS = 20


class RecurrenceStreak(BaseModel):
    """One Experience revision's terminal ``recurred`` streak since its last ``avoided``."""

    artifact_ref: ArtifactRef
    signature_key: str
    terminal_recurred_streak: int = Field(ge=0)


class RecurrenceStatistics(BaseModel):
    """Derived recurrence readings for one Scope, read from an append-only ledger."""

    selected: int = Field(ge=0)
    recurred: int = Field(ge=0)
    avoided: int = Field(ge=0)
    unknown: int = Field(ge=0)
    unlinked_handoff_citations: int = Field(ge=0)
    needing_review: int = Field(ge=0)
    top_revisions: tuple[RecurrenceStreak, ...] = Field(max_length=MAX_RECURRENCE_TOP_REVISIONS)


class ProcessingObservation(BaseModel):
    """Durable invocation progress and a separately identified local scheduler sample."""

    binding: str
    family: str | None = None
    state: Literal["idle", "dirty", "pending", "acknowledged", "queued", "running", "retry_wait", "blocked"]
    observed_at: datetime
    scheduler_observed: bool = False
    reason: Literal[
        "unobserved",
        "waiting_schedule",
        "waiting_dispatch",
        "waiting_capacity",
        "executing",
        "retry_backoff",
        "policy_block",
        "idle",
    ] = "unobserved"
    requested_generation: int = Field(default=0, ge=0)
    handled_generation: int = Field(default=0, ge=0)
    dirty_generation: int = Field(default=0, ge=0)
    clean_generation: int = Field(default=0, ge=0)
    pending_since: datetime | None = None
    running_seconds: float | None = Field(default=None, ge=0)
    next_check_seconds: float | None = Field(default=None, ge=0)
    worker_id: str | None = None
    attempt_generation: int | None = Field(default=None, ge=0)
    retry_failures: int | None = Field(default=None, ge=0)
    block_code: str | None = None
    last_error_code: str | None = None
    last_error_stage: str | None = None
    last_error_at: datetime | None = None
    last_error_worker_id: str | None = None
    last_error_trace_id: str | None = None


class BootstrapDeliveryReading(BaseModel):
    """Current retained receipt states grouped by integration and preparation period."""

    integration: str
    state: Literal["pending", "injected", "skipped", "failed"]
    receipts: int = Field(ge=0)
    content_bytes: int = Field(ge=0)
    last_prepared_at: datetime


class BootstrapDeliveryStatistics(BaseModel):
    """Host-reported delivery does not establish model adoption or billing savings."""

    period: ResolvedUsagePeriod
    retention_days: int = 30
    actual_adoption: Literal["unobserved"] = "unobserved"
    by_integration: tuple[BootstrapDeliveryReading, ...] = ()


class ScopeStatistics(BaseModel):
    """Statistics retained for one Scope inside a resolved selection."""

    scope_id: str
    inventory: InventoryStatistics
    usage: UsageStatistics
    recall: RecallTokenStatistics
    recurrence: RecurrenceStatistics
    processing: tuple[ProcessingObservation, ...] = ()
    bootstrap_delivery: BootstrapDeliveryStatistics | None = None


class Statistics(BaseModel):
    """Current inventory and bounded model usage for one frozen Scope selection."""

    selection: ScopeSelection
    scope_ids: tuple[str, ...]
    as_of: datetime
    inventory: InventoryStatistics
    usage: UsageStatistics
    recall: RecallTokenStatistics
    by_scope: tuple[ScopeStatistics, ...]

    @model_validator(mode="after")
    def validate_scope_details(self) -> Statistics:
        if tuple(item.scope_id for item in self.by_scope) != self.scope_ids:
            raise ValueError("by_scope must contain one ordered entry for every resolved Scope")  # noqa: TRY003
        return self


__all__ = [
    "MAX_RECURRENCE_TOP_REVISIONS",
    "ArtifactInventoryStatistics",
    "BootstrapDeliveryReading",
    "BootstrapDeliveryStatistics",
    "CandidateFamilyCount",
    "CandidateInventoryStatistics",
    "FamilyCount",
    "InventoryStatistics",
    "MemoryEntryInventoryStatistics",
    "MemoryInventoryStatistics",
    "MemoryKindCount",
    "ModelUsageDay",
    "ModelUsageOperation",
    "ModelUsagePurpose",
    "ModelUsagePurposeBreakdown",
    "ModelUsageStatistics",
    "ModelUsageValue",
    "RecallEffortMeasurement",
    "RecallTokenDay",
    "RecallTokenMeasurement",
    "RecallTokenStatistics",
    "RecallTokenValue",
    "RecurrenceStatistics",
    "RecurrenceStreak",
    "ResolvedUsagePeriod",
    "ScopeStatistics",
    "SourceInventoryStatistics",
    "Statistics",
    "StatisticsPeriod",
    "UsageStatistics",
]
