# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Topic Memory Source-window orchestration and fenced atomic publication."""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Awaitable, Callable, Iterable, Mapping, Sequence
from contextlib import AsyncExitStack, asynccontextmanager, nullcontext
from contextvars import ContextVar
from dataclasses import dataclass, field, replace
from enum import StrEnum
from typing import Any, Generic, TypeVar, cast
from uuid import uuid4

from pydantic import BaseModel, Field
from sqlalchemy import update
from sqlalchemy.ext.asyncio import AsyncConnection
from typing_extensions import override

from powercontext.artifacts import ArtifactRef
from powercontext.builtin.artifacts.prompt.service import current_prompt
from powercontext.builtin.artifacts.topic_memory import (
    MAX_TOPIC_MEMORY_QUERY_LENGTH,
    TOPIC_MEMORY_SOURCE_WINDOW_BINDING,
    PublishedTopicMemory,
    TopicMemory,
    TopicMemoryContent,
    TopicMemoryDraft,
    TopicMemoryProjection,
    TopicMemorySearchHit,
    TopicMemorySearchMode,
    chunk_topic_memory_detail,
    prepare_topic_memory_projection,
)
from powercontext.builtin.artifacts.topic_memory.admission import TopicMemoryContentAdmission
from powercontext.builtin.artifacts.topic_memory.generation import (
    MAX_TOPIC_MEMORY_STAGE_ITEMS,
    TOPIC_MEMORY_PROBE_INSTRUCTIONS,
    TopicMemoryEvidence,
    TopicMemoryEvolveInput,
    TopicMemoryEvolveOutput,
    TopicMemoryGenerationError,
    TopicMemoryGlobalInput,
    TopicMemoryGlobalOutput,
    TopicMemoryHistoricalPreview,
    TopicMemoryHistoricalSlot,
    TopicMemoryPlanItem,
    TopicMemoryPlannerInput,
    TopicMemoryPlannerOutput,
    TopicMemoryProbe,
    TopicMemoryProbeCandidates,
    TopicMemoryProbeInput,
    TopicMemoryProbeOutput,
    TopicMemoryProposal,
    TopicMemoryReconcileInput,
    TopicMemoryReconcileOutput,
    TopicMemoryReductionInput,
    TopicMemoryReductionOutput,
    TopicMemoryTemporaryInput,
    TopicMemoryTemporaryOutput,
    topic_memory_stage_fixed_prompt,
)
from powercontext.builtin.artifacts.topic_memory.relatedness import (
    topic_memory_lexical_signature,
    topic_memory_related_components,
    topic_memory_vector_centroid,
)
from powercontext.builtin.artifacts.topic_memory.search import bounded_topic_memory_query
from powercontext.builtin.inference import (
    EmbeddingModel,
    EmbeddingResult,
    GenerationResult,
    InvalidInferenceOutputError,
    StructuredGenerator,
    TokenEstimator,
    character_token_estimator,
    embed_query,
)
from powercontext.builtin.inference.usage import bind_usage_reporter
from powercontext.builtin.persistence.cursors import SourceCursorRepository
from powercontext.builtin.persistence.database import AsyncDatabase
from powercontext.builtin.persistence.dream import DreamRepository
from powercontext.builtin.persistence.errors import ArtifactProcessingLeadershipLostError, GenerationConflictError
from powercontext.builtin.persistence.sources import SourceRepository, StoredSource
from powercontext.builtin.persistence.supervision import ArtifactProcessingFence, ArtifactProcessingLeaseRepository
from powercontext.builtin.persistence.tables import SOURCE_JOURNAL_HEADS_TABLE
from powercontext.builtin.persistence.topic_memory import TopicMemoryRepository
from powercontext.builtin.persistence.topic_memory_budget import (
    MAX_TOPIC_MEMORY_WORK_REQUESTS,
    MAX_TOPIC_MEMORY_WORK_TOKENS,
    RECOVERABLE_TOPIC_MEMORY_REJECTIONS,
    TOPIC_MEMORY_HEAD_CONFLICT,
    TopicMemoryWorkBudget,
    require_topic_memory_work_available,
)
from powercontext.builtin.processing_diagnostics import (
    ProcessingDiagnostics,
    ProcessingFailureReason,
    ProcessingStage,
    attach_diagnostics,
)
from powercontext.builtin.runtime.config import BuiltinConfig, InferenceConfig
from powercontext.builtin.runtime.processing_contracts import (
    ArtifactProcessingWorkAssignment,
    ArtifactProcessingWorkerCompletion,
    ArtifactProcessingWorkerOutcome,
)
from powercontext.builtin.runtime.protocols import RuntimeTracing
from powercontext.builtin.runtime.worker_observability import worker_observability
from powercontext.builtin.source_eligibility import is_generation_eligible
from powercontext.builtin.sources import (
    CONTENT_SOURCE_NAME,
    EXTERNAL_SKILL_SNAPSHOT_SOURCE_NAME,
    SKILL_PACKAGE_UPLOAD_SOURCE_NAME,
    SKILL_USAGE_SOURCE_NAME,
    ContentCapture,
    ExternalSkillSnapshotCapture,
    SkillPackageUploadCapture,
    SkillUsageCapture,
    SourceCursor,
)
from powercontext.builtin.statistics import ModelUsageOperation, ModelUsagePurpose
from powercontext.errors import RevisionConflictError
from powercontext.sources import TEXT_EVIDENCE_PROJECTION_KEY, SourceObservation, TextEvidence

logger = logging.getLogger(__name__)

_PLANNER_TEXT_PREVIEW_LENGTH = 512
MAX_TOPIC_MEMORY_SOURCE_CHARACTERS = 4 * 1024 * 1024
MAX_TOPIC_MEMORY_SOURCE_NODES = 65_536
MAX_TOPIC_MEMORY_SOURCE_DEPTH = 32
MAX_TOPIC_MEMORY_WINDOW_SOURCES = 100

# Rejections worth recording on the frontier. ``source_complexity_limit`` is decided
# by this window's own input, so a retry replays the same rejection. Generated
# rejections can be cleared by a later bounded attempt; the attempt ceiling bounds
# how many retries they may spend.
RECORDED_TOPIC_MEMORY_REJECTIONS = frozenset({"source_complexity_limit"}) | RECOVERABLE_TOPIC_MEMORY_REJECTIONS

InputT = TypeVar("InputT", bound=BaseModel)
OutputT = TypeVar("OutputT")


class _ReservedTopicMemoryGenerator(Generic[InputT, OutputT]):
    def __init__(
        self,
        delegate: StructuredGenerator[InputT, OutputT],
        reserve: Callable[[BaseModel, str], Awaitable[None]],
        stage: str,
    ) -> None:
        self.delegate = delegate
        self.reserve = reserve
        self.stage = stage

    async def generate(self, value: InputT, /) -> GenerationResult[OutputT]:
        await self.reserve(value, self.stage)
        return await self.delegate.generate(value)


UsageReporter = Callable[[ModelUsagePurpose, ModelUsageOperation, Any], Awaitable[None]]


class ArtifactProcessingWaveKind(StrEnum):
    """Legacy Topic window metadata; generic supervision has no waves."""

    EXPLICIT = "explicit"
    AUTOMATIC = "automatic"


@dataclass(frozen=True, slots=True)
class TopicMemoryWindowAssignment:
    """A private finite window used only by the Topic domain pipeline."""

    binding_name: str
    scope_id: str
    source_after: int
    source_through: int
    wave_target: int
    claimed_flush_generation: int
    cursor_generation: int | None
    wave_kind: ArtifactProcessingWaveKind
    fence: ArtifactProcessingFence
    worker_id: str


TopicMemoryCommitAuthorizer = Callable[
    [AsyncConnection, str, Sequence["PreparedTopicMemoryOperation"]], Awaitable[None]
]
TopicMemoryCommitHook = Callable[[AsyncConnection], Awaitable[None]]


@dataclass(frozen=True, slots=True)
class TopicMemoryStageSet:
    """Injected stage ports; arbitrary generator instances remain process-local."""

    probe: StructuredGenerator[TopicMemoryProbeInput, TopicMemoryProbeOutput]
    global_evolver: StructuredGenerator[TopicMemoryGlobalInput, TopicMemoryGlobalOutput]
    planner: StructuredGenerator[TopicMemoryPlannerInput, TopicMemoryPlannerOutput]
    evolver: StructuredGenerator[TopicMemoryEvolveInput, TopicMemoryEvolveOutput]
    temporary: StructuredGenerator[TopicMemoryTemporaryInput, TopicMemoryTemporaryOutput]
    reconciler: StructuredGenerator[TopicMemoryReconcileInput, TopicMemoryReconcileOutput]
    estimator: TokenEstimator
    input_tokens_limit: int
    fixed_prompts: Mapping[str, str] = field(default_factory=dict)
    reducer: StructuredGenerator[TopicMemoryReductionInput, TopicMemoryReductionOutput] | None = None
    max_requests: int = 2
    transcript_reserve: int | None = None

    def __post_init__(self) -> None:
        if (
            self.input_tokens_limit < 1
            or self.max_requests < 1
            or (self.transcript_reserve is not None and self.transcript_reserve < 1)
        ):
            raise ValueError("Topic Memory input token limit must be positive")  # noqa: TRY003

    def fits(self, value: BaseModel, stage: str = "") -> bool:
        fixed = self.fixed_prompts.get(stage, stage)
        return (
            self.estimator.estimate(f"{fixed}\n{value.model_dump_json(exclude_none=False)}") <= self.input_tokens_limit
        )


class TopicMemoryWorkerSpec(BaseModel):
    """Picklable child bootstrap configuration with a permanently redacted repr."""

    config: BuiltinConfig = Field(repr=False)
    worker_security: dict[str, Any] | None = Field(default=None, repr=False)

    @override
    def __repr__(self) -> str:
        return "TopicMemoryWorkerSpec(config=**********)"


@dataclass(frozen=True, slots=True)
class PreparedTopicMemoryOperation:
    """One fully projected CREATE or exact-head UPDATE ready for a short transaction."""

    proposal_id: str
    artifact_id: str
    current: TopicMemory | None
    draft: TopicMemoryDraft
    projection: TopicMemoryProjection


class TopicMemoryWindowSelector:
    """Choose the largest contiguous Source prefix that projects within the Window budgets."""

    def __init__(
        self,
        database: AsyncDatabase,
        sources: SourceRepository,
        estimator: TokenEstimator,
        *,
        context_window_tokens: int,
        probe_fixed_prompt: str | None = None,
    ) -> None:
        self._database = database
        self._sources = sources
        self._estimator = estimator
        self._input_limit = max(1, int(context_window_tokens * 0.80))
        self._probe_fixed_prompt = (
            topic_memory_stage_fixed_prompt(
                TOPIC_MEMORY_PROBE_INSTRUCTIONS,
                TopicMemoryProbeInput,
                TopicMemoryProbeOutput,
            )
            if probe_fixed_prompt is None
            else probe_fixed_prompt
        )

    async def select(self, scope_id: str, source_after: int, source_ceiling: int, /) -> int:
        source_ceiling = min(source_ceiling, source_after + MAX_TOPIC_MEMORY_WINDOW_SOURCES)
        limit = source_ceiling - source_after
        async with self._database.transaction() as connection:
            await require_topic_memory_work_available(
                connection, scope_id, TOPIC_MEMORY_SOURCE_WINDOW_BINDING, source_after
            )
            stored = await self._sources.list(connection, scope_id, after=source_after, limit=limit)
        if len(stored) != limit or tuple(item.journal_position for item in stored) != tuple(
            range(source_after + 1, source_ceiling + 1)
        ):
            raise TopicMemoryGenerationError("source_window_changed")
        # End the Window before the first Source it cannot take, without projecting
        # later ones: a failing or oversized Source must not shrink the prefix before it.
        evidence: list[TopicMemoryEvidence] = []
        characters = 0
        for index, item in enumerate(stored, start=1):
            # Lineage-only entries still belong to the contiguous Journal window.
            if not is_generation_eligible(item.value):
                continue
            try:
                projected = await _project_evidence(index, item, self._sources)
            except TopicMemoryGenerationError:
                # End before it; at the frontier, a singleton Worker persists its rejection.
                return source_after + max(index - 1, 1)
            characters += len(projected.content)
            evidence.append(projected)
            # The first eligible Source forms a Window even when it alone exceeds the budget.
            if (
                characters > MAX_TOPIC_MEMORY_SOURCE_CHARACTERS
                or not await asyncio.to_thread(self._probe_fits, evidence)
            ) and len(evidence) > 1:
                return source_after + index - 1
        return source_ceiling

    def _probe_fits(self, evidence: Sequence[TopicMemoryEvidence]) -> bool:
        request = f"{self._probe_fixed_prompt}\n{TopicMemoryProbeInput(evidence=tuple(evidence)).model_dump_json()}"
        return self._estimator.estimate(request) <= self._input_limit


class TopicMemoryAtomicPublisher:
    """Publish a complete Window with one Cursor CAS and one database transaction."""

    def __init__(
        self,
        database: AsyncDatabase,
        sources: SourceRepository,
        topics: TopicMemoryRepository,
        *,
        cursors: SourceCursorRepository | None = None,
        leases: ArtifactProcessingLeaseRepository | None = None,
        commit_authorizer: TopicMemoryCommitAuthorizer | None = None,
    ) -> None:
        self._database = database
        self._sources = sources
        self._topics = topics
        self._cursors = SourceCursorRepository() if cursors is None else cursors
        self._leases = ArtifactProcessingLeaseRepository() if leases is None else leases
        self._commit_authorizer = commit_authorizer

    async def publish(  # noqa: C901
        self,
        assignment: TopicMemoryWindowAssignment,
        evidence: Mapping[str, StoredSource],
        operations: Sequence[PreparedTopicMemoryOperation],
        /,
        *,
        work_budget: TopicMemoryWorkBudget | None = None,
        commit_hook: TopicMemoryCommitHook | None = None,
    ) -> None:
        if (
            assignment.binding_name != TOPIC_MEMORY_SOURCE_WINDOW_BINDING
            or not 0 <= assignment.source_after < assignment.source_through <= assignment.wave_target
            or len(operations) > MAX_TOPIC_MEMORY_STAGE_ITEMS
        ):
            raise TopicMemoryGenerationError("invalid_window")
        artifact_ids = [operation.artifact_id for operation in operations]
        proposal_ids = [operation.proposal_id for operation in operations]
        if (
            len(artifact_ids) != len(set(artifact_ids))
            or len(proposal_ids) != len(set(proposal_ids))
            or any(
                operation.current is not None
                and (
                    operation.current.artifact_id != operation.artifact_id
                    or operation.current.as_ref() not in operation.draft.artifacts
                )
                for operation in operations
            )
        ):
            raise TopicMemoryGenerationError("duplicate_operation")
        async with self._database.transaction() as connection:
            await self._leases.require_fence(connection, assignment.fence)
            # Make SQLite acquire the outer write transaction before the Cursor
            # repository's insert-CAS savepoint. It also freezes Source capture
            # for this scope while the exact Window is revalidated.
            await connection.execute(
                update(SOURCE_JOURNAL_HEADS_TABLE)
                .where(SOURCE_JOURNAL_HEADS_TABLE.c.scope_id == assignment.scope_id)
                .values(position=SOURCE_JOURNAL_HEADS_TABLE.c.position)
            )
            cursor = await self._cursors.load(
                connection,
                assignment.scope_id,
                assignment.binding_name,
                for_update=True,
            )
            actual_position = 0 if cursor is None else cursor.cursor.sequence
            actual_generation = None if cursor is None else cursor.generation
            if actual_position != assignment.source_after or actual_generation != assignment.cursor_generation:
                raise GenerationConflictError(
                    assignment.binding_name,
                    assignment.cursor_generation,
                    actual_generation,
                )
            count = assignment.source_through - assignment.source_after
            stored = await self._sources.list(
                connection,
                assignment.scope_id,
                after=assignment.source_after,
                limit=count,
            )
            ordered_evidence = tuple(sorted(evidence, key=_opaque_ordinal))
            if ordered_evidence != tuple(_evidence_id(index) for index in range(1, count + 1)):
                raise TopicMemoryGenerationError("invalid_evidence")
            expected = tuple(evidence[key] for key in ordered_evidence)
            if (
                len(stored) != count
                or tuple(item.journal_position for item in stored)
                != tuple(range(assignment.source_after + 1, assignment.source_through + 1))
                or tuple((item.ref, item.value) for item in stored)
                != tuple((item.ref, item.value) for item in expected)
            ):
                raise TopicMemoryGenerationError("source_window_changed")
            allowed_sources = {(item.ref.source_type, item.ref.source_id) for item in stored}
            for operation in operations:
                cited_sources = {(item.source_type, item.source_id) for item in operation.draft.sources}
                if not cited_sources or not cited_sources <= allowed_sources:
                    raise TopicMemoryGenerationError("invalid_evidence")
            if self._commit_authorizer is not None:
                await self._commit_authorizer(connection, assignment.scope_id, operations)
            if work_budget is not None:
                await work_budget.complete(connection)
            await self._cursors.save(
                connection,
                assignment.scope_id,
                assignment.binding_name,
                SourceCursor(sequence=assignment.source_through),
                expected_generation=assignment.cursor_generation,
            )
            ordered = sorted(operations, key=_operation_order)
            position = 0
            while position < len(ordered):
                operation = ordered[position]
                if operation.current is not None:
                    await self._topics.publish_revision(
                        connection,
                        assignment.scope_id,
                        operation.current,
                        operation.draft,
                        operation.projection,
                    )
                    position += 1
                    continue
                next_position = position + 1
                while next_position < len(ordered) and ordered[next_position].current is None:
                    next_position += 1
                creates = ordered[position:next_position]
                await self._topics.publish_creates(
                    connection,
                    assignment.scope_id,
                    tuple((item.artifact_id, item.draft, item.projection) for item in creates),
                    known_sources=stored,
                )
                position = next_position
            if commit_hook is not None:
                await commit_hook(connection)
            await self._leases.require_fence(connection, assignment.fence)


class TopicMemoryProcessor:
    """Connect the R3 Worker contract to R4 retrieval and atomic publication."""

    def __init__(
        self,
        *,
        database: AsyncDatabase,
        sources: SourceRepository,
        topics: TopicMemoryRepository,
        stages: TopicMemoryStageSet,
        publisher: TopicMemoryAtomicPublisher,
        embedding_model: EmbeddingModel | None = None,
        usage_reporter: UsageReporter | None = None,
        history_max_candidates: int = 20,
        history_rrf_threshold: int = 70,
        history_min_candidates: int = 5,
        id_factory: Callable[[], str] | None = None,
        prompt_refs: Mapping[str, ArtifactRef] | None = None,
        tracing: RuntimeTracing | None = None,
    ) -> None:
        self._tracing = tracing
        self._database = database
        self._sources = sources
        self._topics = topics
        self._work_budget: ContextVar[TopicMemoryWorkBudget | None] = ContextVar(
            "topic_memory_work_budget", default=None
        )
        self._local_requests = 0
        self._local_tokens = 0
        self._stages = replace(
            stages,
            probe=_ReservedTopicMemoryGenerator(stages.probe, self._reserve_stage, "probe"),
            global_evolver=_ReservedTopicMemoryGenerator(stages.global_evolver, self._reserve_stage, "global"),
            planner=_ReservedTopicMemoryGenerator(stages.planner, self._reserve_stage, "planner"),
            evolver=_ReservedTopicMemoryGenerator(stages.evolver, self._reserve_stage, "evolve"),
            temporary=_ReservedTopicMemoryGenerator(stages.temporary, self._reserve_stage, "temporary"),
            reconciler=_ReservedTopicMemoryGenerator(stages.reconciler, self._reserve_stage, "reconcile"),
            reducer=None
            if stages.reducer is None
            else _ReservedTopicMemoryGenerator(stages.reducer, self._reserve_stage, "reduce"),
        )
        self._publisher = publisher
        self._embedding_model = embedding_model
        self._document_vectors: ContextVar[dict[tuple[str, str], tuple[float, ...]] | None] = ContextVar(
            "topic_memory_document_vectors", default=None
        )
        self._usage_reporter = usage_reporter
        self._history_max = history_max_candidates
        self._history_threshold = history_rrf_threshold
        self._history_min = history_min_candidates
        self._id_factory = (lambda: str(uuid4())) if id_factory is None else id_factory
        self._prompt_refs: Mapping[str, ArtifactRef] = prompt_refs or {}
        self._used_stages: set[str] = set()

    def _used_prompt_refs(self) -> tuple[ArtifactRef, ...]:
        """Custom Prompt revisions of the stages this run actually invoked, in a stable order."""

        refs: list[ArtifactRef] = []
        for stage in ("probe", "global", "planner", "evolve", "temporary", "reduce", "reconcile"):
            if (
                stage in self._used_stages
                and (reference := self._prompt_refs.get(stage)) is not None
                and all(reference != existing for existing in refs)
            ):
                refs.append(reference)
        return tuple(refs)

    async def process(
        self,
        assignment: TopicMemoryWindowAssignment,
        /,
        *,
        commit_hook: TopicMemoryCommitHook | None = None,
    ) -> ArtifactProcessingWorkerCompletion:
        if (
            assignment.binding_name != TOPIC_MEMORY_SOURCE_WINDOW_BINDING
            or not 0 <= assignment.source_after < assignment.source_through <= assignment.wave_target
        ):
            raise TopicMemoryGenerationError("invalid_window")
        budget = TopicMemoryWorkBudget(
            self._database,
            scope_id=assignment.scope_id,
            binding_name=assignment.binding_name,
            source_after=assignment.source_after,
            source_through=assignment.source_through,
            cursor_generation=assignment.cursor_generation,
            fence=assignment.fence,
        )
        token = self._work_budget.set(budget)
        vector_token = self._document_vectors.set({})
        self._used_stages.clear()
        try:
            await budget.begin()
            try:
                with (
                    nullcontext()
                    if self._tracing is None
                    else self._tracing.stage("topic_memory.prepare", attributes={})
                ):
                    stored = await self._read_window(assignment)
                    evidence = {_evidence_id(index): item for index, item in enumerate(stored, start=1)}
                    projected = await _project_window(stored, self._sources)
                    proposals, candidates = (
                        await self._generate(assignment.scope_id, projected) if projected else ((), {})
                    )
                    operations = await self._prepare_operations(assignment.scope_id, proposals, candidates, evidence)
                try:
                    with (
                        nullcontext()
                        if self._tracing is None
                        else self._tracing.stage("topic_memory.commit", attributes={})
                    ):
                        await self._publisher.publish(
                            assignment, evidence, operations, work_budget=budget, commit_hook=commit_hook
                        )
                except RevisionConflictError:
                    # A concurrent replace or Dream moved a Topic head after this attempt read it.
                    # Recording the cause hands the attempt back; its reservations stay charged. Only a
                    # generated proposal can target an existing head, and every stage reserves before its
                    # call, so each recomputation spends from the frontier's request and token ceilings.
                    await budget.record_failure(TOPIC_MEMORY_HEAD_CONFLICT)
                    return ArtifactProcessingWorkerCompletion(ArtifactProcessingWorkerOutcome.HEAD_CONFLICT)
            except TopicMemoryGenerationError as error:
                if error.code in RECORDED_TOPIC_MEMORY_REJECTIONS:
                    await budget.fail(error.code)
                else:
                    await budget.record_failure(error.code)
                raise
        except ArtifactProcessingLeadershipLostError:
            return ArtifactProcessingWorkerCompletion(ArtifactProcessingWorkerOutcome.LEADERSHIP_LOST)
        except GenerationConflictError:
            return ArtifactProcessingWorkerCompletion(ArtifactProcessingWorkerOutcome.CURSOR_CONFLICT)
        except RevisionConflictError:
            # Not raised by publication, so this attempt keeps counting toward the ceiling.
            return ArtifactProcessingWorkerCompletion(ArtifactProcessingWorkerOutcome.HEAD_CONFLICT)
        finally:
            self._document_vectors.reset(vector_token)
            self._work_budget.reset(token)
        return ArtifactProcessingWorkerCompletion()

    async def _reserve_stage(self, value: BaseModel, stage: str) -> None:
        self._used_stages.add(stage)
        if not self._stages.fits(value, stage):
            raise self._input_budget_error(value, stage, input_item_count=_topic_memory_item_count(value))
        # Reserve every structured retry's entire input + output/transcript
        # capacity, even if the provider returns no usage or fails mid-call.
        reserve = self._stages.transcript_reserve
        capacity = self._stages.input_tokens_limit + (
            max(1, self._stages.input_tokens_limit // 4) if reserve is None else reserve
        )
        await self._reserve(requests=self._stages.max_requests, tokens=self._stages.max_requests * capacity)

    def _estimate_stage_input(self, value: BaseModel, stage: str) -> int:
        fixed = self._stages.fixed_prompts.get(stage, stage)
        return self._stages.estimator.estimate(f"{fixed}\n{value.model_dump_json(exclude_none=False)}")

    def _token_estimator_id(self) -> str | None:
        try:
            return self._stages.estimator.profile.estimator_id
        except Exception:
            return None

    def _input_budget_error(
        self,
        value: BaseModel,
        stage: str,
        *,
        input_item_count: int | None = None,
        code: str = "input_budget_exceeded",
    ) -> TopicMemoryGenerationError:
        try:
            estimate = self._estimate_stage_input(value, stage)
        except Exception:
            estimate = None
        return attach_diagnostics(
            TopicMemoryGenerationError(code),
            ProcessingDiagnostics(
                stage=ProcessingStage.BUSINESS_VALIDATION,
                reason=ProcessingFailureReason.CONTEXT_OVERFLOW,
                input_item_count=input_item_count,
                estimated_input_tokens=estimate,
                token_estimator_id=self._token_estimator_id(),
                effective_budget=self._stages.input_tokens_limit,
                failure_location=stage,
            ),
        )

    async def _reserve(self, *, requests: int, tokens: int) -> None:
        budget = self._work_budget.get()
        if budget is not None:
            await budget.reserve(requests=requests, tokens=tokens)
            return
        # Private stage helpers also have a finite allowance when used alone.
        # The public process entrypoint ALWAYS uses the durable reservation.
        requests_after = self._local_requests + requests
        tokens_after = self._local_tokens + tokens
        if requests_after > MAX_TOPIC_MEMORY_WORK_REQUESTS or tokens_after > MAX_TOPIC_MEMORY_WORK_TOKENS:
            token_ceiling = requests_after <= MAX_TOPIC_MEMORY_WORK_REQUESTS
            raise attach_diagnostics(
                TopicMemoryGenerationError("window_provider_budget_exceeded"),
                ProcessingDiagnostics(
                    stage=ProcessingStage.GENERATION,
                    reason=ProcessingFailureReason.USAGE_LIMIT,
                    estimated_input_tokens=tokens_after if token_ceiling else None,
                    effective_budget=MAX_TOPIC_MEMORY_WORK_TOKENS if token_ceiling else None,
                    failure_location="window_provider_budget_exceeded",
                ),
            )
        self._local_requests = requests_after
        self._local_tokens = tokens_after

    async def _embed(self, texts: tuple[str, ...]):
        model = self._embedding_model
        if model is None:
            raise attach_diagnostics(
                TopicMemoryGenerationError("embedding_unavailable"),
                ProcessingDiagnostics(
                    stage=ProcessingStage.EMBEDDING,
                    reason=ProcessingFailureReason.CONFIGURATION,
                    failure_location="topic-memory-embed",
                ),
            )
        cached = self._document_vectors.get()
        if cached is None:
            cached = {}
        profile = model.profile.model_dump_json()
        pending = tuple(dict.fromkeys(text for text in texts if (profile, text) not in cached))
        # At most one provider request per text (the adapter may batch them).
        if pending:
            await self._reserve(
                requests=len(pending), tokens=max(1, sum(self._stages.estimator.estimate(text) for text in pending))
            )
            result = await model.embed(pending)
            if len(result.vectors) != len(pending):
                raise attach_diagnostics(
                    InvalidInferenceOutputError("topic-memory.index", "requires one vector per input"),
                    ProcessingDiagnostics(
                        stage=ProcessingStage.EMBEDDING,
                        reason=ProcessingFailureReason.INVALID_OUTPUT,
                        failure_location="topic-memory-index",
                    ),
                )
            cached.update(((profile, text), vector) for text, vector in zip(pending, result.vectors, strict=True))
        return EmbeddingResult(vectors=tuple(cached[profile, text] for text in texts))

    async def _embed_query(self, texts: tuple[str, ...]):
        if self._embedding_model is None:
            raise attach_diagnostics(
                TopicMemoryGenerationError("embedding_unavailable"),
                ProcessingDiagnostics(
                    stage=ProcessingStage.EMBEDDING,
                    reason=ProcessingFailureReason.CONFIGURATION,
                    failure_location="topic-memory-embed-query",
                ),
            )
        # At most one provider request per text (the adapter may batch them).
        await self._reserve(
            requests=max(1, len(texts)), tokens=max(1, sum(self._stages.estimator.estimate(text) for text in texts))
        )
        return await embed_query(self._embedding_model, texts)

    async def _read_window(self, assignment: TopicMemoryWindowAssignment) -> tuple[StoredSource, ...]:
        if assignment.source_through - assignment.source_after > MAX_TOPIC_MEMORY_WINDOW_SOURCES:
            raise TopicMemoryGenerationError("source_complexity_limit")
        count = assignment.source_through - assignment.source_after
        async with self._database.transaction() as connection:
            stored = await self._sources.list(
                connection,
                assignment.scope_id,
                after=assignment.source_after,
                limit=count,
            )
        if len(stored) != count or tuple(item.journal_position for item in stored) != tuple(
            range(assignment.source_after + 1, assignment.source_through + 1)
        ):
            raise TopicMemoryGenerationError("source_window_changed")
        return stored

    async def _generate(
        self,
        scope_id: str,
        evidence: tuple[TopicMemoryEvidence, ...],
    ) -> tuple[tuple[TopicMemoryProposal, ...], dict[str, PublishedTopicMemory]]:
        probes = await self._probe(evidence)
        if not probes:
            return (), {}
        probe_candidates, candidates, planner_history = await self._history(scope_id, probes)
        # Keep stage identities local to this generation, including inputs later compacted away.
        internal_ids = {item.probe_id for item in probe_candidates}
        global_input = TopicMemoryGlobalInput(
            evidence=evidence,
            probes=probe_candidates,
            historical=tuple(_historical_slot(key, value) for key, value in candidates.items()),
        )
        if self._stages.fits(global_input, "global"):
            with self._usage(ModelUsagePurpose.TOPIC_MEMORY_GENERATION):
                global_output = (await self._stages.global_evolver.generate(global_input)).output
            if not global_output.ambiguous and self._global_targets_bind(global_output.proposals, candidates):
                proposals = self._validate_proposals(
                    global_output.proposals, evidence, candidates, internal_ids=internal_ids
                )
                return await self._coordinate(scope_id, proposals, candidates, evidence, internal_ids=internal_ids)
        proposals = await self._plan(probe_candidates, planner_history, evidence, candidates, internal_ids=internal_ids)
        return await self._coordinate(scope_id, proposals, candidates, evidence, internal_ids=internal_ids)

    async def _probe(self, evidence: tuple[TopicMemoryEvidence, ...]) -> tuple[TopicMemoryProbe, ...]:
        batches = self._evidence_batches(evidence, "probe")
        probes: list[TopicMemoryProbe] = []
        for batch in batches:
            with self._usage(ModelUsagePurpose.TOPIC_MEMORY_GENERATION):
                output = (await self._stages.probe.generate(TopicMemoryProbeInput(evidence=batch))).output
            self._validate_probes(output.probes, batch)
            for probe in output.probes:
                if probe in probes:
                    continue
                probes = list(cast(tuple[TopicMemoryProbe, ...], await self._compact_intermediates((*probes, probe))))
        result = tuple(probes)
        self._validate_probes(result, evidence)
        return result

    def _reduction_input(
        self, items: Sequence[TopicMemoryProbe | TopicMemoryProposal], *, temporary: bool
    ) -> TopicMemoryReductionInput:
        return TopicMemoryReductionInput(
            probes=() if temporary else cast(tuple[TopicMemoryProbe, ...], tuple(items)),
            temporary=cast(tuple[TopicMemoryProposal, ...], tuple(items)) if temporary else (),
            max_result_tokens=max(1, self._stages.input_tokens_limit // 8),
        )

    def _reduction_input_error(
        self, items: Sequence[TopicMemoryProbe | TopicMemoryProposal], *, temporary: bool
    ) -> TopicMemoryGenerationError:
        if self._stages.reducer is None:
            return attach_diagnostics(
                TopicMemoryGenerationError("reduction_input_budget_exceeded"),
                ProcessingDiagnostics(reason=ProcessingFailureReason.CONFIGURATION, failure_location="reduce"),
            )
        return self._input_budget_error(
            self._reduction_input(items[:1], temporary=temporary),
            "reduce",
            input_item_count=1,
            code="reduction_input_budget_exceeded",
        )

    async def _compact_intermediates(
        self,
        values: Sequence[TopicMemoryProbe | TopicMemoryProposal],
        *,
        temporary: bool = False,
        historical: TopicMemoryHistoricalSlot | None = None,
    ) -> tuple[TopicMemoryProbe | TopicMemoryProposal, ...]:
        """Bound live results by count AND tokens without dropping an input.

        Each reduction consumes a prefix and returns one summary. A singleton
        must shrink; every other reduction decreases cardinality. The fixed
        attempt bound prevents model output from causing a compression loop.
        """

        items = list(values)
        for _ in range(2 * len(items) + 1):
            if len(items) <= MAX_TOPIC_MEMORY_STAGE_ITEMS:
                fits = self._stages.fits(self._reduction_input(items, temporary=temporary), "reduce")
                if temporary:
                    fits = fits and self._stages.fits(
                        TopicMemoryEvolveInput(
                            work_id="work-0001",
                            temporary=cast(tuple[TopicMemoryProposal, ...], tuple(items)),
                            historical=historical,
                        ),
                        "evolve",
                    )
                if fits:
                    return tuple(items)
            size = min(len(items), MAX_TOPIC_MEMORY_STAGE_ITEMS)
            while size and not self._stages.fits(self._reduction_input(items[:size], temporary=temporary), "reduce"):
                size -= 1
            if not size or self._stages.reducer is None:
                raise self._reduction_input_error(items, temporary=temporary)
            request = self._reduction_input(items[:size], temporary=temporary)
            with self._usage(ModelUsagePurpose.TOPIC_MEMORY_GENERATION):
                output = (await self._stages.reducer.generate(request)).output
            result = output.temporary if temporary else output.probe
            other = output.probe if temporary else output.temporary
            expected_evidence = {eid for item in items[:size] for eid in item.evidence_ids}
            if (
                result is None
                or other is not None
                or sorted(output.covered_indices) != list(range(size))
                or set(result.evidence_ids) != expected_evidence
                or (isinstance(result, TopicMemoryProposal) and (result.candidate_id or result.proposal_id))
            ):
                raise TopicMemoryGenerationError("invalid_reduction")
            result_tokens = self._stages.estimator.estimate(result.model_dump_json())
            if result_tokens > request.max_result_tokens:
                raise attach_diagnostics(
                    TopicMemoryGenerationError("reduction_output_budget_exceeded"),
                    ProcessingDiagnostics(
                        stage=ProcessingStage.GENERATION,
                        reason=ProcessingFailureReason.USAGE_LIMIT,
                        input_item_count=len(items[:size]),
                        token_estimator_id=self._token_estimator_id(),
                        effective_budget=request.max_result_tokens,
                        failure_location="reduce",
                    ),
                )
            if size == 1 and result_tokens >= self._stages.estimator.estimate(items[0].model_dump_json()):
                raise TopicMemoryGenerationError("reduction_did_not_progress")
            items[:size] = [result]
        raise TopicMemoryGenerationError("reduction_did_not_progress")

    def _evidence_batches(
        self,
        evidence: tuple[TopicMemoryEvidence, ...],
        stage: str,
    ) -> Iterable[tuple[TopicMemoryEvidence, ...]]:
        batch: list[TopicMemoryEvidence] = []
        for item in evidence:
            candidate = (*batch, item)
            if self._evidence_batch_fits(candidate, stage):
                batch.append(item)
                continue
            if batch:
                yield tuple(batch)
                batch = []
            if self._evidence_batch_fits((item,), stage):
                batch.append(item)
            else:
                for fragment in self._evidence_fragments(item, stage):
                    yield (fragment,)
        if batch:
            yield tuple(batch)

    def _evidence_fragments(self, item: TopicMemoryEvidence, stage: str) -> Iterable[TopicMemoryEvidence]:
        """Keep every character and the original evidence identity across bounded requests."""

        offset = 0
        fragment_size = len(item.content)
        while offset < len(item.content):
            size = min(fragment_size, len(item.content) - offset)
            while size:
                fragment = item.model_copy(
                    update={
                        "content": item.content[offset : offset + size],
                        "metadata": {
                            **item.metadata,
                            "fragment_start": offset,
                            "fragment_end": offset + size,
                            "source_content_length": len(item.content),
                        },
                    }
                )
                if self._evidence_batch_fits((fragment,), stage):
                    yield fragment
                    offset += size
                    fragment_size = size
                    break
                size //= 2
            else:
                value = (
                    TopicMemoryProbeInput(evidence=(item,))
                    if stage == "probe"
                    else TopicMemoryTemporaryInput(work_id="work-batch", evidence=(item,))
                )
                raise self._input_budget_error(value, stage, input_item_count=1)

    def _evidence_batch_fits(
        self,
        evidence: tuple[TopicMemoryEvidence, ...],
        stage: str,
    ) -> bool:
        value: BaseModel = (
            TopicMemoryProbeInput(evidence=evidence)
            if stage == "probe"
            else TopicMemoryTemporaryInput(work_id="work-batch", evidence=evidence)
        )
        return self._stages.fits(value, stage)

    @staticmethod
    def _global_targets_bind(
        proposals: tuple[TopicMemoryProposal, ...],
        candidates: Mapping[str, PublishedTopicMemory],
    ) -> bool:
        targets = [proposal.candidate_id for proposal in proposals if proposal.candidate_id is not None]
        return len(targets) == len(set(targets)) and all(target in candidates for target in targets)

    async def _history(
        self,
        scope_id: str,
        probes: tuple[TopicMemoryProbe, ...],
    ) -> tuple[
        tuple[TopicMemoryProbeCandidates, ...],
        dict[str, PublishedTopicMemory],
        tuple[TopicMemoryHistoricalPreview, ...],
    ]:
        ranked: dict[tuple[str, int], tuple[float, int, TopicMemorySearchHit]] = {}
        hits_by_probe: list[tuple[TopicMemorySearchHit, ...]] = []
        for probe_index, probe in enumerate(probes):
            raw = " ".join(value.strip() for value in (probe.query, *probe.keywords) if value.strip())
            result = (
                await self._search(
                    scope_id,
                    bounded_topic_memory_query(raw),
                    semantic_query=raw[:MAX_TOPIC_MEMORY_QUERY_LENGTH].strip(),
                )
                if raw
                else ()
            )
            selected = _distinct_hits(hit for hit in result if hit.score >= self._history_threshold)
            if len(selected) < self._history_min:
                selected = _distinct_hits(result)[: self._history_min]
            selected = selected[: self._history_max]
            hits_by_probe.append(selected)
            for hit in selected:
                key = _artifact_key(hit.artifact_ref)
                current = ranked.get(key)
                candidate = (hit.score, probe_index, hit)
                if current is None or (-candidate[0], candidate[1]) < (-current[0], current[1]):
                    ranked[key] = candidate
        ordered_keys = sorted(
            ranked,
            key=lambda key: (-ranked[key][0], ranked[key][1], key[0].encode(), -key[1]),
        )[: self._history_max]
        id_by_key = {key: f"candidate-{index:04d}" for index, key in enumerate(ordered_keys, start=1)}
        candidates: dict[str, PublishedTopicMemory] = {}
        if ordered_keys:
            async with self._database.transaction(consistent_snapshot=True) as connection:
                publications = await self._topics.get_exact_many(
                    connection, scope_id, tuple(ranked[key][2].artifact_ref for key in ordered_keys)
                )
            candidates = {id_by_key[key]: value for key, value in zip(ordered_keys, publications, strict=True)}
        projected = tuple(
            TopicMemoryProbeCandidates(
                probe_id=f"probe-{index:04d}",
                query=probe.query,
                keywords=probe.keywords,
                evidence_ids=probe.evidence_ids,
                candidate_ids=tuple(
                    id_by_key[_artifact_key(hit.artifact_ref)]
                    for hit in hits
                    if _artifact_key(hit.artifact_ref) in id_by_key
                ),
            )
            for index, (probe, hits) in enumerate(zip(probes, hits_by_probe, strict=True), start=1)
        )
        planner_history = tuple(
            TopicMemoryHistoricalPreview(
                candidate_id=id_by_key[key],
                title=ranked[key][2].title,
                summary=ranked[key][2].summary,
                snippet=ranked[key][2].snippet,
            )
            for key in ordered_keys
        )
        return projected, candidates, planner_history

    async def _search(
        self,
        scope_id: str,
        query: str,
        *,
        semantic_query: str | None = None,
    ) -> tuple[TopicMemorySearchHit, ...]:
        query_vector = None
        profile = None
        if self._embedding_model is not None:
            with self._usage(ModelUsagePurpose.TOPIC_MEMORY_RECALL, embedding=True):
                embedded = await self._embed_query((query if semantic_query is None else semantic_query,))
            query_vector = embedded.vectors[0]
            profile = self._embedding_model.profile
        async with self._database.transaction(consistent_snapshot=True) as connection:
            result = await self._topics.search(
                connection,
                scope_id,
                query,
                limit=self._history_max,
                mode="hybrid" if query_vector is not None else "fts",
                query_vector=query_vector,
                embedding_profile=profile,
            )
        return result.hits

    async def _plan(  # noqa: C901
        self,
        probes: tuple[TopicMemoryProbeCandidates, ...],
        planner_history: tuple[TopicMemoryHistoricalPreview, ...],
        evidence: tuple[TopicMemoryEvidence, ...],
        candidates: Mapping[str, PublishedTopicMemory],
        *,
        internal_ids: set[str] | None = None,
    ) -> tuple[TopicMemoryProposal, ...]:
        known_ids = set() if internal_ids is None else internal_ids
        known_ids.update(item.probe_id for item in probes)
        planner_input = _bounded_planner_input(probes, planner_history)
        if self._stages.fits(planner_input, "planner"):
            with self._usage(ModelUsagePurpose.TOPIC_MEMORY_GENERATION):
                plan = (await self._stages.planner.generate(planner_input)).output
        else:
            plan = _deterministic_plan(probes)
        expected_probes = {probe.probe_id for probe in probes}
        observed = [probe_id for item in plan.items for probe_id in item.probe_ids]
        if set(observed) != expected_probes or len(observed) != len(set(observed)):
            raise TopicMemoryGenerationError("invalid_plan")
        targets = [item.candidate_id for item in plan.items if item.candidate_id is not None]
        if len(targets) != len(set(targets)) or any(target not in candidates for target in targets):
            raise TopicMemoryGenerationError("invalid_plan")
        probe_map = {probe.probe_id: probe for probe in probes}
        item_by_probe = {
            probe_id: item_index for item_index, item in enumerate(plan.items) for probe_id in item.probe_ids
        }
        for candidate_id in candidates:
            assigned_items = {item_by_probe[probe.probe_id] for probe in probes if candidate_id in probe.candidate_ids}
            if len(assigned_items) > 1:
                raise TopicMemoryGenerationError("invalid_plan")
        for item in plan.items:
            if item.candidate_id is None:
                continue
            item_probes = set(item.probe_ids)
            if any(item.candidate_id not in probe_map[probe_id].candidate_ids for probe_id in item.probe_ids):
                raise TopicMemoryGenerationError("invalid_plan")
            shared_probes = {probe.probe_id for probe in probes if item.candidate_id in probe.candidate_ids}
            if not shared_probes <= item_probes:
                raise TopicMemoryGenerationError("invalid_plan")
        evidence_map = {item.evidence_id: item for item in evidence}
        proposals: list[TopicMemoryProposal] = []
        for index, item in enumerate(plan.items, start=1):
            ids = tuple(dict.fromkeys(eid for pid in item.probe_ids for eid in probe_map[pid].evidence_ids))
            work_evidence = tuple(evidence_map[eid] for eid in ids)
            historical = (
                None
                if item.candidate_id is None
                else _historical_slot(item.candidate_id, candidates[item.candidate_id])
            )
            evolve_input = TopicMemoryEvolveInput(
                work_id=f"work-{index:04d}",
                evidence=work_evidence,
                historical=historical,
            )
            known_ids.add(evolve_input.work_id)
            if self._stages.fits(evolve_input, "evolve"):
                with self._usage(ModelUsagePurpose.TOPIC_MEMORY_GENERATION):
                    proposal = (await self._stages.evolver.generate(evolve_input)).output.proposal
            else:
                temporary: list[TopicMemoryProposal] = []
                for batch_index, batch in enumerate(
                    self._evidence_batches(work_evidence, "temporary"),
                    start=1,
                ):
                    temporary_input = TopicMemoryTemporaryInput(
                        work_id=evolve_input.work_id,
                        evidence=batch,
                    )
                    with self._usage(ModelUsagePurpose.TOPIC_MEMORY_GENERATION):
                        output = (await self._stages.temporary.generate(temporary_input)).output
                    allowed_evidence = {source.evidence_id for source in batch}
                    for temp in output.proposals:
                        if temp.candidate_id is not None or not set(temp.evidence_ids) <= allowed_evidence:
                            raise TopicMemoryGenerationError("invalid_temporary")
                        temporary_id = f"temp-{index:04d}-{batch_index:04d}-{len(temporary):04d}"
                        known_ids.add(temporary_id)
                        temporary.append(temp.model_copy(update={"proposal_id": temporary_id}))
                        temporary = list(
                            cast(
                                tuple[TopicMemoryProposal, ...],
                                await self._compact_intermediates(temporary, temporary=True),
                            )
                        )
                temporary = list(
                    cast(
                        tuple[TopicMemoryProposal, ...],
                        await self._compact_intermediates(temporary, temporary=True, historical=historical),
                    )
                )
                flattened = TopicMemoryEvolveInput(
                    work_id=evolve_input.work_id,
                    temporary=tuple(temporary),
                    historical=historical,
                )
                if not self._stages.fits(flattened, "evolve"):
                    raise self._input_budget_error(
                        flattened,
                        "evolve",
                        input_item_count=len(temporary) + (1 if historical is not None else 0),
                    )
                with self._usage(ModelUsagePurpose.TOPIC_MEMORY_GENERATION):
                    proposal = (await self._stages.evolver.generate(flattened)).output.proposal
            if proposal is not None:
                if proposal.candidate_id != item.candidate_id or not set(proposal.evidence_ids) <= set(ids):
                    raise TopicMemoryGenerationError("invalid_work_item")
                proposals.append(proposal)
        return self._validate_proposals(tuple(proposals), evidence, candidates, internal_ids=known_ids)

    async def _coordinate(  # noqa: C901
        self,
        scope_id: str,
        proposals: tuple[TopicMemoryProposal, ...],
        candidates: dict[str, PublishedTopicMemory],
        evidence: tuple[TopicMemoryEvidence, ...],
        *,
        internal_ids: Iterable[str] = (),
    ) -> tuple[tuple[TopicMemoryProposal, ...], dict[str, PublishedTopicMemory]]:
        known_ids = set(internal_ids)
        proposals = tuple(
            proposal.model_copy(update={"proposal_id": f"proposal-{index:04d}"})
            for index, proposal in enumerate(proposals, start=1)
        )
        known_ids.update(item.proposal_id for item in proposals if item.proposal_id is not None)
        related_scores: dict[str, float] = {}
        discovered: dict[tuple[str, int], tuple[float, ArtifactRef]] = {}
        searches: list[tuple[TopicMemorySearchHit, ...]] = []
        vectors: list[tuple[float, ...] | None] = []
        signatures = tuple(topic_memory_lexical_signature(proposal.content) for proposal in proposals)
        for proposal, signature in zip(proposals, signatures, strict=True):
            if proposal.candidate_id is not None:
                searches.append(())
                vectors.append(None)
                continue
            hits, vector = await self._related_candidates(scope_id, proposal, signature)
            if not hits and vector is None:
                searches.append(())
                vectors.append(None)
                continue
            for hit in hits:
                key = _artifact_key(hit.artifact_ref)
                current = discovered.get(key)
                if current is None or hit.score > current[0]:
                    discovered[key] = (hit.score, hit.artifact_ref)
            searches.append(hits)
            vectors.append(vector)
        known = {_artifact_key(publication.topic.as_ref()): key for key, publication in candidates.items()}
        # Every newly discovered related Topic stays reachable: unrelated unbound initial
        # candidates must not consume the capacity a distinct second-pass match needs.
        # The per-component ranking below keeps each reconcile stage input within its limit.
        added = sorted(
            (key for key in discovered if key not in known),
            key=lambda key: (-discovered[key][0], key[0].encode(), -key[1]),
        )
        reserved = set(candidates)
        next_index = 1
        for key in added:
            candidate_id = f"candidate-{next_index:04d}"
            while candidate_id in reserved:
                next_index += 1
                candidate_id = f"candidate-{next_index:04d}"
            reserved.add(candidate_id)
            next_index += 1
            known[key] = candidate_id
        if added:
            async with self._database.transaction(consistent_snapshot=True) as connection:
                publications = await self._topics.get_exact_many(
                    connection,
                    scope_id,
                    tuple(discovered[key][1] for key in added),
                )
            for key, publication in zip(added, publications, strict=True):
                candidates[known[key]] = publication
        known_ids.update(candidates)
        secondary_candidates: list[frozenset[str]] = []
        for hits, proposal in zip(searches, proposals, strict=True):
            scored = {
                known[_artifact_key(hit.artifact_ref)]: hit.score
                for hit in hits
                if _artifact_key(hit.artifact_ref) in known and known[_artifact_key(hit.artifact_ref)] in candidates
            }
            for candidate_id, score in scored.items():
                related_scores[candidate_id] = max(related_scores.get(candidate_id, 0.0), score)
            if proposal.candidate_id is not None:
                scored[proposal.candidate_id] = float("inf")
            secondary_candidates.append(frozenset(scored))
        components = topic_memory_related_components(
            proposals,
            secondary_candidates=tuple(secondary_candidates),
            vectors=tuple(vectors),
            signatures=signatures,
        )
        coordinated: list[TopicMemoryProposal] = []
        for component_index, component in enumerate(components, start=1):
            members = tuple(proposals[index] for index in component)
            creates = tuple(member for member in members if member.candidate_id is None)
            bound_candidates = {member.candidate_id for member in members if member.candidate_id is not None}
            related_candidates = {cid for index in component for cid in secondary_candidates[index]} - bound_candidates
            ranked_candidates = sorted(
                related_candidates,
                key=lambda candidate_id: (-related_scores.get(candidate_id, 0.0), candidate_id),
            )[: MAX_TOPIC_MEMORY_STAGE_ITEMS - len(bound_candidates)]
            history_ids = sorted(bound_candidates | set(ranked_candidates))
            if not creates or (len(component) == 1 and not history_ids):
                coordinated.extend(members)
                continue
            reconcile_input = TopicMemoryReconcileInput(
                component_id=f"component-{component_index:04d}",
                proposals=members,
                historical=tuple(
                    _historical_slot(candidate_id, candidates[candidate_id]) for candidate_id in history_ids
                ),
            )
            if not self._stages.fits(reconcile_input, "reconcile"):
                raise self._input_budget_error(reconcile_input, "reconcile", input_item_count=len(members))
            known_ids.add(reconcile_input.component_id)
            with self._usage(ModelUsagePurpose.TOPIC_MEMORY_GENERATION):
                reconciled = (await self._stages.reconciler.generate(reconcile_input)).output.proposals
            self._validate_reconciliation(
                members,
                reconciled,
                candidates,
                evidence,
                allowed_targets=set(history_ids),
                internal_ids=known_ids,
            )
            coordinated.extend(reconciled)
        validated = self._validate_proposals(
            tuple(coordinated),
            evidence,
            candidates,
            internal_ids=known_ids,
        )
        return validated, candidates

    async def _related_candidates(
        self,
        scope_id: str,
        proposal: TopicMemoryProposal,
        signature: str,
    ) -> tuple[tuple[TopicMemorySearchHit, ...], tuple[float, ...] | None]:
        vector = await self._signature_vector(proposal.content)
        if not signature and vector is None:
            return (), None
        profile = None if self._embedding_model is None else self._embedding_model.profile
        query = (
            signature or f"{proposal.content.title}\n{proposal.content.summary}"[:MAX_TOPIC_MEMORY_QUERY_LENGTH].strip()
        )
        mode: TopicMemorySearchMode = "fts" if vector is None else "hybrid" if signature else "vector"
        async with self._database.transaction(consistent_snapshot=True) as connection:
            result = await self._topics.search(
                connection,
                scope_id,
                query,
                limit=self._history_max,
                mode=mode,
                query_vector=vector,
                embedding_profile=profile,
            )
        return result.hits, vector

    async def _signature_vector(self, content: TopicMemoryContent) -> tuple[float, ...] | None:
        if self._embedding_model is None:
            return None
        chunks = chunk_topic_memory_detail(content.detail)
        texts = (f"{content.title}\n{content.summary}", *(chunk.text for chunk in chunks))
        with self._usage(ModelUsagePurpose.TOPIC_MEMORY_RECALL, embedding=True):
            vectors = (await self._embed(tuple(texts))).vectors
        return topic_memory_vector_centroid(
            vectors[0],
            tuple((len(chunk.text), vector) for chunk, vector in zip(chunks, vectors[1:], strict=True)),
            topic_length=len(texts[0]),
        )

    async def _prepare_operations(
        self,
        scope_id: str,
        proposals: tuple[TopicMemoryProposal, ...],
        candidates: Mapping[str, PublishedTopicMemory],
        evidence: Mapping[str, StoredSource],
    ) -> tuple[PreparedTopicMemoryOperation, ...]:
        operations: list[PreparedTopicMemoryOperation] = []
        used_targets: set[str] = set()
        for proposal in proposals:
            proposal_id = proposal.proposal_id
            if proposal_id is None:
                raise TopicMemoryGenerationError("invalid_proposal")
            current = None
            artifact_id = ""
            artifact_lineage: tuple[ArtifactRef, ...] = ()
            if proposal.candidate_id is not None:
                if proposal.candidate_id in used_targets:
                    raise TopicMemoryGenerationError("duplicate_target")
                used_targets.add(proposal.candidate_id)
                published = candidates[proposal.candidate_id]
                current = published.topic
                artifact_id = current.artifact_id
                artifact_lineage = (current.as_ref(),)
            else:
                artifact_id = self._id_factory()
            source_refs = tuple(evidence[evidence_id].ref for evidence_id in proposal.evidence_ids)
            content = TopicMemoryContent.model_validate(proposal.content.model_dump())
            draft = TopicMemoryDraft(
                content=content,
                sources=source_refs,
                artifacts=artifact_lineage + self._used_prompt_refs(),
            )
            projection = await self._projection(content)
            operations.append(
                PreparedTopicMemoryOperation(
                    proposal_id=proposal_id,
                    artifact_id=artifact_id,
                    current=current,
                    draft=draft,
                    projection=projection,
                )
            )
        return tuple(operations)

    async def _projection(self, content: TopicMemoryContent) -> TopicMemoryProjection:
        if self._embedding_model is None:
            return prepare_topic_memory_projection(content)
        chunks = chunk_topic_memory_detail(content.detail)
        texts = (f"{content.title}\n{content.summary}", *(chunk.text for chunk in chunks))
        with self._usage(ModelUsagePurpose.TOPIC_MEMORY_INDEXING, embedding=True):
            vectors = (await self._embed(tuple(texts))).vectors
        return prepare_topic_memory_projection(
            content,
            topic_embedding=vectors[0],
            chunk_embeddings=tuple(vectors[1:]),
            embedding_profile=self._embedding_model.profile,
        )

    def _validate_probes(
        self,
        probes: tuple[TopicMemoryProbe, ...],
        evidence: tuple[TopicMemoryEvidence, ...],
    ) -> None:
        allowed = {item.evidence_id for item in evidence}
        if any(not probe.evidence_ids or not set(probe.evidence_ids) <= allowed for probe in probes):
            raise TopicMemoryGenerationError("invalid_evidence")

    def _validate_proposals(
        self,
        proposals: tuple[TopicMemoryProposal, ...],
        evidence: tuple[TopicMemoryEvidence, ...],
        candidates: Mapping[str, PublishedTopicMemory],
        *,
        internal_ids: Iterable[str] = (),
    ) -> tuple[TopicMemoryProposal, ...]:
        if len(proposals) > MAX_TOPIC_MEMORY_STAGE_ITEMS:
            raise TopicMemoryGenerationError("proposal_limit")
        if not proposals:
            return ()
        allowed = {item.evidence_id for item in evidence}
        selected = {item.candidate_id for item in proposals}
        admission = TopicMemoryContentAdmission(
            {item.evidence_id: item.content for item in evidence},
            {key: value.topic.content for key, value in candidates.items() if key in selected},
            internal_ids=(
                *internal_ids,
                *candidates,
                *(item.proposal_id for item in proposals if item.proposal_id is not None),
            ),
        )
        targets: set[str] = set()
        proposal_ids: set[str] = set()
        for proposal in proposals:
            if not proposal.evidence_ids or not set(proposal.evidence_ids) <= allowed:
                raise TopicMemoryGenerationError("invalid_evidence")
            if proposal.candidate_id is not None:
                if proposal.candidate_id not in candidates or proposal.candidate_id in targets:
                    raise TopicMemoryGenerationError("invalid_target")
                targets.add(proposal.candidate_id)
            if proposal.proposal_id is not None:
                if proposal.proposal_id in proposal_ids:
                    raise TopicMemoryGenerationError("invalid_proposal")
                proposal_ids.add(proposal.proposal_id)
            rejection = admission.rejection(proposal.content, proposal.evidence_ids, proposal.candidate_id)
            if rejection is not None:
                raise TopicMemoryGenerationError(rejection)
        return proposals

    def _validate_reconciliation(
        self,
        inputs: tuple[TopicMemoryProposal, ...],
        outputs: tuple[TopicMemoryProposal, ...],
        candidates: Mapping[str, PublishedTopicMemory],
        evidence: tuple[TopicMemoryEvidence, ...],
        *,
        allowed_targets: set[str],
        internal_ids: Iterable[str] = (),
    ) -> None:
        input_ids = {item.proposal_id for item in inputs}
        output_ids = [item.proposal_id for item in outputs]
        if None in output_ids or not set(output_ids) <= input_ids or len(output_ids) != len(set(output_ids)):
            raise TopicMemoryGenerationError("invalid_reconciliation")
        input_targets = {item.candidate_id for item in inputs if item.candidate_id is not None}
        input_by_id = {item.proposal_id: item for item in inputs}
        output_by_id = {item.proposal_id: item for item in outputs}
        input_evidence = {evidence_id for item in inputs for evidence_id in item.evidence_ids}
        output_targets = [item.candidate_id for item in outputs if item.candidate_id is not None]
        if (
            not input_targets <= set(output_targets)
            or not set(output_targets) <= allowed_targets
            or len(output_targets) != len(set(output_targets))
        ):
            raise TopicMemoryGenerationError("identity_merge")
        if any(
            item.proposal_id not in output_by_id or output_by_id[item.proposal_id].candidate_id != item.candidate_id
            for item in input_by_id.values()
            if item.candidate_id is not None
        ):
            raise TopicMemoryGenerationError("identity_merge")
        if any(not set(item.evidence_ids) <= input_evidence for item in outputs):
            raise TopicMemoryGenerationError("invalid_reconciliation")
        self._validate_proposals(
            outputs,
            evidence,
            candidates,
            internal_ids=(*internal_ids, *(item.proposal_id for item in inputs if item.proposal_id is not None)),
        )

    def _usage(self, purpose: ModelUsagePurpose, *, embedding: bool = False):
        reporter = self._usage_reporter
        if reporter is None:
            return nullcontext()

        return bind_usage_reporter(
            reporter,
            generation_purpose=None if embedding else purpose,
            embedding_purpose=purpose if embedding else None,
        )


async def _project_window(
    stored: tuple[StoredSource, ...],
    sources: SourceRepository,
) -> tuple[TopicMemoryEvidence, ...]:
    result: list[TopicMemoryEvidence] = []
    characters = 0
    for index, item in enumerate(stored, start=1):
        if is_generation_eligible(item.value):
            projected = await _project_evidence(index, item, sources)
            characters += len(projected.content)
            if characters > MAX_TOPIC_MEMORY_SOURCE_CHARACTERS:
                raise TopicMemoryGenerationError("source_complexity_limit")
            result.append(projected)
    return tuple(result)


async def _project_evidence(
    index: int,
    stored: StoredSource,
    sources: SourceRepository,
) -> TopicMemoryEvidence:
    materialized = (
        stored.value if isinstance(stored.value, SourceObservation) else await sources.read_value(stored.value)
    )
    content = await asyncio.to_thread(
        _canonical_source_content,
        stored.ref.source_type,
        materialized,
    )
    return TopicMemoryEvidence(
        evidence_id=_evidence_id(index),
        source_type=stored.ref.source_type,
        content=content,
    )


def _canonical_source_content(source_type: str, materialized: object) -> str:
    if isinstance(materialized, str):
        if len(materialized) > MAX_TOPIC_MEMORY_SOURCE_CHARACTERS:
            raise TopicMemoryGenerationError("source_complexity_limit")
        if not materialized.strip():
            raise TopicMemoryGenerationError("unsupported_evidence")
        return materialized
    payload = _source_evidence_payload(source_type, materialized)
    _require_bounded_source_payload(payload)
    content = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    if len(content) > MAX_TOPIC_MEMORY_SOURCE_CHARACTERS:
        raise TopicMemoryGenerationError("source_complexity_limit")
    if not content.strip():
        raise TopicMemoryGenerationError("unsupported_evidence")
    return content


def _source_evidence_payload(source_type: str, materialized: object) -> dict[str, object]:
    payload: dict[str, object]
    if source_type == CONTENT_SOURCE_NAME and isinstance(materialized, ContentCapture):
        payload = {
            "content": materialized.content,
            "metadata": materialized.metadata,
        }
    elif source_type == EXTERNAL_SKILL_SNAPSHOT_SOURCE_NAME and isinstance(
        materialized,
        ExternalSkillSnapshotCapture,
    ):
        payload = {
            "manifest": materialized.snapshot.manifest,
            "mode": materialized.mode.value,
        }
    elif source_type == SKILL_USAGE_SOURCE_NAME and isinstance(materialized, SkillUsageCapture):
        # Stable identities, package digests and host/target locators remain
        # server-owned lineage, not model input. Preserve unknown observations.
        payload = {
            "selected": materialized.selected,
            "invoked": materialized.invoked.value,
            "validation": materialized.validation.value,
            "outcome": materialized.outcome.value,
        }
    elif source_type == SKILL_PACKAGE_UPLOAD_SOURCE_NAME and isinstance(materialized, SkillPackageUploadCapture):
        payload = {"name": materialized.name, "description": materialized.description}
    elif isinstance(materialized, SourceObservation):
        payload = _observation_evidence_payload(materialized)
    else:
        raise TopicMemoryGenerationError("unsupported_evidence")
    return payload


def _observation_evidence_payload(source: SourceObservation) -> dict[str, object]:
    for projection in source.projections:
        if projection.key == TEXT_EVIDENCE_PROJECTION_KEY:
            evidence = TextEvidence.model_validate(projection.value)
            return {"content": evidence.content, "metadata": evidence.metadata}
    # Legacy adapters can submit captured payloads without a named projection.
    # Keep the envelope identity in lineage, as for native Source evidence.
    return {
        key: value
        for key, value in source.payload.items()
        if key not in {"name", "definition_version", "materialization"}
    }


def _require_bounded_source_payload(payload: object) -> None:
    # Traverse lazily: do not copy a huge container or serialize deep metadata
    # before enforcing node/depth/text limits. Cycles hit the depth bound.
    pending = [(iter((payload,)), 0)]
    nodes = characters = 0
    while pending:
        values, depth = pending[-1]
        try:
            value = next(values)
        except StopIteration:
            pending.pop()
            continue
        nodes += 1
        if nodes > MAX_TOPIC_MEMORY_SOURCE_NODES or depth > MAX_TOPIC_MEMORY_SOURCE_DEPTH:
            raise TopicMemoryGenerationError("source_complexity_limit")
        if isinstance(value, str):
            characters += len(value)
        elif isinstance(value, dict):
            pending.append((iter(value), depth + 1))
            pending.append((iter(value.values()), depth + 1))
        elif isinstance(value, (list, tuple)):
            pending.append((iter(value), depth + 1))
        if characters > MAX_TOPIC_MEMORY_SOURCE_CHARACTERS:
            raise TopicMemoryGenerationError("source_complexity_limit")


def _evidence_id(index: int) -> str:
    return f"evidence-{index:04d}"


def _opaque_ordinal(value: str) -> int:
    try:
        return int(value.rsplit("-", maxsplit=1)[1])
    except (IndexError, ValueError):
        raise TopicMemoryGenerationError("invalid_evidence") from None


def _historical_slot(candidate_id: str, published: PublishedTopicMemory) -> TopicMemoryHistoricalSlot:
    return TopicMemoryHistoricalSlot(candidate_id=candidate_id, **published.topic.content.model_dump())


def _bounded_planner_input(
    probes: tuple[TopicMemoryProbeCandidates, ...],
    historical: tuple[TopicMemoryHistoricalPreview, ...],
) -> TopicMemoryPlannerInput:
    bounded_probes = tuple(
        probe.model_copy(
            update={
                "query": probe.query.strip()[:_PLANNER_TEXT_PREVIEW_LENGTH] or "_",
                "keywords": _bounded_planner_keywords(probe.keywords),
            }
        )
        for probe in probes
    )
    bounded_history = tuple(
        item.model_copy(
            update={
                "title": item.title[:_PLANNER_TEXT_PREVIEW_LENGTH],
                "summary": item.summary[:_PLANNER_TEXT_PREVIEW_LENGTH],
                "snippet": (None if item.snippet is None else item.snippet[:_PLANNER_TEXT_PREVIEW_LENGTH]),
            }
        )
        for item in historical
    )
    return TopicMemoryPlannerInput(probes=bounded_probes, historical=bounded_history)


def _bounded_planner_keywords(values: tuple[str, ...]) -> tuple[str, ...]:
    selected: list[str] = []
    remaining = _PLANNER_TEXT_PREVIEW_LENGTH
    for value in values:
        keyword = value.strip()
        if not keyword or remaining < 1:
            continue
        selected.append(keyword[:remaining])
        remaining -= min(len(keyword), remaining)
    return tuple(selected)


def _deterministic_plan(probes: tuple[TopicMemoryProbeCandidates, ...]) -> TopicMemoryPlannerOutput:
    pending = set(range(len(probes)))
    items: list[TopicMemoryPlanItem] = []
    while pending:
        component = {min(pending)}
        candidates = set(probes[next(iter(component))].candidate_ids)
        changed = True
        while changed:
            changed = False
            for index in sorted(pending - component):
                if candidates.intersection(probes[index].candidate_ids):
                    component.add(index)
                    candidates.update(probes[index].candidate_ids)
                    changed = True
        pending.difference_update(component)
        ordered = tuple(sorted(component))
        common = set(probes[ordered[0]].candidate_ids)
        for index in ordered[1:]:
            common.intersection_update(probes[index].candidate_ids)
        target = next((item for item in probes[ordered[0]].candidate_ids if item in common), None)
        items.append(
            TopicMemoryPlanItem(
                probe_ids=tuple(probes[index].probe_id for index in ordered),
                candidate_id=target,
            )
        )
    return TopicMemoryPlannerOutput(items=tuple(items))


def _distinct_hits(values: Iterable[TopicMemorySearchHit]) -> tuple[TopicMemorySearchHit, ...]:
    observed: set[tuple[str, int]] = set()
    result: list[TopicMemorySearchHit] = []
    for hit in values:
        key = _artifact_key(hit.artifact_ref)
        if key not in observed:
            observed.add(key)
            result.append(hit)
    return tuple(result)


def _artifact_key(ref: ArtifactRef) -> tuple[str, int]:
    return ref.artifact_id, ref.revision


def _operation_order(operation: PreparedTopicMemoryOperation) -> tuple[bytes, bytes]:
    return operation.artifact_id.encode(), operation.proposal_id.encode()


def validate_topic_memory_provider_settings(inference: InferenceConfig) -> None:
    """Keep worker requests stateless and limited to known bounded SDK paths."""
    from powercontext.builtin.runtime.composition import BuiltinConfigurationError

    generation = {
        "max_tokens",
        "temperature",
        "top_p",
        "top_k",
        "seed",
        "presence_penalty",
        "frequency_penalty",
        "timeout",
        "openai_reasoning_effort",
        "openai_text_verbosity",
        "service_tier",
        "openai_service_tier",
        "anthropic_service_tier",
        "anthropic_effort",
    }
    providers = {
        "openai",
        "openai-chat",
        "openai-responses",
        "anthropic",
        "azure",
        "azure-responses",
        "deepseek",
        "openrouter",
    }
    embedding_providers = providers | {"minimax"}
    generation_settings = dict(inference.generation_model_settings)
    if "extra_body" in generation_settings:
        body = generation_settings.pop("extra_body")
        template = body.get("chat_template_kwargs") if isinstance(body, dict) else None
        # Only this Chat Completions flag is allowed; extra_body can otherwise
        # override SDK output limits, messages, or tools after budget validation.
        if not (
            inference.generation_model is not None
            and inference.generation_model.startswith("openai-chat:")
            and isinstance(body, dict)
            and set(body) == {"chat_template_kwargs"}
            and isinstance(template, dict)
            and set(template) == {"enable_thinking"}
            and template["enable_thinking"] is False
        ):
            raise BuiltinConfigurationError("topic-memory-provider-budget")
    for name, settings, allowed, provider_names in (
        (inference.generation_model, generation_settings, generation, providers),
        (
            inference.embedding_model,
            inference.embedding_model_settings,
            {"dimensions", "truncate"},
            embedding_providers,
        ),
    ):
        # The built-in test model has no external I/O; retain hermetic workers.
        if name is not None and name != "test" and name.split(":", 1)[0] not in provider_names:
            raise BuiltinConfigurationError("topic-memory-provider-budget")
        if set(settings) - allowed or any(
            value is not None
            and (not isinstance(value, (str, int, float, bool)) or (isinstance(value, str) and len(value) > 128))
            for value in settings.values()
        ):
            raise BuiltinConfigurationError("topic-memory-provider-budget")


def run_topic_memory_worker(
    spec: TopicMemoryWorkerSpec,
    assignment: ArtifactProcessingWorkAssignment,
    /,
) -> ArtifactProcessingWorkerCompletion:
    """Module-level spawn entrypoint that owns one narrow child lifecycle."""

    return asyncio.run(_run_topic_memory_worker(spec, assignment))


async def _run_topic_memory_worker(
    spec: TopicMemoryWorkerSpec,
    assignment: ArtifactProcessingWorkAssignment,
) -> ArtifactProcessingWorkerCompletion:
    if await _process_topic_dream_if_pending(spec, assignment):
        return ArtifactProcessingWorkerCompletion()
    async with _open_topic_memory_processor(spec, assignment.scope_id) as processor:
        return await processor.process(assignment)


async def _process_topic_dream_if_pending(
    spec: TopicMemoryWorkerSpec, assignment: ArtifactProcessingWorkAssignment
) -> bool:
    """Dispatch explicit Dream work without consuming the Topic Source cursor."""

    from powercontext.builtin.dream.bindings import operations_for_binding
    from powercontext.builtin.inference.usage import UsageReportingEmbeddingModel
    from powercontext.builtin.runtime.composition import _dream_generator, _embedding_models, open_builtin_contexts
    from powercontext.builtin.runtime.dream_processing import process_dream_invocation

    operations = operations_for_binding(assignment.binding_name)
    if not operations or not spec.config.runtime.dream_enabled:
        return False
    # Mirror the Memory family worker: the dream branch stays observable when the
    # spawn entrypoint supplied worker tracing or model instrumentation.
    observation = worker_observability.get()
    instrumentation = None if observation is None else observation.instrumentation
    tracing = None if observation is None else observation.tracing
    async with AsyncExitStack() as resources:
        raw_embedding, _ = await _embedding_models(
            spec.config.inference, resources, instrumentation, disable_provider_retries=True
        )
        embedding = None if raw_embedding is None else UsageReportingEmbeddingModel(raw_embedding)
        contexts = await resources.enter_async_context(
            open_builtin_contexts(spec.config, embedding_model=embedding, tracing=tracing, _topic_memory_worker=True)
        )
        async with contexts.database.transaction() as connection:
            record = await DreamRepository().next_pending(
                connection,
                assignment.scope_id,
                operations,
                through_generation=assignment.claimed_request_generation,
            )
        if record is None:
            return False
        generator = await _dream_generator(spec.config.inference, record.run.budget, resources, instrumentation)
        security = None
        if spec.worker_security is not None:
            from powercontext.builtin.authz.worker import open_worker_security

            security = await resources.enter_async_context(
                open_worker_security(spec.worker_security, contexts.database)
            )
        with bind_usage_reporter(
            contexts.model_usage_reporter(assignment.scope_id),
            generation_purpose=ModelUsagePurpose.TOPIC_MEMORY_GENERATION,
        ):
            try:
                return await process_dream_invocation(
                    contexts,
                    assignment,
                    config=spec.config,
                    generator=generator,
                    security=security,
                )
            finally:
                await contexts.flush_model_usage()


@asynccontextmanager
async def _open_topic_memory_processor(spec: TopicMemoryWorkerSpec, scope_id: str):
    """Reconstruct only the DB, index and inference resources needed by one child."""

    from pydantic_ai.settings import ModelSettings

    from powercontext.builtin.artifacts.prompt import PromptRegistry
    from powercontext.builtin.artifacts.prompt.builtin import builtin_prompt_definitions
    from powercontext.builtin.artifacts.topic_memory.generation import (
        TOPIC_MEMORY_EVOLVE_INSTRUCTIONS,
        TOPIC_MEMORY_GLOBAL_INSTRUCTIONS,
        TOPIC_MEMORY_PLANNER_INSTRUCTIONS,
        TOPIC_MEMORY_PROBE_INSTRUCTIONS,
        TOPIC_MEMORY_RECONCILE_INSTRUCTIONS,
        TOPIC_MEMORY_REDUCTION_INSTRUCTIONS,
        TOPIC_MEMORY_TEMPORARY_INSTRUCTIONS,
        BudgetedTopicMemoryGenerator,
        topic_memory_stage_budget,
        topic_memory_stage_fixed_prompt,
        validate_topic_memory_stage_capacity,
    )
    from powercontext.builtin.inference.pydantic_ai import InferenceLimits, PydanticAIStructuredGenerator
    from powercontext.builtin.inference.usage import UsageReportingEmbeddingModel, UsageReportingStructuredGenerator
    from powercontext.builtin.runtime.composition import (
        BuiltinConfigurationError,
        _embedding_models,
        _open_pydantic_ai_model,
        open_builtin_contexts,
    )

    observation = worker_observability.get()
    instrumentation = None if observation is None else observation.instrumentation
    tracing = None if observation is None else observation.tracing
    config = spec.config
    inference = config.inference
    if inference.generation_model is None:
        raise BuiltinConfigurationError("topic-memory-generation")
    validate_topic_memory_provider_settings(inference)
    budget = topic_memory_stage_budget(
        context_window_tokens=inference.generation_model_context_window_tokens,
        max_requests=inference.generation_max_requests,
        model_settings=inference.generation_model_settings,
    )
    validate_topic_memory_stage_capacity(budget, character_token_estimator())
    limits = InferenceLimits(
        timeout_seconds=inference.generation_timeout_seconds,
        max_requests=inference.generation_max_requests,
        max_output_tokens_per_request=budget.max_output_tokens_per_request,
        output_tokens_limit=budget.output_tokens_limit,
        allow_continuations=False,
    )
    settings = cast(ModelSettings, dict(inference.generation_model_settings))
    async with AsyncExitStack() as resources:
        _, model = await _open_pydantic_ai_model(
            inference.generation_model,
            base_url=inference.generation_base_url,
            headers=inference.generation_headers,
            resources=resources,
            instrumentation=instrumentation,
            disable_provider_retries=True,
            streaming=inference.generation_streaming,
            stream_idle_timeout_seconds=inference.generation_stream_idle_timeout_seconds,
            protection=inference.protection,
        )
        raw_embedding, _ = await _embedding_models(inference, resources, instrumentation, disable_provider_retries=True)
        embedding = None if raw_embedding is None else UsageReportingEmbeddingModel(raw_embedding)
        contexts = await resources.enter_async_context(
            open_builtin_contexts(
                config,
                embedding_model=embedding,
                tracing=tracing,
                _topic_memory_worker=True,
                prompt_registry=PromptRegistry(
                    builtin_prompt_definitions(config.runtime.memory_extraction_profile),
                    supported=frozenset(
                        f"topic_memory.{stage}"
                        for stage in ("probe", "global", "planner", "evolve", "temporary", "reduce", "reconcile")
                    ),
                ),
            )
        )

        for stage_name in ("probe", "global", "planner", "evolve", "temporary", "reduce", "reconcile"):
            await resources.enter_async_context(contexts.prompts.bind(scope_id, f"topic_memory.{stage_name}"))

        fixed_prompts: dict[str, str] = {}
        prompt_refs: dict[str, ArtifactRef] = {}

        def stage(
            input_type: type[BaseModel],
            output_type: type[BaseModel],
            instructions: str,
            name: str,
            stage_name: str,
        ):
            prompt_key = f"topic_memory.{stage_name}"
            selection = current_prompt(prompt_key)
            if selection is not None and selection.artifact is not None:
                prompt_refs[stage_name] = selection.artifact
            selected_instructions = instructions if selection is None else selection.compiled_instructions
            fixed_prompt = topic_memory_stage_fixed_prompt(selected_instructions, input_type, output_type)
            fixed_prompts[stage_name] = fixed_prompt
            raw = PydanticAIStructuredGenerator(
                model=model,
                instructions=selected_instructions,
                input_type=input_type,
                output_type=output_type,
                limits=limits,
                model_settings=settings,
                name=name,
                prompt_key=prompt_key,
            )
            bounded = BudgetedTopicMemoryGenerator(
                raw,
                estimator=contexts.token_estimator,
                budget=budget,
                fixed_prompt=fixed_prompt,
            )
            return UsageReportingStructuredGenerator(bounded)

        stages = TopicMemoryStageSet(
            probe=stage(
                TopicMemoryProbeInput,
                TopicMemoryProbeOutput,
                TOPIC_MEMORY_PROBE_INSTRUCTIONS,
                "topic_probe",
                "probe",
            ),
            global_evolver=stage(
                TopicMemoryGlobalInput,
                TopicMemoryGlobalOutput,
                TOPIC_MEMORY_GLOBAL_INSTRUCTIONS,
                "topic_global",
                "global",
            ),
            planner=stage(
                TopicMemoryPlannerInput,
                TopicMemoryPlannerOutput,
                TOPIC_MEMORY_PLANNER_INSTRUCTIONS,
                "topic_planner",
                "planner",
            ),
            evolver=stage(
                TopicMemoryEvolveInput,
                TopicMemoryEvolveOutput,
                TOPIC_MEMORY_EVOLVE_INSTRUCTIONS,
                "topic_evolver",
                "evolve",
            ),
            temporary=stage(
                TopicMemoryTemporaryInput,
                TopicMemoryTemporaryOutput,
                TOPIC_MEMORY_TEMPORARY_INSTRUCTIONS,
                "topic_temporary",
                "temporary",
            ),
            reconciler=stage(
                TopicMemoryReconcileInput,
                TopicMemoryReconcileOutput,
                TOPIC_MEMORY_RECONCILE_INSTRUCTIONS,
                "topic_reconciler",
                "reconcile",
            ),
            reducer=stage(
                TopicMemoryReductionInput,
                TopicMemoryReductionOutput,
                TOPIC_MEMORY_REDUCTION_INSTRUCTIONS,
                "topic_reducer",
                "reduce",
            ),
            estimator=contexts.token_estimator,
            input_tokens_limit=budget.input_tokens_limit,
            fixed_prompts=fixed_prompts,
            max_requests=budget.max_requests,
            transcript_reserve=budget.transcript_reserve,
        )

        from powercontext.builtin.runtime.topic_memory_scope import TopicMemoryScopeProcessor

        security = None
        if spec.worker_security is not None:
            # Runtime-only SDK workers do not require the optional Server adapter.
            from powercontext.builtin.authz.worker import open_worker_security

            security = await resources.enter_async_context(
                open_worker_security(spec.worker_security, contexts.database)
            )
        if security is not None:
            await security.authorize_scope(scope_id)
        commit_authorizer = None if security is None else security.topic_commit
        publisher = TopicMemoryAtomicPublisher(
            contexts.database,
            contexts.repositories.sources,
            contexts.repositories.topic_memories,
            cursors=contexts.repositories.cursors,
            leases=contexts.repositories.processing_leases,
            commit_authorizer=commit_authorizer,
        )
        processor = TopicMemoryProcessor(
            database=contexts.database,
            sources=contexts.repositories.sources,
            topics=contexts.repositories.topic_memories,
            stages=stages,
            publisher=publisher,
            embedding_model=embedding,
            # The runtime-owned recorder writes this window's usage, so the
            # worker's own deadline never covers a statistics transaction.
            usage_reporter=contexts.model_usage_reporter(scope_id),
            history_max_candidates=config.runtime.topic_memory_history_max_candidates,
            history_rrf_threshold=config.runtime.topic_memory_history_rrf_threshold,
            history_min_candidates=config.runtime.topic_memory_history_min_candidates,
            prompt_refs=prompt_refs,
            tracing=tracing,
        )
        try:
            yield TopicMemoryScopeProcessor(
                contexts.database,
                processor,
                TopicMemoryWindowSelector(
                    contexts.database,
                    contexts.repositories.sources,
                    contexts.token_estimator,
                    context_window_tokens=inference.generation_model_context_window_tokens,
                ),
                cursors=contexts.repositories.cursors,
                leases=contexts.repositories.processing_leases,
                commit_authorizer=commit_authorizer,
                source_window_limit=config.runtime.topic_memory_source_window_limit,
            )
        finally:
            # A completed window leaves its own usage readable, matching the
            # family worker's completion boundary.
            await contexts.flush_model_usage()


def _topic_memory_item_count(value: BaseModel) -> int | None:
    for name in ("evidence", "items", "proposals", "candidates", "temporary"):
        items = getattr(value, name, None)
        if isinstance(items, (tuple, list)):
            return len(items)
    return None


__all__ = [
    "PreparedTopicMemoryOperation",
    "TopicMemoryAtomicPublisher",
    "TopicMemoryProcessor",
    "TopicMemoryStageSet",
    "TopicMemoryWindowAssignment",
    "TopicMemoryWindowSelector",
    "TopicMemoryWorkerSpec",
    "run_topic_memory_worker",
]
