# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""User-owned PowerContext authorization persistence for Agent Hosts."""

from __future__ import annotations

import json
import os
import stat
import sys
import tempfile
from dataclasses import dataclass
from importlib import import_module
from pathlib import Path
from typing import Literal

from powercontext.client.transport_policy import normalize_client_url

AuthorizationStatus = Literal["configured", "not_configured", "url_mismatch", "invalid", "unsafe_permissions"]
SetupAuthorizationStatus = Literal[
    "configured", "preserved", "cleared", "not_configured", "url_mismatch", "invalid", "unsafe_permissions"
]

_AUTHORIZATION_ENVIRONMENTS = {
    "codex": "POWERCONTEXT_CODEX_AUTHORIZATION",
    "claude-code": "POWERCONTEXT_CLAUDE_AUTHORIZATION",
    "opencode": "POWERCONTEXT_OPENCODE_AUTHORIZATION",
    "pi": "POWERCONTEXT_PI_AUTHORIZATION",
    "workbuddy": "POWERCONTEXT_WORKBUDDY_AUTHORIZATION",
    "dsh": "POWERCONTEXT_DSH_AUTHORIZATION",
    "minimax": "POWERCONTEXT_MINIMAX_AUTHORIZATION",
}
_CODEX_AUTHORIZATION_ENVIRONMENT = "POWERCONTEXT_CODEX_AUTHORIZATION"


@dataclass(frozen=True, slots=True)
class AuthorizationResolution:
    """Redacted result of resolving one persisted credential."""

    status: AuthorizationStatus
    authorization: str | None


def normalize_authorization(value: str) -> str:
    """Return a complete Bearer header without exposing invalid input in errors."""

    if not isinstance(value, str) or any(ord(character) < 32 or ord(character) == 127 for character in value):
        raise ValueError("authorization must be a non-empty single-token credential")  # noqa: TRY003
    normalized = value.strip()
    if normalized.casefold() == "bearer":
        raise ValueError("authorization must be a non-empty single-token credential")  # noqa: TRY003
    credential = normalized[7:] if normalized.casefold().startswith("bearer ") else normalized
    if (
        not credential
        or not credential.isascii()
        or not credential.isprintable()
        or any(character.isspace() for character in credential)
        or len(credential) > 8192
    ):
        raise ValueError("authorization must be a non-empty single-token credential")  # noqa: TRY003
    return f"Bearer {credential}"


def credential_path(host: str) -> Path:
    """Return a PowerContext-owned credential path below the host config root."""

    from powercontext.cli.dsh_runtime import dsh_home

    roots = {
        "codex": Path(os.environ.get("CODEX_HOME", Path.home() / ".codex")).expanduser(),
        "claude-code": Path(os.environ.get("CLAUDE_CONFIG_DIR", Path.home() / ".claude")).expanduser(),
        "opencode": Path(os.environ.get("OPENCODE_CONFIG_DIR", Path.home() / ".config" / "opencode")).expanduser(),
        "pi": Path(os.environ.get("PI_CODING_AGENT_DIR", Path.home() / ".pi" / "agent")).expanduser(),
        "workbuddy": Path(os.environ.get("WORKBUDDY_HOME", Path.home() / ".workbuddy")).expanduser(),
        "dsh": dsh_home(),
    }
    try:
        root = roots[host]
    except KeyError as error:
        raise ValueError("unsupported persisted authorization host") from error  # noqa: TRY003
    return root / "powercontext" / "credentials.json"


def _authorization_bytes(path: Path, *, server_url: str, value: str) -> bytes:
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise ValueError("credential path must be a regular file")  # noqa: TRY003
    payload = {
        "version": 1,
        "server_url": normalize_client_url(server_url),
        "authorization": normalize_authorization(value),
    }
    return (json.dumps(payload, ensure_ascii=True, separators=(",", ":")) + "\n").encode()


def write_stored_authorization(path: Path, *, server_url: str, value: str) -> None:
    """Atomically persist one URL-bound authorization record."""

    path = Path(path).expanduser()
    content = _authorization_bytes(path, server_url=server_url, value=value)
    parent = path.parent
    parent.mkdir(parents=True, exist_ok=True)
    if os.name != "nt":
        parent.chmod(0o700)
    fd, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=parent)
    temporary = Path(temporary_name)
    try:
        if os.name != "nt":
            os.fchmod(fd, 0o600)
        with os.fdopen(fd, "wb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def read_stored_authorization(path: Path, *, server_url: str) -> AuthorizationResolution:
    """Resolve a credential only when its file and URL binding are safe."""

    path = Path(path).expanduser()
    if not path.exists():
        return AuthorizationResolution("not_configured", None)
    if path.is_symlink() or not path.is_file():
        return AuthorizationResolution("invalid", None)
    if os.name != "nt" and stat.S_IMODE(path.stat().st_mode) & 0o077:
        return AuthorizationResolution("unsafe_permissions", None)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict) or payload.get("version") != 1:
            raise ValueError("invalid persisted authorization record")  # noqa: TRY003, TRY301
        stored_url = normalize_client_url(payload["server_url"])
        authorization = normalize_authorization(payload["authorization"])
        effective_url = normalize_client_url(server_url)
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        return AuthorizationResolution("invalid", None)
    if stored_url != effective_url:
        return AuthorizationResolution("url_mismatch", None)
    return AuthorizationResolution("configured", authorization)


def clear_stored_authorization(path: Path) -> Literal["cleared", "not_configured"]:
    """Delete a PowerContext-owned credential without following symlinks."""

    path = Path(path).expanduser()
    if not path.exists():
        return "not_configured"
    if path.is_symlink() or not path.is_file():
        raise ValueError("credential path must be a regular file")  # noqa: TRY003
    path.unlink()
    return "cleared"


def authorization_updates(connection) -> tuple[dict[Path, bytes], SetupAuthorizationStatus]:
    """Validate credentials before publishing the connection and its URL binding together."""
    path = credential_path(connection.host)
    value = setup_authorization_value(connection.host)
    if value is not None and value.strip():
        content = _authorization_bytes(path, server_url=connection.server_url, value=value)
        path.parent.mkdir(parents=True, exist_ok=True)
        if os.name != "nt":
            path.parent.chmod(0o700)
        return {path: content}, "configured"
    resolution = read_stored_authorization(path, server_url=connection.server_url)
    return {}, "preserved" if resolution.status == "configured" else resolution.status


def setup_authorization_value(host: str) -> str | None:
    """Read the host-specific setup token, falling back to the shared token."""

    from powercontext.cli.transport import setup_environment

    values = setup_environment() | dict(os.environ)
    return values.get(_AUTHORIZATION_ENVIRONMENTS[host]) or values.get("POWERCONTEXT_CLIENT_API_TOKEN")


def validate_setup_authorization(host: str) -> None:
    """Reject invalid explicit credentials before changing host configuration."""
    if host in _AUTHORIZATION_ENVIRONMENTS:
        value = setup_authorization_value(host)
        if value is not None and value.strip():
            normalize_authorization(value)
    elif host == "zcode":
        from powercontext.cli.transport import setup_environment

        value = (setup_environment() | dict(os.environ)).get("POWERCONTEXT_ZCODE_AUTHORIZATION")
        if value and normalize_authorization(value) != value:
            raise ValueError("POWERCONTEXT_ZCODE_AUTHORIZATION must be a complete Bearer header")  # noqa: TRY003


def configure_codex_desktop_authorization(value: str) -> bool:
    """Persist Codex authorization in the Windows user environment used by Desktop."""

    if sys.platform != "win32":
        return False
    authorization = normalize_authorization(value)
    _write_windows_user_environment(_CODEX_AUTHORIZATION_ENVIRONMENT, authorization)
    return True


def read_codex_desktop_authorization() -> str | None:
    """Read and validate the Windows user environment value used by Codex Desktop."""

    if sys.platform != "win32":
        return None
    value = _read_windows_user_environment(_CODEX_AUTHORIZATION_ENVIRONMENT)
    if value is None:
        return None
    try:
        return normalize_authorization(value)
    except ValueError:
        return None


def _write_windows_user_environment(name: str, value: str) -> None:
    import ctypes

    winreg = vars(import_module("winreg"))
    with winreg["CreateKeyEx"](winreg["HKEY_CURRENT_USER"], "Environment", access=winreg["KEY_SET_VALUE"]) as key:
        winreg["SetValueEx"](key, name, 0, winreg["REG_SZ"], value)

    result = ctypes.c_size_t()
    ctypes_members = vars(ctypes)
    set_last_error = ctypes_members["set_last_error"]
    get_last_error = ctypes_members["get_last_error"]
    user32 = ctypes_members["windll"].user32
    set_last_error(0)
    sent = user32.SendMessageTimeoutW(
        0xFFFF,
        0x001A,
        0,
        "Environment",
        0x0002,
        5000,
        ctypes.byref(result),
    )
    error = get_last_error()
    if not sent and error:
        raise OSError(error, "cannot notify Windows processes about the updated user environment")


def _read_windows_user_environment(name: str) -> str | None:
    winreg = vars(import_module("winreg"))

    try:
        with winreg["OpenKey"](winreg["HKEY_CURRENT_USER"], "Environment") as key:
            value, value_type = winreg["QueryValueEx"](key, name)
    except FileNotFoundError:
        return None
    if value_type not in {winreg["REG_SZ"], winreg["REG_EXPAND_SZ"]} or not isinstance(value, str):
        return None
    return value


__all__ = [
    "AuthorizationResolution",
    "AuthorizationStatus",
    "clear_stored_authorization",
    "configure_codex_desktop_authorization",
    "credential_path",
    "normalize_authorization",
    "read_codex_desktop_authorization",
    "read_stored_authorization",
    "setup_authorization_value",
    "validate_setup_authorization",
    "write_stored_authorization",
]
