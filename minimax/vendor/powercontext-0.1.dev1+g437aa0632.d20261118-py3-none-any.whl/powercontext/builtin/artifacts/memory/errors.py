# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Errors owned by the built-in Memory Artifact Family."""

from powercontext.errors import PowerContextError


class MemoryLayerError(PowerContextError):
    """Base exception for Memory domain and repository failures."""


class MemoryCapacityExceededError(MemoryLayerError, RuntimeError):
    def __init__(self, dimension: str, limit: int, observed: int) -> None:
        self.dimension = dimension
        self.limit = limit
        self.observed = observed
        super().__init__(f"memory capacity budget is exceeded: {dimension} {observed} > {limit}")


class CapabilityNotSupportedError(MemoryLayerError, RuntimeError):
    def __init__(self, capability: str, detail: str | None = None) -> None:
        self.capability = capability
        self.detail = detail
        message = f"memory capability is not supported: {capability}"
        if detail is not None:
            message = f"{message} ({detail})"
        super().__init__(message)


class MemoryEntryError(MemoryLayerError):
    """Base exception for logical Memory entry failures."""


class MemoryEntryNotFoundError(MemoryEntryError, LookupError):
    def __init__(self, entry_id: str) -> None:
        self.entry_id = entry_id
        super().__init__(f"memory entry was not found: {entry_id}")


class MemoryEntryInactiveError(MemoryEntryError, RuntimeError):
    def __init__(self, entry_id: str) -> None:
        self.entry_id = entry_id
        super().__init__(f"memory entry is inactive: {entry_id}")


class InvalidMemoryCandidateError(MemoryLayerError, ValueError):
    def __init__(
        self,
        code: str,
        detail: object | None = None,
        *,
        canonical_code: str | None = None,
    ) -> None:
        self.code = code
        self.detail = detail
        self.canonical_code = canonical_code
        messages = {
            "remember-mode": f"unsupported memory remember mode: {detail}",
            "identity-kind": f"unsupported memory identity kind: {detail}",
            "canonical": f"invalid canonical memory entry: {detail}",
        }
        super().__init__(messages.get(code, f"invalid memory candidate: {code}"))


class InvalidMemoryEvidenceError(MemoryLayerError, ValueError):
    def __init__(self, code: str) -> None:
        self.code = code
        messages = {
            "source-resolver": "Source evidence requires a canonical Source resolver",
            "artifact-resolver": "Artifact evidence requires a canonical Artifact resolver",
            "source-outside": "entry Source evidence is outside the allowed evidence set",
            "artifact-outside": "entry Artifact evidence is outside the allowed evidence set",
            "projection": "Memory evidence projection must be JSON-compatible",
            "source-adapter": "Source evidence requires a Source adapter",
        }
        super().__init__(messages.get(code, f"invalid memory evidence: {code}"))


class InvalidEmbeddingError(MemoryLayerError, ValueError):
    def __init__(self, code: str) -> None:
        self.code = code
        messages = {"count": "embedding model must return one vector per text"}
        super().__init__(messages.get(code, f"invalid embedding: {code}"))


class MemoryWriteRejectedError(MemoryLayerError, RuntimeError):
    """A structured, caller-visible refusal to apply one Memory write.

    ``code`` and ``reason`` carry the gate's decision to the host, so a refused write is
    observable rather than silently dropped.
    """

    def __init__(self, code: str, reason: str | None = None) -> None:
        self.code = code
        self.reason = reason
        detail = "" if reason is None else f": {reason}"
        super().__init__(f"memory write was rejected ({code}){detail}")


class MemoryBackendConfigurationError(MemoryLayerError, RuntimeError):
    """Raised when a repository cannot satisfy its declared configuration."""
