# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Composition and lifecycle for one configured built-in runtime."""

from __future__ import annotations

import json
import logging
import os
import warnings
from collections.abc import AsyncIterator, Callable, Mapping, Sequence
from contextlib import AsyncExitStack, asynccontextmanager, nullcontext, suppress
from datetime import timedelta
from functools import partial
from ipaddress import ip_address
from pathlib import Path
from time import perf_counter
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast
from urllib.parse import urlsplit

from pydantic import AnyHttpUrl, JsonValue, SecretStr
from sqlalchemy import inspect, select
from sqlalchemy.ext.asyncio import AsyncConnection
from typing_extensions import override

from powercontext._logging import log_safely
from powercontext.artifacts.search import ArtifactSearchExecutionContext
from powercontext.builtin.artifacts.atomic_memory.extraction import (
    AtomicMemoryExtractionInput,
    AtomicMemoryExtractionOutput,
    AtomicMemoryGenerationPipeline,
    atomic_memory_extraction_instructions,
    require_atomic_memory_pipeline,
    validate_extraction_output,
)
from powercontext.builtin.artifacts.atomic_memory.reconciliation import (
    ATOMIC_MEMORY_RECONCILIATION_INSTRUCTIONS,
    AtomicMemoryReconciliationInput,
    AtomicMemoryReconciliationOutput,
    validate_reconciliation_decision,
)
from powercontext.builtin.artifacts.experience import ExperienceCandidatePipeline, ExperienceGenerator
from powercontext.builtin.artifacts.experience.merge import ExperienceMergeAdapter
from powercontext.builtin.artifacts.handoff import (
    DefaultHandoffEvidenceProjector,
    HandoffGenerationPipeline,
)
from powercontext.builtin.artifacts.memory import (
    CandidatePipeline,
    DefaultMemoryEvidenceProjector,
    MemoryRerankDecision,
    MemoryReranker,
    MemoryWriteGate,
)
from powercontext.builtin.artifacts.memory.reranking import MemoryRerankText
from powercontext.builtin.artifacts.merge import ArtifactMergeService
from powercontext.builtin.artifacts.merge_restoration import ArtifactMergePreviewSigner
from powercontext.builtin.artifacts.profile.generation import PROFILE_INSTRUCTIONS, LLMProfileGenerator
from powercontext.builtin.artifacts.profile.service import (
    ProfileGenerationInput,
    ProfileGenerationOutput,
    ProfileGenerator,
)
from powercontext.builtin.artifacts.prompt import PromptRegistry
from powercontext.builtin.artifacts.prompt.builtin import builtin_prompt_definitions
from powercontext.builtin.artifacts.prompt.service import DemonstrationGenerator
from powercontext.builtin.artifacts.skill import AgentSkillProvider, ExternalSkillProvider, SkillGenerator
from powercontext.builtin.artifacts.topic_memory import TOPIC_MEMORY_SOURCE_WINDOW_BINDING
from powercontext.builtin.artifacts.topic_memory.generation import (
    TopicMemoryGenerationError,
    topic_memory_stage_budget,
    validate_topic_memory_stage_capacity,
)
from powercontext.builtin.code.configuration import open_code_service
from powercontext.builtin.dream.bindings import DREAM_OPERATIONS, operation_spec
from powercontext.builtin.dream.generation import (
    DREAM_INSTRUCTIONS,
    DreamGenerationInput,
    DreamGenerator,
    LLMDreamGenerator,
)
from powercontext.builtin.dream.models import DreamBudget, DreamPlan
from powercontext.builtin.dream.service import CandidateAttester, DreamAuthorizer
from powercontext.builtin.evidence.models import content_digest
from powercontext.builtin.evidence.resolver import AuthorizationContext
from powercontext.builtin.handoff_report.adapters import RuntimeHandoffReadAdapter
from powercontext.builtin.handoff_report.application import HandoffReportApplication
from powercontext.builtin.inference import EmbeddingModel, TokenEstimator, character_token_estimator
from powercontext.builtin.inference.input_encoding import INPUT_ENCODING_SCHEMA_V2
from powercontext.builtin.inference.observability import (
    ProviderObservationReport,
    ProviderObservationSource,
    ProviderObserver,
    bind_provider_observer,
    current_provider_observer,
    observe_http_client,
    provider_name,
    suppress_provider_observation,
)
from powercontext.builtin.inference.privacy import InferenceProtectionConfig, PrivacyPolicy
from powercontext.builtin.inference.usage import (
    UsageReportingEmbeddingModel,
    UsageReportingStructuredGenerator,
)
from powercontext.builtin.persistence.atomic_memory_index import (
    AtomicMemoryIndexCapabilities,
)
from powercontext.builtin.persistence.atomic_memory_readiness import (
    assert_atomic_memory_migration_ready,
    ensure_supported_atomic_memory_schema,
)
from powercontext.builtin.persistence.bootstrap_receipts import BootstrapReceiptRepository
from powercontext.builtin.persistence.experience_index import ensure_artifact_head_searchable_text
from powercontext.builtin.persistence.lexical_projection import refresh_lexical_projections
from powercontext.builtin.persistence.oceanbase.atomic_memory_index import OceanBaseAtomicMemoryIndex
from powercontext.builtin.persistence.oceanbase.experience_index import OceanBaseExperienceFTSIndex
from powercontext.builtin.persistence.oceanbase.profile import OceanBaseConfig, OceanBaseProfile
from powercontext.builtin.persistence.oceanbase.topic_memory_index import (
    OceanBaseTopicMemoryFTSIndex,
    OceanBaseTopicMemoryVectorIndex,
)
from powercontext.builtin.persistence.processing_migration import (
    assert_processing_schema_ready,
    bootstrap_processing_schema,
)
from powercontext.builtin.persistence.revision_metadata_schema import ensure_artifact_revision_metadata_schema
from powercontext.builtin.persistence.schema import ensure_portable_timestamp_precision
from powercontext.builtin.persistence.scope_search_schema import ensure_scope_search_schema
from powercontext.builtin.persistence.seekdb.profile import SeekDBConfig, SeekDBProfile
from powercontext.builtin.persistence.skill_distribution_schema import ensure_skill_distribution_schema
from powercontext.builtin.persistence.sqlite.atomic_memory_index import SQLiteAtomicMemoryIndex
from powercontext.builtin.persistence.sqlite.experience_index import SQLiteExperienceFTSIndex
from powercontext.builtin.persistence.sqlite.profile import SQLiteConfig, SQLiteProfile
from powercontext.builtin.persistence.sqlite.topic_memory_index import (
    SQLiteTopicMemoryFTSIndex,
    SQLiteTopicMemoryVectorIndex,
)
from powercontext.builtin.persistence.tables import BUILTIN_TABLES, PORTABLE_RESTORE_RECEIPTS_TABLE
from powercontext.builtin.persistence.tag_schema import ensure_topic_memory_tag_schema
from powercontext.builtin.persistence.topic_memory import TopicMemoryRepository
from powercontext.builtin.persistence.topic_memory_budget import record_topic_memory_work_failure
from powercontext.builtin.persistence.topic_memory_index import (
    CompositeTopicMemoryIndex,
    TopicMemoryIndex,
)
from powercontext.builtin.portability import BundleRecoveryRequiredError
from powercontext.builtin.runtime._scope_cache import ScopeCacheObserver
from powercontext.builtin.runtime.application import (
    BuiltinRuntime,
    RecallEffortSink,
)
from powercontext.builtin.runtime.artifact_merge import (
    ArtifactMergeAccess,
    ArtifactMergeApplication,
    merge_artifact_tags,
)
from powercontext.builtin.runtime.artifact_processing import (
    ArtifactProcessingBinding,
    ArtifactProcessingSupervisor,
    ArtifactProcessingSupervisors,
    SpawnArtifactProcessingWorkerLauncher,
)
from powercontext.builtin.runtime.artifact_search import ArtifactSearchService
from powercontext.builtin.runtime.atomic_memory_input import render_atomic_memory_input
from powercontext.builtin.runtime.atomic_memory_processing import AtomicMemoryProcessingConfig
from powercontext.builtin.runtime.atomic_memory_search import AtomicArtifactSearcher
from powercontext.builtin.runtime.config import BuiltinConfig, ExternalSkillsConfig, InferenceConfig, RuntimeConfig
from powercontext.builtin.runtime.decision_model import (
    DECISION_INSTRUCTIONS,
    DecisionInput,
    DecisionModel,
    DecisionOutput,
    DecisionRequest,
    DecisionResult,
    FailOpenDecisionModel,
    LLMDecisionModel,
)
from powercontext.builtin.runtime.decision_policy import DecisionPolicyMode, DecisionPrivacyBoundary
from powercontext.builtin.runtime.decision_projection import (
    DecisionRequestProjectionSanitizer,
    KnownSecretDecisionRequestSanitizer,
)
from powercontext.builtin.runtime.experience_search import ExperienceArtifactSearcher
from powercontext.builtin.runtime.extraction_diagnostics import ExtractionDiagnostics
from powercontext.builtin.runtime.family_processing import FAMILY_BINDINGS, FamilyWorkerSpec, run_family_worker
from powercontext.builtin.runtime.input_preparation import render_input
from powercontext.builtin.runtime.memory_write_gate import build_memory_write_gate
from powercontext.builtin.runtime.models import DreamOperationCapability, MemorySearchMode, RuntimeCapabilities
from powercontext.builtin.runtime.processing_contracts import (
    ArtifactProcessingModelUsageDelta,
    WorkerEntrypoint,
    WorkerInitializerPreparation,
)
from powercontext.builtin.runtime.processing_discovery import SourceProcessingPendingProvider, enabled_profile_scopes
from powercontext.builtin.runtime.processing_registry import (
    canonical_processing_manifest,
    dream_operations,
    processing_capabilities,
)
from powercontext.builtin.runtime.protocols import RuntimeTracing
from powercontext.builtin.runtime.readiness import (
    CachedReadinessProbe,
    ReadinessProbe,
    ReadinessProbeDefinition,
    RuntimeReadinessChecks,
    dependency_readiness_probe,
)
from powercontext.builtin.runtime.recall_sufficiency import RecallSufficiencyPolicy
from powercontext.builtin.runtime.receipt_capture import current_receipt_evidence
from powercontext.builtin.runtime.relational import RelationalContexts
from powercontext.builtin.runtime.topic_memory_processing import (
    TopicMemoryWorkerSpec,
    run_topic_memory_worker,
    validate_topic_memory_provider_settings,
)
from powercontext.builtin.runtime.topic_memory_recovery import TopicMemoryRecoveryService
from powercontext.builtin.runtime.topic_memory_scope import topic_memory_processing_block
from powercontext.builtin.runtime.topic_memory_search import TopicMemorySearcher
from powercontext.builtin.runtime.worker_observability import worker_model_usage_collector
from powercontext.builtin.sources import (
    BUILTIN_SOURCE_REGISTRY,
    TEXT_EVIDENCE_PROJECTION_KEY,
)
from powercontext.builtin.statistics import ModelUsagePurpose
from powercontext.errors import InvalidSourceProjectionError, SourceProjectionNotFoundError
from powercontext.sources import AdapterSourceDefinition, Source, SourceDefinitionRegistry, SourceProjectionKey

if TYPE_CHECKING:
    import httpx2
    from anthropic import AsyncAnthropic
    from pydantic_ai.models import Model
    from pydantic_ai.models.instrumented import InstrumentationSettings
    from pydantic_ai.providers import Provider
    from pydantic_ai.settings import ModelSettings

    from powercontext.builtin.inference.pydantic_ai import InferenceLimits

ValueT = TypeVar("ValueT")
logger = logging.getLogger(__name__)


class BuiltinConfigurationError(RuntimeError):
    """Report a configuration that cannot assemble the built-in runtime."""

    def __init__(self, issue: str) -> None:
        messages = {
            "external-skill-host": "external Skill roots require a host identity",
            "inference-endpoint-provider": (
                "custom inference endpoints require an OpenAI- or Anthropic-compatible model identifier"
            ),
            "inference-profile": "validated inference profile is incomplete",
            "inference-protection-injected-provider": (
                "enforcing inference protection requires owned provider transports; custom inference injection is unsupported"
            ),
            "memory-reranker": "Memory reranking requires a configured generation or rerank model, or injected reranker",
            "scheduled-experience-pipeline": "scheduled Experience incubation requires a candidate pipeline",
            "scheduled-pipeline": "scheduled Source processing requires a candidate pipeline",
            "scheduled-profile-generation": "scheduled Profile processing requires reconstructible generation",
            "topic-memory-child-resources": (
                "Topic Memory processing requires child-reconstructible inference resources"
            ),
            "topic-memory-generation-budget": "Topic Memory generation budget is not executable",
            "topic-memory-provider-budget": "Topic Memory workers require supported providers with transport retries disabled and bounded stateless model settings",
            "topic-memory-generation": "Topic Memory processing requires a configured generation model",
            "topic-memory-database": "Topic Memory workers require file-backed SQLite; an in-memory database cannot be shared with spawned workers",
            "artifact-processing-worker-authorization-provider": (
                "Background processing requires a reconstructible Authorization Provider with transactional ownership and audit"
            ),
            "artifact-processing-child-resources": "Background processing requires child-reconstructible inference resources",
            "artifact-processing-source-registry": (
                "Built-in background workers require the built-in Source definitions; "
                "provide custom processing bindings or disable built-in background families for a custom Source registry"
            ),
            "artifact-processing-families": "Declared background families must have one matching registration and reconstructible models",
            "database": "unsupported built-in database",
            "decision-model": (
                "decision assistance requires a configured generation or decision model, or injected decision model"
            ),
            "decision-projection-sanitizer": (
                "hosted_redacted Memory write-gate egress requires an explicitly selected decision projection sanitizer"
            ),
        }
        super().__init__(messages[issue])


class _DefinitionEvidenceProjector(DefaultMemoryEvidenceProjector):
    def __init__(self, definitions: SourceDefinitionRegistry, projection: SourceProjectionKey) -> None:
        self._definitions = definitions
        self._projection = projection

    @override
    def project_source(self, source: Source, /) -> JsonValue:
        try:
            return self._definitions.project(source, self._projection)
        except (InvalidSourceProjectionError, SourceProjectionNotFoundError):
            return super().project_source(source)


class _DefinitionHandoffEvidenceProjector(DefaultHandoffEvidenceProjector):
    def __init__(self, definitions: SourceDefinitionRegistry, projection: SourceProjectionKey) -> None:
        self._definitions = definitions
        self._projection = projection

    @override
    def project_source(self, source: Source, /) -> JsonValue:
        try:
            return self._definitions.project(source, self._projection)
        except (InvalidSourceProjectionError, SourceProjectionNotFoundError):
            return super().project_source(source)


class _TracingMemoryReranker:
    """Trace one configured reranker without exposing Memory content."""

    def __init__(self, delegate: MemoryReranker, tracing: RuntimeTracing) -> None:
        self._delegate = delegate
        self._tracing = tracing
        self.policy_id = delegate.policy_id
        self.supports_atomic_memory = getattr(delegate, "supports_atomic_memory", False)

    def receipt_configuration(self) -> dict[str, object] | None:
        configuration = getattr(self._delegate, "receipt_configuration", None)
        return configuration() if callable(configuration) else None

    async def rerank(
        self,
        query: str,
        candidates: tuple[MemoryRerankText, ...],
        limit: int,
        /,
    ) -> MemoryRerankDecision:
        evidence = current_receipt_evidence()
        started = perf_counter() if evidence is not None else None
        try:
            with self._tracing.stage(
                "memory.rerank",
                attributes={
                    "powercontext.memory.rerank.candidate_count": len(candidates),
                    "powercontext.memory.rerank.limit": limit,
                },
            ) as span:
                decision = await self._delegate.rerank(query, candidates, limit)
                span.set_attributes({
                    "powercontext.memory.rerank.selected_count": len(decision.selected_ranks),
                    "powercontext.memory.rerank.discarded_rank_count": decision.discarded_rank_count,
                    "powercontext.memory.rerank.used_fallback": decision.used_fallback,
                })
                return decision
        finally:
            if evidence is not None and started is not None:
                evidence.stage("memory.rerank", (perf_counter() - started) * 1000)


class _TracingDecisionModel:
    """Trace one configured decision backend without exposing question or evidence content."""

    def __init__(self, delegate: DecisionModel, tracing: RuntimeTracing) -> None:
        self._delegate = delegate
        self._tracing = tracing
        self.policy_id = delegate.policy_id
        self.is_local_only = bool(getattr(delegate, "is_local_only", False))
        self.provider_id = getattr(delegate, "provider_id", None)
        self.backend_model_id = getattr(delegate, "backend_model_id", None)

    async def evaluate(self, request: DecisionRequest, /) -> DecisionResult:
        with self._tracing.stage(
            "decision.evaluate",
            attributes={"powercontext.decision.kind": request.decision_kind},
        ) as span:
            result = await self._delegate.evaluate(request)
            span.set_attributes({
                "powercontext.decision.outcome": result.outcome.value,
                "powercontext.decision.used_fallback": result.used_fallback,
            })
            return result


def _fail_open_decision_model(
    injected: DecisionModel | None,
    generated: DecisionModel | None,
    tracing: RuntimeTracing | None,
    *,
    timeout_seconds: float | None = None,
) -> DecisionModel | None:
    """Resolve the decision backend, always exposing it fail-open wrapped with tracing outermost."""

    backend = injected if injected is not None else generated
    if backend is None:
        return None
    delegate: DecisionModel = FailOpenDecisionModel(backend, timeout_seconds=timeout_seconds)
    if tracing is not None:
        delegate = _TracingDecisionModel(delegate, tracing)
    return delegate


def _require_decision_backend(runtime: RuntimeConfig, configured: DecisionModel | None) -> None:
    """Reject an enabled decision role that resolved to no backend at all."""

    if runtime.decision_assistance_enabled and configured is None:
        raise BuiltinConfigurationError("decision-model")


def _resolve_memory_write_gate_sanitizer(
    runtime: RuntimeConfig,
    decision_request_sanitizer: DecisionRequestProjectionSanitizer | None,
    decision_model: DecisionModel | None = None,
) -> DecisionRequestProjectionSanitizer | None:
    """Resolve the explicitly selected projection boundary for hosted Memory gate egress."""

    if decision_request_sanitizer is not None:
        if not callable(getattr(decision_request_sanitizer, "sanitize", None)) and not callable(
            decision_request_sanitizer
        ):
            raise BuiltinConfigurationError("decision-projection-sanitizer")
        return decision_request_sanitizer
    if (
        runtime.memory_write_gate_enabled
        and runtime.memory_write_gate_mode is not DecisionPolicyMode.DISABLED
        and runtime.memory_write_gate_privacy_boundary is DecisionPrivacyBoundary.HOSTED_REDACTED
    ):
        if decision_model is not None and bool(getattr(decision_model, "is_local_only", False)):
            return None
        if runtime.memory_write_gate_sanitizer == "known_secrets":
            return KnownSecretDecisionRequestSanitizer()
        raise BuiltinConfigurationError("decision-projection-sanitizer")
    return decision_request_sanitizer


def _resolve_runtime_decision_request_sanitizer(
    runtime: RuntimeConfig,
    decision_request_sanitizer: DecisionRequestProjectionSanitizer | None,
    memory_write_gate: MemoryWriteGate | None,
    decision_model: DecisionModel | None,
) -> DecisionRequestProjectionSanitizer | None:
    """Resolve projection safety only when Runtime owns the gate composition."""

    if memory_write_gate is not None:
        return decision_request_sanitizer
    return _resolve_memory_write_gate_sanitizer(runtime, decision_request_sanitizer, decision_model)


def _configured_memory_write_gate(
    injected: MemoryWriteGate | None,
    decision_model: DecisionModel | None,
    runtime: RuntimeConfig,
    decision_request_sanitizer: DecisionRequestProjectionSanitizer | None = None,
) -> MemoryWriteGate | None:
    """Resolve the Memory write gate: an explicit injection wins, then configuration builds one.

    The gate is auxiliary and fail-open by contract, which is the opposite of the decision role:
    an enabled gate whose decision backend is unavailable logs a warning and passes writes through
    instead of failing startup, so a misconfigured gate can never block Memory writes.
    """

    if injected is not None:
        return injected
    if not runtime.memory_write_gate_enabled:
        return None
    decision_request_sanitizer = _resolve_memory_write_gate_sanitizer(
        runtime,
        decision_request_sanitizer,
        decision_model,
    )
    gate = build_memory_write_gate(
        decision_model,
        enabled=True,
        hold_on=runtime.memory_write_gate_hold_on,
        threshold=runtime.memory_write_gate_threshold,
        mode=runtime.memory_write_gate_mode,
        privacy_boundary=runtime.memory_write_gate_privacy_boundary,
        decision_request_sanitizer=decision_request_sanitizer,
    )
    if gate is None:
        log_safely(
            logger,
            logging.WARNING,
            "Memory write gate is enabled but no decision backend is available; writes pass through",
            extra={"event": "memory.write-gate.unavailable", "decision_kind": "memory.write-gate"},
        )
    return gate


def _artifact_merge_application(contexts: RelationalContexts, config: RuntimeConfig) -> ArtifactMergeApplication:
    signer = (
        None
        if config.atomic_memory_preview_signing_secret is None
        else ArtifactMergePreviewSigner(
            keys={
                config.atomic_memory_preview_signing_key_id: config.atomic_memory_preview_signing_secret.get_secret_value().encode(
                    "utf-8"
                )
            },
            active_key_id=config.atomic_memory_preview_signing_key_id,
            ttl_seconds=config.atomic_memory_preview_ttl_seconds,
        )
    )
    experience = ArtifactMergeService(
        artifacts=contexts.repositories.artifacts,
        adapter=ExperienceMergeAdapter(contexts.experience_index),
        security=ArtifactMergeAccess("experience"),
        merge_tags=partial(merge_artifact_tags, family="experience"),
        preview_signer=signer,
    )
    return ArtifactMergeApplication(
        contexts.database,
        (contexts.atomic_memory.service.shared, experience),
        default_context=ArtifactSearchExecutionContext(trusted_local=True),
        id_factory=contexts.atomic_memory.id_factory,
        restore_retry_budget=config.atomic_memory_restore_retry_budget,
    )


def _validate_protected_inference(protection: InferenceProtectionConfig, *dependencies: object) -> None:
    if protection.mode == "enforcing" and any(dependency is not None for dependency in dependencies):
        raise BuiltinConfigurationError("inference-protection-injected-provider")


@asynccontextmanager
async def open_builtin_runtime(  # noqa: C901
    config: BuiltinConfig,
    *,
    scheduler_path: str | Path | None = None,
    candidate_pipeline: CandidatePipeline | AtomicMemoryGenerationPipeline | None = None,
    experience_pipeline: ExperienceCandidatePipeline | None = None,
    experience_generator: ExperienceGenerator | None = None,
    profile_generator: ProfileGenerator | None = None,
    skill_generator: SkillGenerator | None = None,
    dream_generator: DreamGenerator | None = None,
    dream_authorizer: DreamAuthorizer | None = None,
    dream_authorization_context: AuthorizationContext = nullcontext,
    dream_candidate_attester: CandidateAttester | None = None,
    dream_candidate_authorizer: CandidateAttester | None = None,
    external_skill_provider: ExternalSkillProvider | None = None,
    handoff_pipeline: HandoffGenerationPipeline | None = None,
    embedding_model: EmbeddingModel | None = None,
    token_estimator: TokenEstimator | None = None,
    memory_reranker: MemoryReranker | None = None,
    decision_model: DecisionModel | None = None,
    decision_request_sanitizer: DecisionRequestProjectionSanitizer | None = None,
    memory_write_gate: MemoryWriteGate | None = None,
    instrumentation: InstrumentationSettings | None = None,
    model_usage_observer: Callable[[int, int, int, int], None] | None = None,
    worker_model_usage_observer: Callable[[ArtifactProcessingModelUsageDelta | None], None] | None = None,
    scope_cache_observer: ScopeCacheObserver | None = None,
    provider_observer: ProviderObserver | None = None,
    worker_provider_observer: Callable[[ProviderObservationReport | None], None] | None = None,
    topic_memory_search_observer: Callable[[str, bool], None] | None = None,
    tracing: RuntimeTracing | None = None,
    artifact_processing_bindings: Sequence[ArtifactProcessingBinding] = (),
    worker_security: dict[str, Any] | None = None,
    processing_observer: Callable[[str, str, float], None] | None = None,
    worker_initializer: Callable[[], None] | WorkerInitializerPreparation | None = None,
    worker_entrypoint_wrapper: Callable[[WorkerEntrypoint], WorkerEntrypoint] | None = None,
    scheduled_profile_runner: Any = None,
    source_registry: SourceDefinitionRegistry | None = None,
    cursor_secret: bytes | None = None,
    handoff_verification_keys: tuple[bytes, ...] = (),
    recall_effort_sink: RecallEffortSink | None = None,
    dispatch_processing: bool = True,
    _archive_recovery: bool = False,
) -> AsyncIterator[BuiltinRuntime]:
    """Open the selected database, inference adapters, and built-in runtime.

    Recall efforts use the scoped relational statistics recorder by default.
    An explicit ``recall_effort_sink`` replaces that recorder rather than adding
    a second observation. A disabled gate invokes neither recorder nor sink.

    Set ``dispatch_processing=False`` for offline maintenance. This skips supervisor
    startup without changing deployment configuration, manifest validation, or archive
    recovery behavior.

    ``worker_initializer`` is an optional bootstrap for automatically composed spawn
    workers. A ``WorkerInitializerPreparation`` can own per-launch resources through
    a context manager yielding the picklable child bootstrap. Its resources remain
    open until spawn or cancellation cleanup finishes. Custom bindings own their
    launchers and initialization. The default does not configure process logging.

    ``scheduler_path`` is deprecated and ignored.
    """

    if scheduler_path is not None:
        warnings.warn(
            "scheduler_path is ignored and will be removed; automatic processing is scheduled by the "
            "artifact processing supervisor",
            DeprecationWarning,
            stacklevel=3,
        )

    async with AsyncExitStack() as resources:
        _validate_protected_inference(
            config.inference.protection,
            candidate_pipeline,
            experience_pipeline,
            experience_generator,
            profile_generator,
            skill_generator,
            dream_generator,
            handoff_pipeline,
            embedding_model,
            memory_reranker,
            decision_model,
            memory_write_gate,
        )
        configured_source_registry = source_registry or BUILTIN_SOURCE_REGISTRY
        resources.enter_context(bind_provider_observer(provider_observer or current_provider_observer()))
        resolved_decision_request_sanitizer = decision_request_sanitizer
        _validate_processing_source_registry(config, artifact_processing_bindings, configured_source_registry)
        prompt_demonstrators: dict[str, DemonstrationGenerator] = {}
        (
            generated_profile,
            generated_memory,
            generated_incubation,
            generated_experience,
            generated_skill,
            generated_handoff,
            generated_reranker,
            generated_decision,
            generation_readiness,
            rerank_readiness,
            decision_readiness,
        ) = (
            await _generation_pipelines(
                config.inference,
                config.runtime,
                resources,
                instrumentation,
                configured_source_registry,
                prompt_demonstrators=prompt_demonstrators,
            )
            if (
                profile_generator is None
                or candidate_pipeline is None
                or experience_pipeline is None
                or experience_generator is None
                or skill_generator is None
                or handoff_pipeline is None
                or (config.runtime.memory_rerank_enabled and memory_reranker is None)
                or (
                    (config.runtime.decision_assistance_enabled or config.runtime.memory_write_gate_enabled)
                    and decision_model is None
                )
            )
            else (None, None, None, None, None, None, None, None, None, None, None)
        )
        configured_pipeline = (
            generated_memory if candidate_pipeline is None else require_atomic_memory_pipeline(candidate_pipeline)
        )
        configured_incubation = generated_incubation if experience_pipeline is None else experience_pipeline
        configured_experience = generated_experience if experience_generator is None else experience_generator
        configured_skill = generated_skill if skill_generator is None else skill_generator
        configured_handoff = generated_handoff if handoff_pipeline is None else handoff_pipeline
        configured_reranker = generated_reranker if memory_reranker is None else memory_reranker
        components = (
            ("profile.generate", profile_generator, generated_profile),
            ("atomic_memory.extract", candidate_pipeline, generated_memory),
            ("atomic_memory.reconcile", candidate_pipeline, generated_memory),
            ("memory.rerank", memory_reranker, generated_reranker),
            ("experience.incubate", experience_pipeline, generated_incubation),
            ("experience.generate", experience_generator, generated_experience),
            ("skill.generate", skill_generator, generated_skill),
            ("handoff.generate", handoff_pipeline, generated_handoff),
            *(
                (f"topic_memory.{stage}", None, object())
                for stage in ("probe", "global", "planner", "evolve", "temporary", "reduce", "reconcile")
                if config.inference.generation_model is not None
            ),
        )
        prompt_registry = _prompt_registry(config.runtime, components)
        if configured_reranker is not None and tracing is not None:
            configured_reranker = _TracingMemoryReranker(configured_reranker, tracing)
        # The decision role is always exposed fail-open wrapped; tracing, when enabled, is outermost
        # so its span records the final verdict including any degradation.
        configured_decision = _fail_open_decision_model(
            decision_model,
            generated_decision,
            tracing,
            timeout_seconds=config.inference.decision_timeout_seconds or config.inference.generation_timeout_seconds,
        )
        resolved_decision_request_sanitizer = _resolve_runtime_decision_request_sanitizer(
            config.runtime,
            decision_request_sanitizer,
            memory_write_gate,
            configured_decision,
        )
        configured_gate = _configured_memory_write_gate(
            memory_write_gate,
            configured_decision,
            config.runtime,
            resolved_decision_request_sanitizer,
        )
        if embedding_model is None:
            configured_embedding_source, readiness_embedding = await _embedding_models(
                config.inference,
                resources,
                instrumentation,
            )
        else:
            from powercontext.builtin.inference.pydantic_ai import PydanticAIEmbeddingModel

            configured_embedding_source = embedding_model
            readiness_embedding = (
                embedding_model._without_instrumentation()
                if isinstance(embedding_model, PydanticAIEmbeddingModel)
                else embedding_model
            )
        configured_embedding = _usage_reporting_embedding_model(configured_embedding_source)
        configured_external_skills = (
            _external_skill_provider(config.external_skills)
            if external_skill_provider is None
            else external_skill_provider
        )
        contexts = await resources.enter_async_context(
            open_builtin_contexts(
                config,
                _archive_recovery=_archive_recovery,
                model_usage_observer=model_usage_observer,
                candidate_pipeline=configured_pipeline,
                experience_pipeline=configured_incubation,
                experience_generator=configured_experience,
                skill_generator=configured_skill,
                external_skill_provider=configured_external_skills,
                handoff_pipeline=configured_handoff,
                embedding_model=configured_embedding,
                token_estimator=token_estimator,
                memory_reranker=configured_reranker,
                decision_model=configured_decision,
                memory_write_gate=configured_gate,
                source_registry=configured_source_registry,
                cursor_secret=cursor_secret,
                tracing=tracing,
                prompt_registry=prompt_registry,
                prompt_demonstrators=prompt_demonstrators,
                handoff_verification_keys=handoff_verification_keys,
            )
        )
        contexts.profiles.generator = generated_profile if profile_generator is None else profile_generator
        contexts.profiles.max_sources = config.runtime.profile_max_sources_per_window
        if scheduled_profile_runner is not None:

            async def run_profile(scope_id, high):
                return await scheduled_profile_runner(scope_id, high, contexts.profiles)

            contexts.profiles.scheduled_runner = run_profile
        readiness_probes: dict[str, ReadinessProbeDefinition] = {
            "database": ReadinessProbeDefinition(
                probe=dependency_readiness_probe(contexts.database.ping),
                blocking=True,
            ),
        }
        inference_readiness = (
            ("inference.generation", generation_readiness),
            ("inference.rerank", rerank_readiness),
            ("inference.decision", decision_readiness),
            (
                "inference.embedding",
                None if readiness_embedding is None else _embedding_readiness_probe(readiness_embedding),
            ),
        )
        for name, readiness_probe in inference_readiness:
            if readiness_probe is not None:
                readiness_probes[name] = ReadinessProbeDefinition(probe=readiness_probe, blocking=False)
        processing_bindings = _artifact_processing_bindings(
            config,
            contexts,
            artifact_processing_bindings,
            injected_embedding_model=embedding_model,
            injected_token_estimator=token_estimator,
            injected_pipelines={
                "memory": candidate_pipeline,
                "experience": experience_pipeline if experience_pipeline is not None else dream_generator,
                "profile": profile_generator,
                "skill": dream_generator,
            },
            injected_memory_write_gate=memory_write_gate,
            worker_security=worker_security,
            worker_initializer=worker_initializer,
            worker_entrypoint_wrapper=worker_entrypoint_wrapper,
            worker_model_usage_observer=worker_model_usage_observer,
            source_registry=configured_source_registry,
            worker_provider_observer=worker_provider_observer,
        )
        log_safely(
            logger,
            logging.INFO,
            "Artifact processing configuration",
            extra={
                "event": "artifact_processing.configured",
                "mode": config.runtime.artifact_processing_supervisor_mode,
                "role": config.runtime.artifact_processing_role,
                "compatibility_aliases": config.runtime._processing_aliases_used,
                "families": [
                    {
                        "binding": b.binding_name,
                        "family": b.artifact_family,
                        "workers": b.max_workers,
                        "timeout_seconds": b.worker_timeout_seconds,
                        "interval_seconds": None
                        if b.automatic_processing_interval is None
                        else b.automatic_processing_interval.total_seconds(),
                        "cron": b.cron,
                        "timezone": b.timezone,
                    }
                    for b in processing_bindings
                ],
            },
        )
        configured_operations = dream_operations(config)
        if dream_generator is not None and config.runtime.dream_enabled:
            registered_families = {binding.artifact_family for binding in processing_bindings}
            configured_operations = tuple(
                spec.operation
                for spec in DREAM_OPERATIONS
                if spec.processing_family in registered_families or (spec.family is None and registered_families)
            )
        topic_memory_processing_available = _topic_memory_processing_available(config, processing_bindings)
        artifact_search, topic_memory_searcher = compose_artifact_search(
            contexts, configured_embedding, observer=topic_memory_search_observer
        )
        runtime = await resources.enter_async_context(
            BuiltinRuntime(
                inference_protection=config.inference.protection,
                code_service=await resources.enter_async_context(open_code_service(config.code, config.database)),
                provider=contexts,
                primary_database=contexts.database,
                owner_write_transactions=True,
                handoff_committer=contexts.commit_handoff,
                capabilities=RuntimeCapabilities(
                    memory_extraction=contexts.memory_extraction,
                    experience_generation=contexts.experience_generation,
                    managed_skill_generation=contexts.managed_skill_generation,
                    artifact_dreaming=bool(configured_operations),
                    artifact_dreaming_operations=tuple(
                        DreamOperationCapability(
                            operation=operation,
                            effect=operation_spec(operation).effect,
                            output_kind=operation_spec(operation).output_kind,
                        )
                        for operation in configured_operations
                    ),
                    external_skill_registry=contexts.external_skill_registry,
                    memory_search_modes=_search_modes(contexts.atomic_memory_index.capabilities),
                    handoff_generation=contexts.handoff_generation,
                    prompts=dict(contexts.prompt_registry.capabilities),
                ),
                source_window_limit=config.runtime.source_window_limit,
                extraction_diagnostics=ExtractionDiagnostics(
                    pipeline_configured=(
                        contexts.memory_extraction
                        or (
                            config.runtime.artifact_processing_role != "api"
                            and any(binding.artifact_family == "memory" for binding in processing_bindings)
                        )
                    ),
                    external_worker=(
                        config.runtime.artifact_processing_role == "api" and "memory" in processing_capabilities(config)
                    ),
                ),
                context_assembly_max_entries=config.runtime.context_assembly_max_entries,
                recall_sufficiency_policy=RecallSufficiencyPolicy.from_runtime_config(
                    config.runtime.model_copy(update={"memory_rerank_enabled": configured_reranker is not None})
                ),
                recall_embedding_timeout_seconds=config.runtime.recall_embedding_timeout_seconds,
                scope_cache_size=config.runtime.scope_cache_size,
                scope_evictor=contexts.evict,
                scope_cache_observer=scope_cache_observer,
                review_service=contexts.review,
                catalog_change_service=contexts.catalog_changes,
                profiles=contexts.profiles,
                subject_sources=contexts.subject_sources,
                generation_service=contexts.generation,
                dream_service=contexts.dream(
                    dream_generator,
                    operations=configured_operations,
                    budget=config.runtime.dream_budget,
                    max_pending_per_scope=config.runtime.dream_max_pending_per_scope,
                    authorize=dream_authorizer,
                    authorization_context=dream_authorization_context,
                    attest_candidate=dream_candidate_attester,
                    authorize_candidate=dream_candidate_authorizer,
                ),
                generation_concurrency=config.runtime.generation_concurrency,
                experience_recall=contexts.search_experience_outcome,
                artifact_search=artifact_search,
                skill_recall=contexts.search_skills,
                skill_lister=contexts.list_skills,
                skill_origin_reader=contexts.get_skill_origins,
                skill_governance_reader=contexts.get_skill_governance,
                skill_governance_updater=contexts.update_skill_lifecycle,
                skill_package_resolver=contexts.skill_package,
                package_snapshot_resolver=contexts.package_snapshot,
                skill_package_uploader=contexts.upload_skill_package,
                skill_usage_recorder=contexts.record_skill_usage,
                experience_incubator=contexts.incubate_experience if contexts.experience_incubation else None,
                topic_memory_search=contexts.search_topic_memories,
                topic_memory_searcher=topic_memory_searcher,
                topic_memory_get=contexts.get_topic_memory,
                topic_memory_browse=contexts.browse_topic_memories,
                topic_memory_flush=contexts.request_topic_memory_flush,
                topic_memory_recovery=TopicMemoryRecoveryService(contexts.database),
                topic_memory_embedding_model=configured_embedding,
                topic_memory_processing_available=topic_memory_processing_available,
                topic_memory_search_observer=topic_memory_search_observer,
                external_skill_registry=contexts.external_skills if contexts.external_skill_registry else None,
                external_skill_importer=contexts.import_external_skill if contexts.external_skill_registry else None,
                skill_publication_service=contexts.skill_publications,
                remote_skill_distribution=contexts.remote_skill_distribution(),
                statistics_service=contexts.statistics,
                record_service=contexts.records,
                bootstrap_receipts=BootstrapReceiptRepository(contexts.database),
                atomic_memory_application=contexts.atomic_memory,
                artifact_merge_application=_artifact_merge_application(contexts, config.runtime),
                prompt_service=contexts.prompts,
                recall_token_estimator=contexts.estimate_recall_tokens,
                recall_effort_sink=recall_effort_sink,
                decision_model=configured_decision,
                publication_application=contexts.publications,
                scope_application=contexts.scopes,
                readiness=RuntimeReadinessChecks(
                    readiness_probes,
                    disabled_dependencies=(name for name, probe in inference_readiness if probe is None),
                ),
                tracing=tracing,
                remote_ingestion=contexts,
                archive_service=contexts.portability,
            )
        )
        runtime.artifact_processing_supervisor = await resources.enter_async_context(
            _open_artifact_processing_supervisor(
                config,
                contexts,
                processing_bindings,
                tracing=tracing,
                dispatch_processing=dispatch_processing,
                recovery=_archive_recovery,
                processing_observer=processing_observer,
            )
        )
        contexts.profiles.operation_context = runtime._operation
        if config.handoff_report.enabled:
            runtime.handoff_report = HandoffReportApplication(
                contexts.scopes,
                RuntimeHandoffReadAdapter(
                    contexts.database,
                    contexts.repositories.artifacts,
                    contexts.handoff_artifact_id,
                ),
            )
        if config.runtime.memory_rerank_enabled and configured_reranker is None:
            raise BuiltinConfigurationError("memory-reranker")
        _require_decision_backend(config.runtime, configured_decision)
        yield runtime


def _validate_processing_source_registry(
    config: BuiltinConfig,
    bindings: Sequence[ArtifactProcessingBinding],
    source_registry: SourceDefinitionRegistry,
) -> None:
    """Reject unsupported child Sources before database bootstrap commits deployment identity."""

    if config.runtime.artifact_processing_role == "api":
        return
    registered = {binding.artifact_family for binding in bindings}
    if all(family in registered for family in processing_capabilities(config)):
        return
    definitions = source_registry.definitions
    builtin_definitions = BUILTIN_SOURCE_REGISTRY.definitions
    if (
        type(source_registry) is not SourceDefinitionRegistry
        or len(definitions) != len(builtin_definitions)
        or any(
            # A host may replace only the evidence declaration while keeping the
            # builtin adapter, version and projections. `memory_evidence` is
            # deliberately excluded: it is the dimension this registration adds.
            not (
                definition is expected
                or (
                    type(definition) is AdapterSourceDefinition
                    and type(expected) is AdapterSourceDefinition
                    and definition.adapter is expected.adapter
                    and definition.version == expected.version
                    and definition.projections is expected.projections
                )
            )
            for definition, expected in zip(definitions, builtin_definitions, strict=True)
        )
    ):
        raise BuiltinConfigurationError("artifact-processing-source-registry")


def _artifact_processing_bindings(  # noqa: C901 - validate and assemble one registration per Family
    config: BuiltinConfig,
    contexts: RelationalContexts,
    bindings: Sequence[ArtifactProcessingBinding],
    *,
    injected_embedding_model: EmbeddingModel | None = None,
    injected_token_estimator: TokenEstimator | None = None,
    injected_pipelines: Mapping[str, object | None] | None = None,
    injected_memory_write_gate: MemoryWriteGate | None = None,
    worker_security: dict[str, Any] | None = None,
    worker_initializer: Callable[[], None] | WorkerInitializerPreparation | None = None,
    worker_entrypoint_wrapper: Callable[[WorkerEntrypoint], WorkerEntrypoint] | None = None,
    worker_model_usage_observer: Callable[[ArtifactProcessingModelUsageDelta | None], None] | None = None,
    source_registry: SourceDefinitionRegistry = BUILTIN_SOURCE_REGISTRY,
    worker_provider_observer: Callable[[ProviderObservationReport | None], None] | None = None,
) -> tuple[ArtifactProcessingBinding, ...]:
    configured = list(bindings)
    _validate_processing_registrations(configured)
    capabilities = processing_capabilities(config)
    canonical = {**FAMILY_BINDINGS, "topic-memory": TOPIC_MEMORY_SOURCE_WINDOW_BINDING}
    registered = {binding.artifact_family for binding in configured}
    declared = set(capabilities)
    if declared - (set(canonical) | registered):
        raise BuiltinConfigurationError("artifact-processing-families")
    automatic = {
        "memory": config.runtime.memory_schedule_seconds,
        "topic-memory": config.runtime.topic_memory_schedule_seconds,
        "experience": config.runtime.experience_schedule_seconds,
        "profile": config.runtime.profile_schedule_enabled or None,
        "skill": None,
        "handoff": None,
        "prompt": None,
    }
    for family, schedule in automatic.items():
        if schedule is not None and family not in declared | registered:
            if (
                family == "topic-memory"
                and config.runtime.artifact_processing_families is None
                and config.inference.generation_model is not None
            ):
                validate_topic_memory_provider_settings(config.inference)
            issue = {
                "memory": "scheduled-pipeline",
                "experience": "scheduled-experience-pipeline",
                "topic-memory": "topic-memory-generation",
                "profile": "scheduled-profile-generation",
            }[family]
            raise BuiltinConfigurationError(issue)
    if config.runtime.artifact_processing_role == "api":
        return tuple(configured)
    _validate_processing_source_registry(config, configured, source_registry)
    injected_pipelines = injected_pipelines or {}
    for family in capabilities:
        if family in registered:
            continue
        if config.inference.generation_model is None:
            raise BuiltinConfigurationError("artifact-processing-families")
        if (
            injected_embedding_model is not None
            or injected_token_estimator is not None
            or injected_pipelines.get(family) is not None
            or (family == "memory" and injected_memory_write_gate is not None)
        ):
            raise BuiltinConfigurationError("artifact-processing-child-resources")
        if isinstance(config.database, SQLiteConfig) and not config.database.is_persistent:
            raise BuiltinConfigurationError("topic-memory-database")
        prefix = family.replace("-", "_")
        if family == "topic-memory":
            validate_topic_memory_provider_settings(config.inference)
            try:
                budget = topic_memory_stage_budget(
                    context_window_tokens=config.inference.generation_model_context_window_tokens,
                    max_requests=config.inference.generation_max_requests,
                    model_settings=config.inference.generation_model_settings,
                )
                validate_topic_memory_stage_capacity(budget, contexts.token_estimator)
            except TopicMemoryGenerationError as error:
                raise BuiltinConfigurationError("topic-memory-generation-budget") from error
            entrypoint = partial(
                run_topic_memory_worker, TopicMemoryWorkerSpec(config=config, worker_security=worker_security)
            )
        else:
            entrypoint = partial(run_family_worker, FamilyWorkerSpec(config=config, worker_security=worker_security))
        interval = None if family == "profile" else automatic[family]
        binding = canonical[family]
        configured.append(
            ArtifactProcessingBinding(
                binding_name=binding,
                artifact_family=family,
                launcher=SpawnArtifactProcessingWorkerLauncher(
                    entrypoint,
                    initializer=worker_initializer,
                    entrypoint_wrapper=worker_entrypoint_wrapper,
                    collect_model_usage=worker_model_usage_observer is not None,
                    collect_provider_observations=worker_provider_observer is not None,
                ),
                max_workers=getattr(config.runtime, f"{prefix}_max_workers"),
                worker_timeout_seconds=getattr(config.runtime, f"{prefix}_worker_timeout_seconds"),
                automatic_processing_interval=None if interval is None else timedelta(seconds=float(interval)),
                cron=config.runtime.profile_cron
                if family == "profile" and config.runtime.profile_schedule_enabled
                else None,
                timezone=config.runtime.profile_timezone if family == "profile" else "Asia/Shanghai",
                pending_provider=None
                if family in {"skill", "handoff", "prompt"}
                else SourceProcessingPendingProvider(contexts.database, binding, family),
                automatic_scope_filter=enabled_profile_scopes if family == "profile" else None,
                work_block=partial(topic_memory_processing_block, dream_enabled=config.runtime.dream_enabled)
                if family == "topic-memory"
                else None,
                worker_model_usage_observer=worker_model_usage_observer,
                work_failure=record_topic_memory_work_failure if family == "topic-memory" else None,
                worker_provider_observer=worker_provider_observer,
            )
        )
    _validate_processing_registrations(configured)
    return tuple(configured)


def _validate_processing_registrations(configured: Sequence[ArtifactProcessingBinding]) -> None:
    for attribute in ("binding_name", "artifact_family", "config_prefix"):
        identifiers = [getattr(binding, attribute) for binding in configured]
        if len(identifiers) != len(set(identifiers)):
            raise BuiltinConfigurationError("artifact-processing-families")


def _topic_memory_processing_available(
    config: BuiltinConfig,
    bindings: Sequence[ArtifactProcessingBinding],
) -> bool:
    """Report declared cross-role processing ability without probing worker liveness."""

    return any(binding.binding_name == TOPIC_MEMORY_SOURCE_WINDOW_BINDING for binding in bindings) or (
        config.runtime.artifact_processing_role == "api" and "topic-memory" in processing_capabilities(config)
    )


def _topic_memory_provider_available(config: BuiltinConfig) -> bool:
    try:
        validate_topic_memory_provider_settings(config.inference)
    except BuiltinConfigurationError:
        return False
    return True


@asynccontextmanager
async def _open_artifact_processing_supervisor(
    config: BuiltinConfig,
    contexts: RelationalContexts,
    bindings: Sequence[ArtifactProcessingBinding],
    *,
    tracing: RuntimeTracing | None = None,
    dispatch_processing: bool = True,
    recovery: bool = False,
    processing_observer: Callable[[str, str, float], None] | None = None,
) -> AsyncIterator[ArtifactProcessingSupervisors | None]:
    if not dispatch_processing or recovery or config.runtime.artifact_processing_role == "api" or not bindings:
        yield None
        return
    groups = (
        [("global", tuple(bindings))]
        if config.runtime.artifact_processing_supervisor_mode == "global"
        else [(f"artifact:{binding.artifact_family}", (binding,)) for binding in bindings]
    )
    async with AsyncExitStack() as resources:
        supervisors = []
        for name, group in groups:
            supervisor = await resources.enter_async_context(
                ArtifactProcessingSupervisor(
                    database=contexts.database,
                    bindings=group,
                    supervisor_group=name,
                    lease_mode="oceanbase" if isinstance(config.database, OceanBaseConfig) else "single-process",
                    leases=contexts.repositories.processing_leases,
                    binding_states=contexts.repositories.processing_binding_states,
                    tracing=tracing,
                    processing_observer=processing_observer,
                )
            )
            supervisors.append(supervisor)
        yield ArtifactProcessingSupervisors(tuple(supervisors))


def compose_artifact_search(contexts, embedding_model=None, *, observer=None):
    """Use the same Family-owned Searchers in Server, SDK and generation Workers."""
    # Plugin families are searched by their plugins through the Server, not here.
    artifact_search = ArtifactSearchService(known_families=contexts.repositories.artifacts.families)
    artifact_search.register(
        ExperienceArtifactSearcher(contexts.database, contexts.repositories.artifacts, contexts.experience_index)
    )
    artifact_search.register(contexts.list_skills)
    topic_memory_searcher = TopicMemorySearcher(
        search=contexts.search_topic_memories,
        embedding_model=embedding_model,
        observer=observer,
        capabilities=contexts.topic_memory_index.capabilities,
    )
    artifact_search.register(topic_memory_searcher, embedding_purpose=ModelUsagePurpose.TOPIC_MEMORY_RECALL)
    artifact_search.register(
        AtomicArtifactSearcher(application=contexts.atomic_memory),
        embedding_purpose=ModelUsagePurpose.MEMORY_RECALL,
    )
    return artifact_search, topic_memory_searcher


@asynccontextmanager
async def open_builtin_contexts(  # noqa: C901 -- Backend admission and resource lifetimes stay together.
    config: BuiltinConfig,
    *,
    candidate_pipeline: CandidatePipeline | AtomicMemoryGenerationPipeline | None = None,
    experience_pipeline: ExperienceCandidatePipeline | None = None,
    experience_generator: ExperienceGenerator | None = None,
    skill_generator: SkillGenerator | None = None,
    external_skill_provider: ExternalSkillProvider | None = None,
    handoff_pipeline: HandoffGenerationPipeline | None = None,
    embedding_model: EmbeddingModel | None = None,
    token_estimator: TokenEstimator | None = None,
    memory_reranker: MemoryReranker | None = None,
    decision_model: DecisionModel | None = None,
    memory_write_gate: MemoryWriteGate | None = None,
    source_registry: SourceDefinitionRegistry | None = None,
    cursor_secret: bytes | None = None,
    tracing: RuntimeTracing | None = None,
    prompt_registry: PromptRegistry | None = None,
    prompt_demonstrators: dict[str, DemonstrationGenerator] | None = None,
    handoff_verification_keys: tuple[bytes, ...] = (),
    model_usage_observer: Callable[[int, int, int, int], None] | None = None,
    _topic_memory_worker: bool = False,
    _archive_recovery: bool = False,
) -> AsyncIterator[RelationalContexts]:
    """Open the selected database and expose scope-bound PowerContext providers."""

    if model_usage_observer is None:
        collector = worker_model_usage_collector.get()
        if collector is not None:
            model_usage_observer = collector.observer()
    database = config.database
    configured_token_estimator = character_token_estimator() if token_estimator is None else token_estimator
    if isinstance(database, SQLiteConfig):
        experience_index = SQLiteExperienceFTSIndex()
        topic_indexes: list[TopicMemoryIndex] = [SQLiteTopicMemoryFTSIndex()]
        if embedding_model is not None:
            topic_indexes.append(SQLiteTopicMemoryVectorIndex(embedding_model.profile))
        topic_index = CompositeTopicMemoryIndex(*topic_indexes)
        atomic_index = SQLiteAtomicMemoryIndex(None if embedding_model is None else embedding_model.profile)
        async with SQLiteProfile.open(
            database,
            tables=BUILTIN_TABLES + topic_index.tables + atomic_index.tables,
            load_vector_extension=embedding_model is not None,
            _archive_recovery=_archive_recovery,
        ) as profile:
            async with profile.database.transaction() as connection:
                managed = await connection.run_sync(lambda sync: inspect(sync).has_table("pc_schema_revision"))
                if managed:
                    # Managed startup only validates; keep one read snapshot
                    # without reserving SQLite's writer slot.
                    await connection.exec_driver_sql("BEGIN")
                else:
                    # Unmanaged bootstrap may write. Recheck after taking the
                    # writer slot in case a concurrent initializer registered it.
                    await connection.exec_driver_sql("BEGIN IMMEDIATE")
                    managed = await connection.run_sync(lambda sync: inspect(sync).has_table("pc_schema_revision"))
                if managed:
                    await assert_processing_schema_ready(connection, canonical_processing_manifest(config))
                    await atomic_index.validate_current(connection)
                    await _initialize_archive_aware_topics(
                        connection,
                        topic_index,
                        worker=_topic_memory_worker,
                        recovery=_archive_recovery,
                        validate_only=True,
                    )
                else:
                    await bootstrap_processing_schema(connection, canonical_processing_manifest(config))
                    await assert_processing_schema_ready(connection, canonical_processing_manifest(config))
                    await ensure_skill_distribution_schema(connection)
                    await ensure_topic_memory_tag_schema(connection)
                    await ensure_scope_search_schema(connection)
                    await ensure_artifact_revision_metadata_schema(connection)
                    await ensure_portable_timestamp_precision(connection, BUILTIN_TABLES)
                    # A Topic child reuses its parent's schema. It never reads or
                    # writes Memory/Experience projections; rebuilding their FTS
                    # indexes here would take the shared SQLite write lock once
                    # per Window. Normal runtime startup retains index recovery.
                    if not _topic_memory_worker:
                        await _initialize_atomic_memory_authority(connection)
                        await atomic_index.initialize(connection)
                        await atomic_index.validate_current(connection)
                        await refresh_lexical_projections(
                            connection, atomic_index.table if atomic_index.table in atomic_index.tables else None
                        )
                        await ensure_artifact_head_searchable_text(connection)
                        await assert_atomic_memory_migration_ready(connection)
                        await experience_index.initialize(connection)
                    await _initialize_archive_aware_topics(
                        connection, topic_index, worker=_topic_memory_worker, recovery=_archive_recovery
                    )
            contexts = RelationalContexts(
                model_usage_observer=model_usage_observer,
                database=profile.database,
                topic_memory_index=topic_index,
                atomic_memory_index=atomic_index,
                atomic_memory_preview_signing_secret=None
                if config.runtime.atomic_memory_preview_signing_secret is None
                else config.runtime.atomic_memory_preview_signing_secret.get_secret_value().encode("utf-8"),
                atomic_memory_preview_signing_key_id=config.runtime.atomic_memory_preview_signing_key_id,
                atomic_memory_preview_ttl_seconds=config.runtime.atomic_memory_preview_ttl_seconds,
                atomic_memory_restore_retry_budget=config.runtime.atomic_memory_restore_retry_budget,
                atomic_memory_processing_config=AtomicMemoryProcessingConfig.from_runtime(config.runtime),
                experience_index=experience_index,
                candidate_pipeline=candidate_pipeline,
                experience_pipeline=experience_pipeline,
                experience_generator=experience_generator,
                skill_generator=skill_generator,
                external_skill_provider=external_skill_provider,
                handoff_pipeline=handoff_pipeline,
                embedding_model=embedding_model,
                token_estimator=configured_token_estimator,
                memory_reranker=memory_reranker,
                decision_model=decision_model,
                memory_write_gate=memory_write_gate,
                decision_observation_retention_days=config.runtime.decision_observation_retention_days,
                memory_rerank_candidate_limit=config.runtime.memory_rerank_candidate_limit,
                recall_channel_weights=config.runtime.recall_channel_weights,
                prompt_registry=prompt_registry,
                prompt_demonstrators=prompt_demonstrators,
                handoff_verification_keys=handoff_verification_keys,
                topic_memory_write_timeout_seconds=config.inference.embedding_timeout_seconds,
                topic_memory_write_concurrency=config.runtime.generation_concurrency,
                model_usage_queue_capacity=config.runtime.model_usage_queue_capacity,
                model_usage_write_timeout_seconds=config.runtime.model_usage_write_timeout_seconds,
                model_usage_flush_timeout_seconds=config.runtime.model_usage_flush_timeout_seconds,
                source_registry=source_registry,
                cursor_secret=cursor_secret,
                tracing=tracing,
            )
            async with _contexts_lifecycle(contexts, recovery=_archive_recovery):
                yield contexts
        return
    experience_index = OceanBaseExperienceFTSIndex()
    topic_indexes: list[TopicMemoryIndex] = [OceanBaseTopicMemoryFTSIndex()]
    if embedding_model is not None:
        topic_indexes.append(OceanBaseTopicMemoryVectorIndex(embedding_model.profile))
    topic_index = CompositeTopicMemoryIndex(*topic_indexes)
    atomic_index = OceanBaseAtomicMemoryIndex(None if embedding_model is None else embedding_model.profile)
    tables = BUILTIN_TABLES + topic_index.tables + atomic_index.tables
    if isinstance(database, OceanBaseConfig):
        profile_context = OceanBaseProfile.open(database, tables=tables, _archive_recovery=_archive_recovery)
    elif isinstance(database, SeekDBConfig):
        profile_context = SeekDBProfile.open(database, tables=tables, _archive_recovery=_archive_recovery)
    else:
        raise BuiltinConfigurationError("database")
    async with profile_context as profile:
        async with profile.database.transaction() as connection:
            await ensure_supported_atomic_memory_schema(connection)
            managed = await connection.run_sync(lambda sync: inspect(sync).has_table("pc_schema_revision"))
            if managed:
                await assert_processing_schema_ready(connection, canonical_processing_manifest(config))
                await atomic_index.validate_current(connection)
                await _initialize_archive_aware_topics(
                    connection, topic_index, worker=_topic_memory_worker, recovery=_archive_recovery, validate_only=True
                )
            else:
                await bootstrap_processing_schema(connection, canonical_processing_manifest(config))
                await assert_processing_schema_ready(connection, canonical_processing_manifest(config))
                await ensure_skill_distribution_schema(connection)
                await ensure_topic_memory_tag_schema(connection)
                await ensure_scope_search_schema(connection)
                await ensure_artifact_revision_metadata_schema(connection)
                await ensure_portable_timestamp_precision(connection, BUILTIN_TABLES)
                if not _topic_memory_worker:
                    await _initialize_atomic_memory_authority(connection)
                    await atomic_index.initialize(connection)
                    await atomic_index.validate_current(connection)
                    await refresh_lexical_projections(
                        connection, atomic_index.table if atomic_index.table in atomic_index.tables else None
                    )
                    await ensure_artifact_head_searchable_text(connection)
                    await assert_atomic_memory_migration_ready(connection)
                    await experience_index.initialize(connection)
                await _initialize_archive_aware_topics(
                    connection, topic_index, worker=_topic_memory_worker, recovery=_archive_recovery
                )
        contexts = RelationalContexts(
            model_usage_observer=model_usage_observer,
            database=profile.database,
            topic_memory_index=topic_index,
            atomic_memory_index=atomic_index,
            atomic_memory_preview_signing_secret=None
            if config.runtime.atomic_memory_preview_signing_secret is None
            else config.runtime.atomic_memory_preview_signing_secret.get_secret_value().encode("utf-8"),
            atomic_memory_preview_signing_key_id=config.runtime.atomic_memory_preview_signing_key_id,
            atomic_memory_preview_ttl_seconds=config.runtime.atomic_memory_preview_ttl_seconds,
            atomic_memory_restore_retry_budget=config.runtime.atomic_memory_restore_retry_budget,
            atomic_memory_processing_config=AtomicMemoryProcessingConfig.from_runtime(config.runtime),
            experience_index=experience_index,
            candidate_pipeline=candidate_pipeline,
            experience_pipeline=experience_pipeline,
            experience_generator=experience_generator,
            skill_generator=skill_generator,
            external_skill_provider=external_skill_provider,
            handoff_pipeline=handoff_pipeline,
            embedding_model=embedding_model,
            token_estimator=configured_token_estimator,
            memory_reranker=memory_reranker,
            decision_model=decision_model,
            memory_rerank_candidate_limit=config.runtime.memory_rerank_candidate_limit,
            recall_channel_weights=config.runtime.recall_channel_weights,
            prompt_registry=prompt_registry,
            prompt_demonstrators=prompt_demonstrators,
            handoff_verification_keys=handoff_verification_keys,
            topic_memory_write_timeout_seconds=config.inference.embedding_timeout_seconds,
            topic_memory_write_concurrency=config.runtime.generation_concurrency,
            model_usage_queue_capacity=config.runtime.model_usage_queue_capacity,
            model_usage_write_timeout_seconds=config.runtime.model_usage_write_timeout_seconds,
            model_usage_flush_timeout_seconds=config.runtime.model_usage_flush_timeout_seconds,
            source_registry=source_registry,
            cursor_secret=cursor_secret,
            tracing=tracing,
        )
        async with _contexts_lifecycle(contexts, recovery=_archive_recovery):
            yield contexts


@asynccontextmanager
async def _contexts_lifecycle(contexts: RelationalContexts, /, *, recovery: bool) -> AsyncIterator[None]:
    """Expose initialized Contexts and settle their usage before the owning database closes."""

    try:
        if not recovery:
            await contexts.scopes.bootstrap_default()
        yield
    finally:
        await contexts.aclose_usage_recorder()


async def _initialize_archive_aware_topics(
    connection: AsyncConnection, index: TopicMemoryIndex, *, worker: bool, recovery: bool, validate_only: bool = False
) -> None:
    pending = await connection.scalar(
        select(PORTABLE_RESTORE_RECEIPTS_TABLE.c.bundle_id)
        .where(PORTABLE_RESTORE_RECEIPTS_TABLE.c.projections_ready.is_(False))
        .limit(1)
    )
    if pending and (not recovery or worker):
        raise BundleRecoveryRequiredError()
    if pending:
        if validate_only:
            from powercontext.builtin.persistence.migrations.models import MigrationError
            from powercontext.builtin.persistence.migrations.vector_profile import read_embedding_profile

            stored = await connection.run_sync(read_embedding_profile)
            if stored != index.capabilities.embedding_profile:
                raise MigrationError(
                    "embedding_profile_mismatch", "Archive recovery must use the managed vector profile."
                )
        else:
            await index.initialize(connection)
    else:
        await TopicMemoryRepository(index=index).initialize(
            connection, configure_retrieval_shape=not worker, validate_only=validate_only
        )


def _register_prompt_demonstrators(
    target: dict[str, DemonstrationGenerator] | None,
    keys: tuple[str, ...],
    model: Model,
    limits: InferenceLimits,
    settings: ModelSettings | None,
) -> None:
    if target is None:
        return
    from powercontext.builtin.inference.prompt_demonstrations import PromptDemonstrationGenerator

    generator = PromptDemonstrationGenerator(model, limits=limits, model_settings=settings)
    target.update(dict.fromkeys(keys, generator))


async def _dream_generator(
    settings: InferenceConfig,
    budget: DreamBudget,
    resources: AsyncExitStack,
    instrumentation: InstrumentationSettings | None,
) -> DreamGenerator | None:
    if settings.generation_model is None:
        return None
    if settings.generation_model.split(":", 1)[0] not in {
        "openai",
        "openai-chat",
        "openai-responses",
        "anthropic",
    }:
        # Dream requires an adapter whose SDK retries can be disabled explicitly.
        # Other inference workloads retain their existing provider support.
        return None
    from pydantic_ai.settings import ModelSettings

    from powercontext.builtin.inference.pydantic_ai import InferenceLimits, PydanticAIStructuredGenerator

    provider_model, model = await _open_pydantic_ai_model(
        settings.generation_model,
        base_url=settings.generation_base_url,
        headers=settings.generation_headers,
        resources=resources,
        instrumentation=instrumentation,
        disable_provider_retries=True,
        streaming=settings.generation_streaming,
        stream_idle_timeout_seconds=settings.generation_stream_idle_timeout_seconds,
        protection=settings.protection,
    )
    model_settings = cast(ModelSettings, dict(settings.generation_model_settings))
    model_settings["max_tokens"] = min(int(model_settings.get("max_tokens") or 4096), budget.max_output_tokens)
    identity = settings.model_dump_json(
        include={
            "generation_model",
            "generation_base_url",
            "generation_model_settings",
            "generation_timeout_seconds",
        }
    )
    identity = json.dumps(
        [identity, getattr(provider_model, "base_url", None), model_settings],
        sort_keys=True,
        default=str,
    )
    generator = PydanticAIStructuredGenerator(
        model=model,
        instructions=DREAM_INSTRUCTIONS,
        input_type=DreamGenerationInput,
        output_type=DreamPlan,
        limits=InferenceLimits(
            timeout_seconds=min(settings.generation_timeout_seconds, budget.timeout_seconds), max_requests=1
        ),
        model_settings=model_settings,
        name="artifact_dreaming",
    )
    return LLMDreamGenerator(
        UsageReportingStructuredGenerator(generator),
        config_id=content_digest(identity.encode()),
    )


async def _generation_pipelines(
    settings: InferenceConfig,
    runtime: RuntimeConfig,
    resources: AsyncExitStack,
    instrumentation: InstrumentationSettings | None,
    source_registry: SourceDefinitionRegistry,
    *,
    prompt_demonstrators: dict[str, DemonstrationGenerator] | None = None,
) -> tuple[
    ProfileGenerator | None,
    AtomicMemoryGenerationPipeline | None,
    ExperienceCandidatePipeline | None,
    ExperienceGenerator | None,
    SkillGenerator | None,
    HandoffGenerationPipeline | None,
    MemoryReranker | None,
    DecisionModel | None,
    ReadinessProbe | None,
    ReadinessProbe | None,
    ReadinessProbe | None,
]:
    if (
        settings.generation_model is None
        and (not runtime.memory_rerank_enabled or settings.rerank_model is None)
        and not (
            (runtime.decision_assistance_enabled or runtime.memory_write_gate_enabled)
            and settings.decision_model is not None
        )
    ):
        return (None, None, None, None, None, None, None, None, None, None, None)

    from pydantic_ai.settings import ModelSettings, merge_model_settings

    from powercontext.builtin.artifacts.experience import (
        EXPERIENCE_GENERATION_INSTRUCTIONS,
        EXPERIENCE_INCUBATION_INSTRUCTIONS,
        ExperienceGenerationOutput,
        ExperienceIncubationInput,
        ExperienceIncubationOutput,
        LLMExperienceCandidatePipeline,
        LLMExperienceGenerator,
    )
    from powercontext.builtin.artifacts.generation import ArtifactGenerationInput
    from powercontext.builtin.artifacts.handoff import (
        HANDOFF_GENERATION_INSTRUCTIONS,
        HandoffGenerationInput,
        HandoffGenerationOutput,
        LLMHandoffGenerationPipeline,
    )
    from powercontext.builtin.artifacts.memory import (
        MEMORY_RERANK_INSTRUCTIONS,
        LLMMemoryReranker,
        MemoryRerankInput,
        MemoryRerankOutput,
    )
    from powercontext.builtin.artifacts.skill import (
        SKILL_GENERATION_INSTRUCTIONS,
        LLMSkillGenerator,
        SkillGenerationOutput,
    )
    from powercontext.builtin.inference.pydantic_ai import (
        InferenceLimits,
        PydanticAIStructuredGenerator,
        probe_pydantic_ai_model,
    )

    generated_profile: ProfileGenerator | None = None
    generated_memory: AtomicMemoryGenerationPipeline | None = None
    generated_incubation: ExperienceCandidatePipeline | None = None
    generated_experience: ExperienceGenerator | None = None
    generated_skill: SkillGenerator | None = None
    generated_handoff: HandoffGenerationPipeline | None = None
    generated_reranker: MemoryReranker | None = None
    generation_readiness: ReadinessProbe | None = None
    rerank_readiness: ReadinessProbe | None = None

    generation_provider_model: Model | None = None
    generation_model: Model | None = None
    generation_request_settings: ModelSettings | None = None
    if settings.generation_model is not None:
        generation_provider_model, generation_model = await _open_pydantic_ai_model(
            settings.generation_model,
            base_url=settings.generation_base_url,
            headers=settings.generation_headers,
            resources=resources,
            instrumentation=instrumentation,
            streaming=settings.generation_streaming,
            stream_idle_timeout_seconds=settings.generation_stream_idle_timeout_seconds,
            protection=settings.protection,
        )
        generation_request_settings = cast(ModelSettings, dict(settings.generation_model_settings)) or None
        generation_limits = InferenceLimits(
            timeout_seconds=settings.generation_timeout_seconds,
            max_requests=settings.generation_max_requests,
        )
        _register_prompt_demonstrators(
            prompt_demonstrators,
            (
                "profile.generate",
                "atomic_memory.extract",
                "atomic_memory.reconcile",
                "experience.incubate",
                "experience.generate",
                "skill.generate",
                "handoff.generate",
                *(
                    f"topic_memory.{stage}"
                    for stage in ("probe", "global", "planner", "evolve", "temporary", "reduce", "reconcile")
                ),
            ),
            generation_model,
            generation_limits,
            generation_request_settings,
        )
        generated_profile = LLMProfileGenerator(
            UsageReportingStructuredGenerator(
                PydanticAIStructuredGenerator(
                    model=generation_model,
                    instructions=PROFILE_INSTRUCTIONS,
                    input_type=ProfileGenerationInput,
                    output_type=ProfileGenerationOutput,
                    limits=generation_limits,
                    model_settings=generation_request_settings,
                    name="profile_generation",
                    prompt_key="profile.generate",
                )
            )
        )
        memory_estimator = character_token_estimator()
        input_policy = PrivacyPolicy(settings.protection)
        memory_modes = {
            stage: settings.input_encoding_mode(stage) for stage in ("atomic_memory.extract", "atomic_memory.reconcile")
        }
        memory_input_renderer = (
            None
            if all(mode == "off" for mode in memory_modes.values())
            else partial(
                render_atomic_memory_input,
                modes=memory_modes,
                estimator=memory_estimator,
                policy=input_policy,
            )
        )
        memory_send_renderer = None if memory_input_renderer is None else partial(memory_input_renderer, observe=True)
        memory_generator = PydanticAIStructuredGenerator(
            model=generation_model,
            instructions=atomic_memory_extraction_instructions(runtime.memory_extraction_profile),
            input_type=AtomicMemoryExtractionInput,
            output_type=AtomicMemoryExtractionOutput,
            limits=generation_limits,
            model_settings=generation_request_settings,
            name="atomic_memory_extraction",
            prompt_key="atomic_memory.extract",
            output_check=validate_extraction_output,
            input_renderer=memory_send_renderer,
        )
        memory_reconciler = PydanticAIStructuredGenerator(
            model=generation_model,
            instructions=ATOMIC_MEMORY_RECONCILIATION_INSTRUCTIONS,
            input_type=AtomicMemoryReconciliationInput,
            output_type=AtomicMemoryReconciliationOutput,
            limits=generation_limits,
            model_settings=generation_request_settings,
            name="atomic_memory_reconciliation",
            prompt_key="atomic_memory.reconcile",
            output_check=validate_reconciliation_decision,
            input_renderer=memory_send_renderer,
        )
        experience_generator = PydanticAIStructuredGenerator(
            model=generation_model,
            instructions=EXPERIENCE_INCUBATION_INSTRUCTIONS,
            input_type=ExperienceIncubationInput,
            output_type=ExperienceIncubationOutput,
            limits=generation_limits,
            model_settings=generation_request_settings,
            name="experience_incubation",
            prompt_key="experience.incubate",
            input_renderer=(
                partial(
                    render_input,
                    stage="experience.incubate",
                    schema=INPUT_ENCODING_SCHEMA_V2,
                    mode=settings.input_encoding_mode("experience.incubate"),
                    estimator=memory_estimator,
                    policy=input_policy,
                    observe=True,
                )
                if settings.input_encoding_mode("experience.incubate") != "off"
                else None
            ),
        )
        explicit_experience_generator = PydanticAIStructuredGenerator(
            model=generation_model,
            instructions=EXPERIENCE_GENERATION_INSTRUCTIONS,
            input_type=ArtifactGenerationInput,
            output_type=ExperienceGenerationOutput,
            limits=generation_limits,
            model_settings=generation_request_settings,
            name="experience_generation",
            prompt_key="experience.generate",
            input_renderer=(
                partial(
                    render_input,
                    stage="experience.generate",
                    schema=INPUT_ENCODING_SCHEMA_V2,
                    mode=settings.input_encoding_mode("experience.generate"),
                    estimator=memory_estimator,
                    policy=input_policy,
                    observe=True,
                )
                if settings.input_encoding_mode("experience.generate") != "off"
                else None
            ),
        )
        skill_generator = PydanticAIStructuredGenerator(
            model=generation_model,
            instructions=SKILL_GENERATION_INSTRUCTIONS,
            input_type=ArtifactGenerationInput,
            output_type=SkillGenerationOutput,
            limits=generation_limits,
            model_settings=generation_request_settings,
            name="skill_generation",
            prompt_key="skill.generate",
        )
        handoff_generator = PydanticAIStructuredGenerator(
            model=generation_model,
            instructions=HANDOFF_GENERATION_INSTRUCTIONS,
            input_type=HandoffGenerationInput,
            output_type=HandoffGenerationOutput,
            limits=generation_limits,
            model_settings=generation_request_settings,
            name="handoff_generation",
            prompt_key="handoff.generate",
        )
        generated_memory = AtomicMemoryGenerationPipeline(
            extractor=UsageReportingStructuredGenerator(memory_generator),
            reconciler=UsageReportingStructuredGenerator(memory_reconciler),
            estimator=memory_estimator,
            extraction_instructions=atomic_memory_extraction_instructions(runtime.memory_extraction_profile),
            input_renderer=memory_input_renderer,
        )
        generated_incubation = LLMExperienceCandidatePipeline(UsageReportingStructuredGenerator(experience_generator))
        generated_experience = LLMExperienceGenerator(UsageReportingStructuredGenerator(explicit_experience_generator))
        generated_skill = LLMSkillGenerator(UsageReportingStructuredGenerator(skill_generator))
        generated_handoff = LLMHandoffGenerationPipeline(
            UsageReportingStructuredGenerator(handoff_generator),
            evidence_projector=_DefinitionHandoffEvidenceProjector(source_registry, TEXT_EVIDENCE_PROJECTION_KEY),
        )

        async def probe_generation() -> None:
            # Readiness probing runs outside any operation span; keep it out of traces.
            await probe_pydantic_ai_model(
                generation_provider_model,
                timeout_seconds=settings.generation_timeout_seconds,
                model_settings=generation_request_settings,
            )

        generation_readiness = CachedReadinessProbe(
            dependency_readiness_probe(probe_generation, timeout_seconds=settings.generation_timeout_seconds)
        )

    if runtime.memory_rerank_enabled:
        rerank_provider_model = generation_provider_model
        rerank_model = generation_model
        inherits_generation = settings.rerank_model is None
        rerank_headers = (
            _merge_headers(settings.generation_headers, settings.rerank_headers)
            if inherits_generation
            else settings.rerank_headers
        )
        separate_rerank_model = settings.rerank_model is not None or bool(settings.rerank_headers)
        if separate_rerank_model:
            rerank_model_name = settings.rerank_model or settings.generation_model
            if rerank_model_name is None:
                raise BuiltinConfigurationError("memory-reranker")
            rerank_provider_model, rerank_model = await _open_pydantic_ai_model(
                rerank_model_name,
                base_url=settings.rerank_base_url
                if settings.rerank_model is not None
                else settings.generation_base_url,
                headers=rerank_headers,
                resources=resources,
                instrumentation=instrumentation,
                streaming=settings.generation_streaming,
                stream_idle_timeout_seconds=settings.generation_stream_idle_timeout_seconds,
                protection=settings.protection,
            )
        if rerank_provider_model is not None and rerank_model is not None:
            rerank_values = (
                settings.generation_model_settings | settings.rerank_model_settings
                if inherits_generation
                else settings.rerank_model_settings
            )
            rerank_request_settings = cast(ModelSettings, dict(rerank_values))
            rerank_request_settings = merge_model_settings(
                rerank_request_settings,
                ModelSettings(temperature=0.0),
            )
            rerank_generator = PydanticAIStructuredGenerator(
                model=rerank_model,
                instructions=MEMORY_RERANK_INSTRUCTIONS,
                input_type=MemoryRerankInput,
                output_type=MemoryRerankOutput,
                limits=InferenceLimits(
                    timeout_seconds=settings.rerank_timeout_seconds or settings.generation_timeout_seconds,
                    max_requests=settings.rerank_max_requests or settings.generation_max_requests,
                ),
                model_settings=rerank_request_settings,
                name="memory_rerank",
                prompt_key="memory.rerank",
            )
            generated_reranker = LLMMemoryReranker(UsageReportingStructuredGenerator(rerank_generator))
            _register_prompt_demonstrators(
                prompt_demonstrators,
                ("memory.rerank",),
                rerank_model,
                InferenceLimits(
                    timeout_seconds=settings.rerank_timeout_seconds or settings.generation_timeout_seconds,
                    max_requests=settings.rerank_max_requests or settings.generation_max_requests,
                ),
                rerank_request_settings,
            )

            if separate_rerank_model or settings.rerank_model_settings:

                async def probe_rerank() -> None:
                    timeout_seconds = settings.rerank_timeout_seconds or settings.generation_timeout_seconds
                    await probe_pydantic_ai_model(
                        rerank_provider_model,
                        timeout_seconds=timeout_seconds,
                        model_settings=rerank_request_settings,
                    )

                rerank_readiness = CachedReadinessProbe(
                    dependency_readiness_probe(
                        probe_rerank,
                        timeout_seconds=settings.rerank_timeout_seconds or settings.generation_timeout_seconds,
                    )
                )

    generated_decision, decision_readiness = await _generation_decision(
        settings,
        runtime,
        resources,
        instrumentation,
        generation_provider_model=generation_provider_model,
        generation_model=generation_model,
    )

    return (
        generated_profile,
        generated_memory,
        generated_incubation,
        generated_experience,
        generated_skill,
        generated_handoff,
        generated_reranker,
        generated_decision,
        generation_readiness,
        rerank_readiness,
        decision_readiness,
    )


async def _generation_decision(
    settings: InferenceConfig,
    runtime: RuntimeConfig,
    resources: AsyncExitStack,
    instrumentation: InstrumentationSettings | None,
    *,
    generation_provider_model: Model | None,
    generation_model: Model | None,
) -> tuple[DecisionModel | None, ReadinessProbe | None]:
    """Build the opt-in decision backend, reusing the generation model when not overridden."""

    if not runtime.decision_assistance_enabled and not runtime.memory_write_gate_enabled:
        return None, None

    from pydantic_ai.settings import ModelSettings, merge_model_settings

    from powercontext.builtin.inference.pydantic_ai import (
        InferenceLimits,
        PydanticAIStructuredGenerator,
        probe_pydantic_ai_model,
    )

    decision_provider_model = generation_provider_model
    decision_model = generation_model
    decision_model_name = settings.decision_model or settings.generation_model
    inherits_generation = settings.decision_model is None
    decision_headers = (
        _merge_headers(settings.generation_headers, settings.decision_headers)
        if inherits_generation
        else settings.decision_headers
    )
    separate_decision_model = settings.decision_model is not None or bool(settings.decision_headers)
    if separate_decision_model:
        if decision_model_name is None:
            raise BuiltinConfigurationError("decision-model")
        decision_provider_model, decision_model = await _open_pydantic_ai_model(
            decision_model_name,
            base_url=settings.decision_base_url
            if settings.decision_model is not None
            else settings.generation_base_url,
            headers=decision_headers,
            resources=resources,
            instrumentation=instrumentation,
            streaming=settings.generation_streaming,
            stream_idle_timeout_seconds=settings.generation_stream_idle_timeout_seconds,
            protection=settings.protection,
        )
    if decision_provider_model is None or decision_model is None:
        return None, None
    decision_values = (
        settings.generation_model_settings | settings.decision_model_settings
        if inherits_generation
        else settings.decision_model_settings
    )
    decision_request_settings = cast(ModelSettings, dict(decision_values))
    decision_request_settings = merge_model_settings(
        decision_request_settings,
        ModelSettings(temperature=0.0),
    )
    decision_generator = PydanticAIStructuredGenerator(
        model=decision_model,
        instructions=DECISION_INSTRUCTIONS,
        input_type=DecisionInput,
        output_type=DecisionOutput,
        limits=InferenceLimits(
            timeout_seconds=settings.decision_timeout_seconds or settings.generation_timeout_seconds,
            max_requests=settings.decision_max_requests or settings.generation_max_requests,
        ),
        model_settings=decision_request_settings,
        name="decision_evaluate",
    )
    generated_decision = LLMDecisionModel(
        UsageReportingStructuredGenerator(decision_generator),
        is_local_only=_is_loopback_endpoint(
            settings.decision_base_url if settings.decision_model is not None else settings.generation_base_url
        ),
        provider_id=None if decision_model_name is None else decision_model_name.partition(":")[0],
        backend_model_id=None
        if decision_model_name is None
        else decision_model_name.partition(":")[2] or decision_model_name,
    )

    decision_readiness: ReadinessProbe | None = None
    if separate_decision_model or settings.decision_model_settings:

        async def probe_decision() -> None:
            timeout_seconds = settings.decision_timeout_seconds or settings.generation_timeout_seconds
            await probe_pydantic_ai_model(
                decision_provider_model,
                timeout_seconds=timeout_seconds,
                model_settings=decision_request_settings,
            )

        decision_readiness = CachedReadinessProbe(
            dependency_readiness_probe(
                probe_decision,
                timeout_seconds=settings.decision_timeout_seconds or settings.generation_timeout_seconds,
            )
        )
    return generated_decision, decision_readiness


async def preflight_builtin_runtime(
    config: BuiltinConfig,
    *,
    decision_request_sanitizer: DecisionRequestProjectionSanitizer | None = None,
    memory_write_gate: MemoryWriteGate | None = None,
) -> None:
    """Validate Runtime composition without opening persistence or making requests."""

    async with AsyncExitStack() as resources:
        generated_pipelines = await _generation_pipelines(
            config.inference,
            config.runtime,
            resources,
            None,
            BUILTIN_SOURCE_REGISTRY,
        )
        if memory_write_gate is None:
            _resolve_memory_write_gate_sanitizer(
                config.runtime,
                decision_request_sanitizer,
                generated_pipelines[7],
            )
        if config.inference.embedding_model is not None:
            await _embedding_models(config.inference, resources, None)
        if config.runtime.schedule_seconds is not None and config.inference.generation_model is None:
            raise BuiltinConfigurationError("scheduled-pipeline")
        if config.runtime.experience_schedule_seconds is not None and config.inference.generation_model is None:
            raise BuiltinConfigurationError("scheduled-experience-pipeline")
        if config.runtime.memory_rerank_enabled and (
            config.inference.generation_model is None and config.inference.rerank_model is None
        ):
            raise BuiltinConfigurationError("memory-reranker")
        if config.runtime.decision_assistance_enabled and (
            config.inference.generation_model is None and config.inference.decision_model is None
        ):
            raise BuiltinConfigurationError("decision-model")


async def _open_pydantic_ai_model(
    model_name: str,
    *,
    base_url: AnyHttpUrl | None,
    headers: Mapping[str, SecretStr],
    resources: AsyncExitStack,
    instrumentation: InstrumentationSettings | None,
    disable_provider_retries: bool = False,
    streaming: Literal["auto", "disabled"] = "disabled",
    stream_idle_timeout_seconds: float = 60.0,
    protection: InferenceProtectionConfig | None = None,
) -> tuple[Model, Model]:
    from pydantic_ai.models import infer_model
    from pydantic_ai.models.instrumented import InstrumentedModel

    if (base_url is not None or headers) and ":" not in model_name:
        raise BuiltinConfigurationError("inference-endpoint-provider")
    inferred_model = infer_model(
        model_name,
        provider_factory=_provider_factory(
            base_url,
            headers,
            workload="generation",
            resources=resources,
            disable_retries=disable_provider_retries,
            protection=protection,
        ),
    )
    provider_model = await resources.enter_async_context(inferred_model)
    model = provider_model
    if streaming == "auto" and model_name.split(":", 1)[0] in _STREAMING_AGGREGATED_PROVIDERS:
        # Gateways in front of non-streaming endpoints may drop idle exchanges
        # long before the configured generation timeout; aggregate one streamed
        # request instead. The wall-clock budget stays owned by the generator.
        from powercontext.builtin.inference.pydantic_ai import StreamingAggregateModel

        model = StreamingAggregateModel(model, idle_timeout_seconds=stream_idle_timeout_seconds)
    elif streaming == "auto":
        log_safely(
            logger,
            logging.WARNING,
            "Streamed generation aggregation was not applied because the model provider prefix "
            "is outside the supported set",
            extra={
                "event": "inference.generation.streaming_not_applied",
                "operation": "generate",
                "unit": "inference",
            },
        )
    model = model if instrumentation is None else InstrumentedModel(model, instrumentation)
    return provider_model, model


_STREAMING_AGGREGATED_PROVIDERS = frozenset({"anthropic", "openai", "openai-chat", "openai-responses"})


def _provider_factory(
    base_url: AnyHttpUrl | None,
    headers: Mapping[str, SecretStr],
    *,
    workload: Literal["generation", "embedding"],
    resources: AsyncExitStack,
    disable_retries: bool = False,
    protection: InferenceProtectionConfig | None = None,
) -> Callable[[str], Provider[Any]]:
    if protection is not None and protection.mode != "disabled":
        create_provider = _protected_provider_factory(
            base_url,
            headers,
            workload=workload,
            resources=resources,
            protection=protection,
            disable_retries=disable_retries or protection.mode == "enforcing",
        )
    else:
        create_provider = _unbounded_provider_factory(base_url, headers, workload=workload, resources=resources)

    def create(name: str) -> Provider[Any]:
        provider = create_provider(name)
        observer = current_provider_observer()
        if observer is not None:
            import httpx2

            client = getattr(provider, "_own_http_client", None)
            # Explicit SDK clients above are newly owned by this Runtime as well.
            if client is None and name in {"openai", "openai-chat", "openai-responses", "anthropic", "openai-codex"}:
                client = getattr(provider.client, "_client", None)
            supported = False
            if isinstance(client, httpx2.AsyncClient):
                with suppress(Exception):
                    observe_http_client(client)
                    supported = True
            ProviderObservationSource(provider_name(provider.name), workload, observer).emit(
                "coverage", outcome="available" if supported else "unavailable"
            )
        return provider

    if not disable_retries or (protection is not None and protection.mode != "disabled"):
        return create

    def bounded(provider_name: str) -> Provider[Any]:
        from anthropic import AsyncAnthropic
        from openai import AsyncOpenAI

        provider = create(provider_name)
        client = provider.client
        if not isinstance(client, (AsyncOpenAI, AsyncAnthropic)):
            # No unmetered provider-specific retry policy in a Topic Worker.
            raise BuiltinConfigurationError("topic-memory-provider-budget")
        client.max_retries = 0
        return provider

    return bounded


def _protected_provider_factory(
    base_url: AnyHttpUrl | None,
    headers: Mapping[str, SecretStr],
    *,
    workload: Literal["generation", "embedding"],
    resources: AsyncExitStack,
    protection: InferenceProtectionConfig,
    disable_retries: bool,
) -> Callable[[str], Provider[Any]]:
    """Own the final transport, including SDK defaults and auxiliary models."""

    import httpx2

    from powercontext.builtin.inference.protected_transport import ProtectedAsyncTransport

    def create(provider_name: str) -> Provider[Any]:
        # Explicit client injection avoids SDK cached clients, redirect behavior,
        # hidden transport retries and provider-side request inspection bypasses.
        client = httpx2.AsyncClient(
            transport=ProtectedAsyncTransport(protection),
            follow_redirects=False,
            headers={"Accept-Encoding": "identity"},
        )
        resources.push_async_callback(client.aclose)
        if provider_name in {"openai", "openai-chat", "openai-responses"}:
            from openai import AsyncOpenAI
            from pydantic_ai.providers.openai import OpenAIProvider

            sdk = AsyncOpenAI(
                base_url=None if base_url is None else str(base_url),
                api_key=os.getenv("OPENAI_API_KEY") or "api-key-not-set",
                default_headers=_resolve_headers(headers),
                http_client=client,
            )
            if disable_retries:
                sdk.max_retries = 0
            resources.push_async_callback(sdk.close)
            return OpenAIProvider(openai_client=sdk)
        if provider_name == "anthropic" and workload == "generation":
            from pydantic_ai.providers.anthropic import AnthropicProvider

            sdk = _anthropic_client(base_url, headers, http_client=client)
            if disable_retries:
                sdk.max_retries = 0
            resources.push_async_callback(sdk.close)
            return AnthropicProvider(anthropic_client=sdk)
        raise BuiltinConfigurationError("inference-endpoint-provider")

    return create


def _unbounded_provider_factory(
    base_url: AnyHttpUrl | None,
    headers: Mapping[str, SecretStr],
    *,
    workload: Literal["generation", "embedding"],
    resources: AsyncExitStack,
) -> Callable[[str], Provider[Any]]:
    import httpx2
    from pydantic_ai.providers import infer_provider
    from pydantic_ai.providers.openai import OpenAIProvider

    def create_provider(provider_name: str) -> Provider[Any]:
        if base_url is None and not headers:
            if provider_name == "openai-codex" and workload == "generation":
                from powercontext.builtin.inference.codex import codex_cli_provider

                return codex_cli_provider(resources)
            if provider_name != "anthropic" or not os.getenv("ANTHROPIC_BASE_URL"):
                return infer_provider(provider_name)
        if provider_name in {"openai", "openai-chat", "openai-responses"}:
            if headers:
                from openai import AsyncOpenAI

                http_client = httpx2.AsyncClient(follow_redirects=False) if base_url is not None else None
                client = AsyncOpenAI(
                    base_url=None if base_url is None else str(base_url),
                    api_key=os.getenv("OPENAI_API_KEY") or "api-key-not-set",
                    default_headers=_resolve_headers(headers),
                    http_client=http_client,
                )
                resources.push_async_callback(client.close)
                return OpenAIProvider(openai_client=client)
            if base_url is not None and _is_loopback_endpoint(base_url):
                http_client = httpx2.AsyncClient(follow_redirects=False)
                resources.push_async_callback(http_client.aclose)
                return OpenAIProvider(base_url=str(base_url), http_client=http_client)
            return OpenAIProvider(base_url=str(base_url))
        if provider_name == "anthropic" and workload == "generation":
            from pydantic_ai.providers.anthropic import AnthropicProvider

            client = _anthropic_client(base_url, headers)
            resources.push_async_callback(client.close)
            return AnthropicProvider(anthropic_client=client)
        raise BuiltinConfigurationError("inference-endpoint-provider")

    return create_provider


def _anthropic_client(
    base_url: AnyHttpUrl | None,
    headers: Mapping[str, SecretStr],
    *,
    http_client: httpx2.AsyncClient | None = None,
) -> AsyncAnthropic:
    import httpx2
    from anthropic import AsyncAnthropic

    endpoint = str(base_url) if base_url is not None else os.getenv("ANTHROPIC_BASE_URL")
    custom_endpoint = endpoint is not None and urlsplit(endpoint).hostname != "api.anthropic.com"
    resolved = _resolve_headers(headers)
    header_api_key = _pop_header(resolved, "x-api-key")
    api_key = header_api_key or os.getenv("ANTHROPIC_API_KEY")
    has_authorization = any(name.casefold() == "authorization" for name in resolved)
    if api_key and has_authorization:
        resolved["X-Api-Key"] = api_key
    if http_client is None and endpoint is not None:
        http_client = httpx2.AsyncClient(follow_redirects=False)
    if api_key and not has_authorization and (base_url is not None or custom_endpoint or header_api_key is not None):
        http_client = http_client or httpx2.AsyncClient()
        http_client.auth = partial(_anthropic_api_key_header, api_key=api_key)
    return AsyncAnthropic(
        base_url=endpoint,
        api_key=api_key or (None if has_authorization else "api-key-not-set"),
        default_headers=resolved,
        http_client=http_client,
    )


def _anthropic_api_key_header(request: httpx2.Request, *, api_key: str) -> httpx2.Request:
    """Keep custom endpoints compatible with the pre-v2 Anthropic authentication header."""

    if request.headers.get("Authorization") == f"Bearer {api_key}":
        del request.headers["Authorization"]
        request.headers["X-Api-Key"] = api_key
    return request


def _is_loopback_endpoint(endpoint: AnyHttpUrl | str | None) -> bool:
    """Allow only explicit local names and addresses for raw decision content."""

    if endpoint is None:
        return False
    try:
        host = urlsplit(str(endpoint)).hostname
    except ValueError:
        return False
    if host is None:
        return False
    host = host.lower()
    if host == "localhost":
        return True
    try:
        return ip_address(host).is_loopback
    except ValueError:
        return False


def _resolve_headers(headers: Mapping[str, SecretStr]) -> dict[str, str]:
    return {name: value.get_secret_value() for name, value in headers.items()}


def _pop_header(headers: dict[str, str], name: str) -> str | None:
    expected = name.casefold()
    for existing_name in headers:
        if existing_name.casefold() == expected:
            return headers.pop(existing_name)
    return None


def _merge_headers(*values: Mapping[str, SecretStr]) -> dict[str, SecretStr]:
    merged: dict[str, SecretStr] = {}
    names: dict[str, str] = {}
    for headers in values:
        for name, value in headers.items():
            normalized_name = name.casefold()
            if previous_name := names.get(normalized_name):
                del merged[previous_name]
            merged[name] = value
            names[normalized_name] = name
    return merged


def _prompt_registry(
    runtime: RuntimeConfig,
    components: tuple[tuple[str, object | None, object | None], ...],
) -> PromptRegistry:
    """Infer Prompt support from executable generated components in either process."""

    injected = frozenset(key for key, supplied, _ in components if supplied is not None)
    return PromptRegistry(
        builtin_prompt_definitions(runtime.memory_extraction_profile),
        supported=frozenset(
            key for key, supplied, generated in components if supplied is None and generated is not None
        ),
        injected=injected,
        disabled=frozenset({"memory.rerank"})
        if not runtime.memory_rerank_enabled and "memory.rerank" not in injected
        else frozenset(),
    )


def _usage_reporting_embedding_model(model: EmbeddingModel | None) -> EmbeddingModel | None:
    """Attribute operational embeddings once, leaving readiness adapters unwrapped."""

    if model is None or isinstance(model, UsageReportingEmbeddingModel):
        return model
    return UsageReportingEmbeddingModel(model)


def _embedding_provider_settings(settings: InferenceConfig, dimension: int) -> dict[str, JsonValue]:
    """Return embedding request settings, keeping stored dimension separate from the wire field."""

    request_settings = dict(settings.embedding_model_settings)
    if settings.embedding_send_dimensions:
        request_settings["dimensions"] = dimension
    else:
        request_settings.pop("dimensions", None)
    return request_settings


async def _embedding_models(
    settings: InferenceConfig,
    resources: AsyncExitStack,
    instrumentation: InstrumentationSettings | None,
    *,
    disable_provider_retries: bool = False,
) -> tuple[EmbeddingModel | None, EmbeddingModel | None]:
    if settings.embedding_model is None:
        return None, None

    from powercontext.builtin.inference.minimax import is_minimax_embedding

    if is_minimax_embedding(
        str(settings.embedding_base_url) if settings.embedding_base_url is not None else None,
        settings.embedding_model,
    ):
        return _minimax_embedding_models(settings, resources, instrumentation)

    from pydantic_ai import Embedder
    from pydantic_ai.embeddings import EmbeddingSettings, infer_embedding_model

    from powercontext.builtin.artifacts.memory import EmbeddingProfile
    from powercontext.builtin.inference.pydantic_ai import InferenceLimits, PydanticAIEmbeddingModel

    providers: list[Provider[Any]] = []
    create_provider = _provider_factory(
        settings.embedding_base_url,
        settings.embedding_headers,
        workload="embedding",
        resources=resources,
        disable_retries=disable_provider_retries,
        protection=settings.protection,
    )

    def provider_factory(provider_name: str) -> Provider[Any]:
        provider = create_provider(provider_name)
        providers.append(provider)
        return provider

    model = infer_embedding_model(settings.embedding_model, provider_factory=provider_factory)
    for provider in providers:
        await resources.enter_async_context(provider)
    profile = EmbeddingProfile(
        profile_id=_required(settings.embedding_profile_id),
        model=settings.embedding_model,
        dimension=_required(settings.embedding_dimension),
        distance="l2",
        normalization=settings.embedding_normalization,
    )
    limits = InferenceLimits(timeout_seconds=settings.embedding_timeout_seconds)
    embedding_settings = cast(
        EmbeddingSettings,
        _embedding_provider_settings(settings, profile.dimension),
    )

    def adapter(instrument: InstrumentationSettings | bool | None) -> EmbeddingModel:
        return PydanticAIEmbeddingModel(
            embedder=Embedder(model, settings=embedding_settings, instrument=instrument),
            batch_size=settings.embedding_batch_size,
            profile=profile,
            limits=limits,
        )

    # Readiness runs outside an application operation, so use the same provider model
    # without instrumentation to avoid exporting an orphan inference span.
    return adapter(instrumentation), adapter(False)


def _minimax_embedding_models(
    settings: InferenceConfig,
    resources: AsyncExitStack,
    instrumentation: InstrumentationSettings | None,
) -> tuple[EmbeddingModel | None, EmbeddingModel | None]:
    """Build operational and readiness MiniMax embedding adapters.

    MiniMax is detected by host or model prefix and requires an explicit base URL
    plus a header secret, both already supplied by the inference configuration.
    """

    from powercontext.builtin.artifacts.memory import EmbeddingProfile
    from powercontext.builtin.inference.minimax import MiniMaxEmbeddingModel, _embedding_model_name

    if settings.embedding_model is None or settings.embedding_base_url is None:
        raise BuiltinConfigurationError("inference-endpoint-provider")
    profile = EmbeddingProfile(
        profile_id=_required(settings.embedding_profile_id),
        model=settings.embedding_model,
        dimension=_required(settings.embedding_dimension),
        distance="l2",
        normalization=settings.embedding_normalization,
    )
    headers = _resolve_headers(settings.embedding_headers) if settings.embedding_headers else None
    model_name = _embedding_model_name(settings.embedding_model)

    def adapter(instrument: InstrumentationSettings | bool | None) -> EmbeddingModel:
        model = MiniMaxEmbeddingModel(
            base_url=str(settings.embedding_base_url),
            model=model_name,
            headers=headers,
            profile=profile,
            batch_size=settings.embedding_batch_size,
            timeout_seconds=settings.embedding_timeout_seconds,
            protection=settings.protection,
        )
        resources.push_async_callback(model.aclose)
        return model

    # MiniMax has no OpenTelemetry instrumentation hook; readiness uses the same
    # instance kind as the operational adapter.
    return adapter(instrumentation), adapter(False)


def _embedding_readiness_probe(model: EmbeddingModel) -> ReadinessProbe:
    async def probe_embedding() -> None:
        with suppress_provider_observation():
            await model.embed(("PowerContext readiness probe",))

    return CachedReadinessProbe(dependency_readiness_probe(probe_embedding))


def _required(value: ValueT | None) -> ValueT:
    if value is None:
        raise BuiltinConfigurationError("inference-profile")
    return value


def _external_skill_provider(settings: ExternalSkillsConfig) -> ExternalSkillProvider | None:
    if not settings.agent_targets:
        return None
    if settings.host_id is None:
        raise BuiltinConfigurationError("external-skill-host")
    return AgentSkillProvider(host_id=settings.host_id, targets=settings.agent_targets)


def _search_modes(capabilities: AtomicMemoryIndexCapabilities) -> tuple[MemorySearchMode, ...]:
    modes: list[MemorySearchMode] = []
    if capabilities.fts or capabilities.hybrid:
        modes.append("auto")
    if capabilities.fts:
        modes.append("fts")
    if capabilities.vector:
        modes.append("vector")
    if capabilities.hybrid:
        modes.append("hybrid")
    return tuple(modes)


__all__ = ["BuiltinConfigurationError", "open_builtin_contexts", "open_builtin_runtime", "preflight_builtin_runtime"]


async def _initialize_atomic_memory_authority(connection) -> None:
    """Create formal authority storage without importing legacy business data."""
    from powercontext.builtin.authz.repository import ACCESS_POLICY_HEADS_TABLE, ACCESS_TABLES
    from powercontext.builtin.persistence.schema import create_tables

    await create_tables(connection, ACCESS_TABLES)
    if connection.dialect.name == "sqlite":
        from sqlalchemy.dialects.sqlite import insert as upsert

        statement = (
            upsert(ACCESS_POLICY_HEADS_TABLE)
            .values(name="authorization", revision=0)
            .on_conflict_do_nothing(index_elements=["name"])
        )
    else:
        from sqlalchemy.dialects.mysql import insert as upsert

        statement = upsert(ACCESS_POLICY_HEADS_TABLE).values(name="authorization", revision=0)
        statement = statement.on_duplicate_key_update(revision=ACCESS_POLICY_HEADS_TABLE.c.revision)
    await connection.execute(statement)
