# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Atomic Memory projection publication and complete retrieval contracts."""

from __future__ import annotations

import json
import math
from collections.abc import Sequence
from dataclasses import dataclass, replace
from hashlib import sha256
from typing import Any, Literal, Protocol

from pydantic import BaseModel
from sqlalchemy import Table, bindparam, delete, func, inspect, or_, select, text, update
from sqlalchemy.dialects.mysql import insert as mysql_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert
from sqlalchemy.ext.asyncio import AsyncConnection

from powercontext.artifacts import ArtifactRef, ChannelScore
from powercontext.artifacts.fusion import FusionCandidate, FusionChannel, RrfParameters, fuse_rrf
from powercontext.builtin.artifacts.memory import EmbeddingProfile
from powercontext.builtin.artifacts.memory.canonical import canonical_embedding, canonical_json, normalize_query
from powercontext.builtin.artifacts.search import (
    DEFAULT_ADMISSION_FLOOR,
    AdmissionFloor,
    InvalidSearchScore,
    RecallChannelWeights,
    analyze_text,
    fts_query_requirements,
    fts_required_matches,
    lexical_search_score,
)
from powercontext.builtin.inference import EmbeddingModel
from powercontext.builtin.persistence.atomic_memory_evidence import (
    AtomicMemoryEvidenceAnnotation,
    AtomicMemoryEvidenceRepository,
)
from powercontext.builtin.persistence.atomic_memory_evidence_schema import ATOMIC_MEMORY_EVIDENCE_TABLES
from powercontext.builtin.persistence.atomic_memory_index_schema import (
    ATOMIC_MEMORY_EVIDENCE_PROJECTION_TABLE,
    ATOMIC_MEMORY_PROJECTION_FORMAT,
)
from powercontext.builtin.persistence.sources import SourceRepository
from powercontext.builtin.persistence.tables import ARTIFACT_TAGS_TABLE
from powercontext.builtin.tags import TagFilter
from powercontext.sources.evidence import SourceEvidence

AtomicMemorySearchMode = Literal["fts", "vector", "hybrid"]
ATOMIC_MEMORY_RRF_CONSTANT = 60
DEFAULT_ATOMIC_MEMORY_RELATED_PAGE_SIZE = 250
# Columns of unreleased development layouts; their tables are derived and rebuilt rather than migrated.
_OBSOLETE_PROJECTION_COLUMNS = frozenset({"read_grants", "owner_type", "owner_id"})


async def _projection_columns(connection: AsyncConnection, table: Table) -> set[str]:
    if connection.dialect.name == "mysql":
        return set(
            await connection.scalars(
                text(
                    "SELECT column_name FROM information_schema.columns "
                    "WHERE table_schema = DATABASE() AND table_name = :table_name"
                ),
                {"table_name": table.name},
            )
        )

    def read(sync: Any) -> set[str]:
        inspector = inspect(sync)
        if not inspector.has_table(table.name):
            return set()
        return {column["name"] for column in inspector.get_columns(table.name)}

    return await connection.run_sync(read)


async def drop_obsolete_atomic_memory_projection(connection: AsyncConnection, table: Table) -> bool:
    """Drop a development-layout current table so initialization recreates it; authority stays unchanged."""

    if not await _projection_columns(connection, table) & _OBSOLETE_PROJECTION_COLUMNS:
        return False
    await connection.run_sync(lambda sync: table.drop(sync))
    if connection.dialect.name == "sqlite":
        await connection.exec_driver_sql(f"DROP TABLE IF EXISTS {table.name}_fts")
    return True


class AtomicMemoryIndexError(RuntimeError):
    """Retrieval cannot meet the requested channel or completeness contract."""

    def __init__(self, code: str, message: str) -> None:
        self.code = code
        super().__init__(message)


@dataclass(frozen=True)
class AtomicMemoryIndexCapabilities:
    fts: bool = True
    vector: bool = False
    hybrid: bool = False
    tag_filter: bool = True
    embedding_profile: EmbeddingProfile | None = None


@dataclass(frozen=True)
class AtomicMemoryIndexFilter:
    """Same-row content filters; the runtime authorizes Scope read first."""

    tag_filter: TagFilter | None = None
    kind: str | None = None


@dataclass(frozen=True)
class PreparedAtomicMemoryProjection:
    kind: str
    text: str
    searchable_text: str
    content_hash: str
    description: str | None = None
    embedding: tuple[float, ...] | None = None
    embedding_profile: EmbeddingProfile | None = None
    profile_fingerprint: str | None = None
    embedding_input_hash: str | None = None


@dataclass(frozen=True)
class AtomicMemoryProjection:
    artifact_ref: ArtifactRef
    state_version: int
    prepared: PreparedAtomicMemoryProjection
    tag_keys: tuple[str, ...]


@dataclass(frozen=True)
class AtomicMemoryIndexHit:
    artifact_ref: ArtifactRef
    state_version: int
    kind: str
    text: str
    score: float
    distance: float | None = None
    channel_scores: dict[str, ChannelScore] | None = None
    retrieval_score: float | None = None


@dataclass(frozen=True)
class AtomicMemorySearchChannels:
    fts: tuple[AtomicMemoryIndexHit, ...] = ()
    vector: tuple[AtomicMemoryIndexHit, ...] = ()


@dataclass(frozen=True)
class AtomicMemoryRelatedRank:
    """One lightweight channel rank; bodies are fetched only for the current page."""

    artifact_ref: ArtifactRef
    state_version: int
    kind: str
    score: float
    distance: float | None = None
    channel_scores: dict[str, ChannelScore] | None = None


@dataclass(frozen=True)
class AtomicMemoryRelatedCursor:
    """Complete lightweight rank snapshot taken when the enumeration started.

    Later pages slice ``ranks`` by ``offset``. Rankings depend on corpus statistics,
    so re-ranking a later page could reorder or skip candidates after another Scope
    changes. No body is retained here: each page still reads and authorizes only
    its own identities.
    """

    ranks: tuple[AtomicMemoryRelatedRank, ...]
    offset: int = 0


@dataclass(frozen=True)
class AtomicMemoryRelatedPage:
    hits: tuple[AtomicMemoryIndexHit, ...]
    heads: dict[str, dict[str, object]]
    cursor: AtomicMemoryRelatedCursor | None


@dataclass(frozen=True)
class AtomicMemorySearchRequest:
    query: str
    filters: AtomicMemoryIndexFilter
    mode: AtomicMemorySearchMode = "fts"
    limit: int = 20
    query_vector: tuple[float, ...] | None = None
    embedding_profile: EmbeddingProfile | None = None
    admission: AdmissionFloor | None = None


@dataclass(frozen=True)
class AtomicMemoryRelatedRequest:
    """Complete enumeration in page-sized batches; page size never bounds the total."""

    query: str
    filters: AtomicMemoryIndexFilter
    mode: AtomicMemorySearchMode = "fts"
    query_vector: tuple[float, ...] | None = None
    embedding_profile: EmbeddingProfile | None = None
    max_distance: float | None = None
    admission: AdmissionFloor | None = None
    page_size: int = DEFAULT_ATOMIC_MEMORY_RELATED_PAGE_SIZE


class AtomicMemoryIndex(Protocol):
    """Caller-owned projection transactions, including initialization and current-row validation."""

    table: Table
    tables: tuple[Table, ...]
    capabilities: AtomicMemoryIndexCapabilities

    async def initialize(self, connection: AsyncConnection, /) -> None: ...

    async def validate_current(self, connection: AsyncConnection, /) -> None: ...

    async def replace_many(
        self, connection: AsyncConnection, scope_id: str, projections: Sequence[AtomicMemoryProjection], /
    ) -> None: ...

    async def delete(self, connection: AsyncConnection, scope_id: str, artifact_id: str, /) -> None: ...

    async def save_evidence(
        self,
        connection: AsyncConnection,
        scope_id: str,
        artifact_ref: ArtifactRef,
        sources: Sequence[SourceEvidence],
        /,
    ) -> AtomicMemoryEvidenceAnnotation: ...

    async def read_evidence(
        self, connection: AsyncConnection, scope_id: str, artifact_ref: ArtifactRef, /
    ) -> AtomicMemoryEvidenceAnnotation | None: ...

    async def project_evidence(
        self, connection: AsyncConnection, annotation: AtomicMemoryEvidenceAnnotation, /
    ) -> None: ...

    async def read_evidence_projection(
        self, connection: AsyncConnection, scope_id: str, artifact_ref: ArtifactRef, /
    ) -> AtomicMemoryEvidenceAnnotation | None: ...

    async def search(
        self, connection: AsyncConnection, scope_id: str, request: AtomicMemorySearchRequest, /
    ) -> AtomicMemorySearchChannels: ...

    async def probe_recoverable(
        self, connection: AsyncConnection, scope_id: str, request: AtomicMemorySearchRequest, floor: AdmissionFloor, /
    ) -> bool: ...

    async def related_page(
        self,
        connection: AsyncConnection,
        scope_id: str,
        request: AtomicMemoryRelatedRequest,
        cursor: AtomicMemoryRelatedCursor | None = None,
        /,
    ) -> AtomicMemoryRelatedPage | None:
        """Return one page of a complete enumeration.

        The first call ranks the complete eligible set; later calls only read the
        cursor's lightweight slice. Bodies and authorization stay per page.
        """
        ...

    async def enumerate_related_with_heads(
        self, connection: AsyncConnection, scope_id: str, request: AtomicMemoryRelatedRequest, /
    ) -> tuple[tuple[AtomicMemoryIndexHit, ...], dict[str, dict[str, object]]]: ...

    async def refresh_tags(
        self, connection: AsyncConnection, scope_id: str, artifact_id: str, tag_keys: tuple[str, ...], /
    ) -> None: ...


class AtomicMemoryProjectionPublisher:
    """Prepare vectors outside writes and publish with the authoritative transaction."""

    def __init__(
        self,
        index: AtomicMemoryIndex,
        *,
        embedding_model: EmbeddingModel | None = None,
        sources: SourceRepository | None = None,
    ) -> None:
        if not callable(getattr(index, "replace_many", None)):
            raise AtomicMemoryIndexError("publication", "Atomic Memory index must publish complete projection sets")
        self.index = index
        self._embedding_model = embedding_model
        self._sources = sources

    @property
    def profile_fingerprint(self) -> str | None:
        profile = self.index.capabilities.embedding_profile
        return None if profile is None else atomic_memory_profile_fingerprint(profile)

    def validate_prepared(self, prepared: PreparedAtomicMemoryProjection) -> None:
        """Reject a prepared vector after a deployment profile change."""

        profile = self.index.capabilities.embedding_profile
        if prepared.profile_fingerprint != self.profile_fingerprint or prepared.embedding_profile != profile:
            raise AtomicMemoryIndexError("embedding-profile", "Embedding profile changed after projection preparation")
        if profile is None:
            if prepared.embedding is not None or prepared.embedding_input_hash is not None:
                raise AtomicMemoryIndexError("embedding-profile", "No-vector deployment received a prepared vector")
        elif prepared.embedding is None or prepared.embedding_input_hash != atomic_memory_embedding_input_hash(
            prepared.kind, prepared.text
        ):
            raise AtomicMemoryIndexError("embedding-input", "Prepared vector does not match the embedding input")

    async def prepare(self, content: BaseModel) -> PreparedAtomicMemoryProjection:
        payload = content.model_dump(mode="json", by_alias=True)
        kind, body = payload.get("kind"), payload.get("text")
        if not isinstance(kind, str) or not isinstance(body, str) or not kind.strip() or not body.strip():
            raise AtomicMemoryIndexError("content", "Atomic Memory requires nonempty kind and text")
        input_text = atomic_memory_embedding_input(kind, body)
        profile = self.index.capabilities.embedding_profile
        vector = None
        if profile is not None:
            model = self._embedding_model
            if model is None or model.profile != profile:
                raise AtomicMemoryIndexError("embedding-profile", "Atomic Memory embedding model does not match index")
            result = await model.embed((input_text,))
            if len(result.vectors) != 1:
                raise AtomicMemoryIndexError("embedding-result", "Embedding model did not return one vector per input")
            vector = canonical_embedding(
                result.vectors[0], dimension=profile.dimension, normalization=profile.normalization
            )
        return PreparedAtomicMemoryProjection(
            kind=kind,
            text=body,
            description=payload.get("description"),
            searchable_text=analyze_text(input_text),
            content_hash=sha256(canonical_json(payload)).hexdigest(),
            embedding=vector,
            embedding_profile=None if profile is None else profile.model_copy(deep=True),
            profile_fingerprint=None if profile is None else atomic_memory_profile_fingerprint(profile),
            embedding_input_hash=None if vector is None else atomic_memory_embedding_input_hash(kind, body),
        )

    async def capture_evidence(self, connection: AsyncConnection, scope_id: str, record: Any) -> None:
        """Accept history only for a committed body write, never state-only republishing."""

        artifact = record.artifact
        if (
            self._sources is not None
            and await self.index.read_evidence(connection, scope_id, artifact.as_ref()) is None
        ):
            evidence = await self._sources.evidence(connection, scope_id, artifact.lineage.sources)
            annotation = await self.index.save_evidence(connection, scope_id, artifact.as_ref(), evidence)
            await self.index.project_evidence(connection, annotation)

    async def publish(
        self,
        connection: AsyncConnection,
        scope_id: str,
        record: Any,
        prepared: PreparedAtomicMemoryProjection,
    ) -> None:
        artifact = record.artifact
        if record.state.state != "active":
            await self.remove(connection, scope_id, artifact.artifact_id)
            return
        tags = await load_atomic_memory_tags(connection, scope_id, artifact.artifact_id)
        await self.index.replace_many(connection, scope_id, (self._projection(record, prepared, tags),))

    async def publish_many(
        self,
        connection: AsyncConnection,
        scope_id: str,
        records: Sequence[tuple[Any, PreparedAtomicMemoryProjection]],
    ) -> None:
        """Publish independent, newly created and untagged revisions in one transaction."""
        await self.index.replace_many(
            connection,
            scope_id,
            tuple(self._projection(record, prepared, ()) for record, prepared in records),
        )

    def _projection(
        self, record: Any, prepared: PreparedAtomicMemoryProjection, tags: tuple[str, ...]
    ) -> AtomicMemoryProjection:
        artifact = record.artifact
        if record.state.state != "active":
            raise AtomicMemoryIndexError("state", "Bulk projection requires active Atomic Memory")
        content_hash = sha256(canonical_json(artifact.content.model_dump(mode="json", by_alias=True))).hexdigest()
        if content_hash != prepared.content_hash:
            raise AtomicMemoryIndexError("prepared-content", "Prepared projection does not match the committed content")
        self.validate_prepared(prepared)
        return AtomicMemoryProjection(
            artifact_ref=artifact.as_ref(),
            state_version=record.state.state_version,
            prepared=prepared,
            tag_keys=tags,
        )

    async def remove(self, connection: AsyncConnection, scope_id: str, artifact_id: str) -> None:
        await self.index.delete(connection, scope_id, artifact_id)


async def load_atomic_memory_tags(connection: AsyncConnection, scope_id: str, artifact_id: str) -> tuple[str, ...]:
    rows = (
        await connection.execute(
            select(ARTIFACT_TAGS_TABLE.c.tag_key)
            .where(
                ARTIFACT_TAGS_TABLE.c.scope_id == scope_id,
                ARTIFACT_TAGS_TABLE.c.family == "atomic-memory",
                ARTIFACT_TAGS_TABLE.c.artifact_id == artifact_id,
                ARTIFACT_TAGS_TABLE.c.target_type == "artifact",
                ARTIFACT_TAGS_TABLE.c.target_id == artifact_id,
            )
            .order_by(ARTIFACT_TAGS_TABLE.c.tag_key)
            .with_for_update()
        )
    ).scalars()
    return tuple(str(row) for row in rows)


def atomic_memory_embedding_input(kind: str, body: str, /) -> str:
    return f"{kind}\n{body}"


def atomic_memory_embedding_input_hash(kind: str, body: str, /) -> str:
    return sha256(atomic_memory_embedding_input(kind, body).encode("utf-8")).hexdigest()


def atomic_memory_profile_fingerprint(profile: EmbeddingProfile, /) -> str:
    return sha256(canonical_json(profile.model_dump(mode="json"))).hexdigest()


def sqlite_fts_coverage_sql(terms: tuple[str, ...], /) -> tuple[str, dict[str, object]]:
    """Count whole terms without growing SQL depth or bind count with query length."""

    return (
        "(SELECT COUNT(*) FROM json_each(:fts_terms) AS query_term "
        "WHERE instr(' ' || searchable_text || ' ', query_term.value) > 0)",
        {"fts_terms": json.dumps([f" {term} " for term in terms], ensure_ascii=False)},
    )


def oceanbase_fts_coverage_sql(terms: tuple[str, ...], /) -> tuple[str, dict[str, object]]:
    """Count whole terms with logarithmic expression depth on OceanBase and seekdb."""

    parameters: dict[str, object] = {}
    coverage: list[str] = []
    for index, term in enumerate(terms):
        key = f"fts_term_{index}"
        parameters[key] = f" {term} "
        coverage.append(
            f"CASE WHEN LOCATE(BINARY :{key}, BINARY CONCAT(' ', searchable_text, ' ')) > 0 THEN 1 ELSE 0 END"
        )
    # A flat sum becomes a left-deep expression and can exceed the backend's
    # expression limit for valid long queries. Pair terms without dropping any.
    while len(coverage) > 1:
        coverage = [
            f"({coverage[index]} + {coverage[index + 1]})" if index + 1 < len(coverage) else coverage[index]
            for index in range(0, len(coverage), 2)
        ]
    return coverage[0] if coverage else "0", parameters


def _memory_words_requirement(word_count: int, floor: AdmissionFloor | None) -> int:
    floor = DEFAULT_ADMISSION_FLOOR if floor is None else floor
    return max(floor.lexical_min_matched_terms, math.ceil(word_count * floor.lexical_coverage))


def atomic_memory_related_requirement(
    term_count: int, word_count: int, /, *, floor: AdmissionFloor | None = None
) -> int:
    """Return how many distinct candidate terms a stored memory must contain to be related.

    The shared terms must meet the lexical admission threshold for the candidate's ``term_count`` distinct terms, or
    number at least the minimum match count and cover the coverage fraction of the memory's own ``word_count`` indexed
    words. The requirement never grows beyond what a short memory can supply, so a long candidate still finds a short
    memory of the same fact. Prepare-time search keeps the query-only threshold.
    """

    return min(fts_required_matches(term_count, floor=floor), _memory_words_requirement(word_count, floor))


def atomic_memory_related_requirement_sql(
    term_count: int, dialect: Literal["sqlite", "mysql"], /, *, floor: AdmissionFloor | None = None
) -> tuple[str, dict[str, object], int]:
    """Render ``atomic_memory_related_requirement`` over each row's indexed words.

    Returns the SQL expression, its parameters, and the lowest requirement any row can have. A shared-term count is an
    integer, so comparing it with ``words * coverage`` equals comparing it with that product's ceiling. Both backends
    multiply in double precision, as Python does, so SQL and Python admit the same rows.
    """

    floor = DEFAULT_ADMISSION_FLOOR if floor is None else floor
    required = fts_required_matches(term_count, floor=floor)
    parameters: dict[str, object] = {"fts_related_required": required}
    lowest = min(required, floor.lexical_min_matched_terms)
    if lowest == required:
        return ":fts_related_required", parameters, lowest
    length, least, greatest = ("length", "MIN", "MAX") if dialect == "sqlite" else ("CHAR_LENGTH", "LEAST", "GREATEST")
    # Analyzed text joins encoded words with single spaces; encoded words never contain one.
    words = (
        f"(CASE WHEN searchable_text = '' THEN 0 ELSE {length}(searchable_text) - "
        f"{length}(REPLACE(searchable_text, ' ', '')) + 1 END)"
    )
    parameters.update(
        fts_related_min_matched=floor.lexical_min_matched_terms, fts_related_coverage=float(floor.lexical_coverage)
    )
    expression = (
        f"{least}(:fts_related_required, {greatest}(:fts_related_min_matched, {words} * :fts_related_coverage))"
    )
    return expression, parameters, lowest


def atomic_memory_filter_sql(
    filters: AtomicMemoryIndexFilter, dialect: Literal["sqlite", "mysql"], /
) -> tuple[str, dict[str, object]]:
    """Render only fixed SQL structure; all identities and tags are bound parameters."""

    parameters: dict[str, object] = {}
    conditions: list[str] = []
    if filters.tag_filter is not None:
        tags: list[str] = []
        for index, tag_key in enumerate(filters.tag_filter.keys):
            key = f"tag_key_{index}"
            parameters[key] = tag_key
            tags.append(
                f"EXISTS (SELECT 1 FROM json_each(tag_keys) AS t WHERE t.value = :{key})"  # noqa: S608
                if dialect == "sqlite"
                else f"JSON_CONTAINS(tag_keys, JSON_QUOTE(:{key})) = 1"
            )
        conjunction = " AND " if filters.tag_filter.match == "all" else " OR "
        conditions.append(f"({conjunction.join(tags)})")
    if filters.kind is not None:
        conditions.append("kind = :kind_filter" if dialect == "sqlite" else "BINARY kind = BINARY :kind_filter")
        parameters["kind_filter"] = filters.kind
    return " AND ".join(conditions) or "1 = 1", parameters


ATOMIC_MEMORY_AUTHORITY_COLUMNS = (
    "scope_id",
    "family",
    "artifact_id",
    "revision",
    "lifecycle_state",
    "replacement_artifact_id",
    "merged_into_id",
    "governance_generation",
)


def atomic_memory_body_select() -> str:
    """Select projection text and authoritative bodies for one page of artifact identities."""

    authority = ", ".join(f"head.{name} AS authority_{name}" for name in ATOMIC_MEMORY_AUTHORITY_COLUMNS)
    return (
        "SELECT current.artifact_id AS artifact_id, current.text AS projected_text, "  # noqa: S608
        f"{authority}, body.content AS authority_content "
        "FROM pc_atomic_memory_current AS current "
        "LEFT JOIN pc_artifact_heads AS head ON head.scope_id = current.scope_id "
        "AND head.family = 'atomic-memory' AND head.artifact_id = current.artifact_id "
        "LEFT JOIN pc_artifacts AS body ON body.scope_id = head.scope_id "
        "AND body.family = head.family AND body.artifact_id = head.artifact_id "
        "AND body.revision = head.revision "
        "WHERE current.scope_id = :scope_id AND current.artifact_id IN :body_ids"
    )


def atomic_memory_bodies_from_rows(rows: Any, /) -> tuple[dict[str, str], dict[str, dict[str, object]]]:
    """Decode page bodies and authoritative heads, skipping rows without a joined head."""

    texts: dict[str, str] = {}
    heads: dict[str, dict[str, object]] = {}
    for row in rows:
        artifact_id = str(row["artifact_id"])
        texts[artifact_id] = str(row["projected_text"])
        if row["authority_artifact_id"] is not None:
            heads[artifact_id] = {
                name: row[f"authority_{name}"] for name in (*ATOMIC_MEMORY_AUTHORITY_COLUMNS, "content")
            }
    return texts, heads


def atomic_memory_page_slice(
    ranks: Sequence[AtomicMemoryRelatedRank], cursor: AtomicMemoryRelatedCursor | None, page_size: int, /
) -> tuple[tuple[AtomicMemoryRelatedRank, ...], AtomicMemoryRelatedCursor | None] | None:
    """Slice the stable rank snapshot and carry it forward while pages remain."""

    offset = 0 if cursor is None else cursor.offset
    page = tuple(ranks[offset : offset + page_size])
    if not page:
        return None
    following = offset + len(page)
    return page, (AtomicMemoryRelatedCursor(ranks=tuple(ranks), offset=following) if following < len(ranks) else None)


def atomic_memory_page_from_ranks(
    ranks: Sequence[AtomicMemoryRelatedRank],
    texts: dict[str, str],
    heads: dict[str, dict[str, object]],
    cursor: AtomicMemoryRelatedCursor | None,
) -> AtomicMemoryRelatedPage:
    """Attach page bodies to lightweight ranks while preserving rank order."""

    missing = next((rank for rank in ranks if rank.artifact_ref.artifact_id not in texts), None)
    if missing is not None:
        raise AtomicMemoryIndexError(
            "stale-recall", f"Related memory {missing.artifact_ref.artifact_id} left the index after ranking"
        )
    hits = tuple(
        AtomicMemoryIndexHit(
            artifact_ref=rank.artifact_ref,
            state_version=rank.state_version,
            kind=rank.kind,
            text=texts[rank.artifact_ref.artifact_id],
            score=rank.score,
            distance=rank.distance,
            channel_scores=rank.channel_scores,
        )
        for rank in ranks
    )
    identities = {rank.artifact_ref.artifact_id for rank in ranks}
    page_heads = {identity: heads[identity] for identity in identities if identity in heads}
    return AtomicMemoryRelatedPage(hits=hits, heads=page_heads, cursor=cursor)


def atomic_memory_vector_sql(
    eligibility: str, dialect: Literal["sqlite", "mysql"], /, *, bounded: bool, threshold: bool
) -> str:
    """Exact Top-K over usable rows, or complete enumeration with a readiness sentinel.

    Bounded search is not a collection audit. Complete related enumeration rejects
    incomplete eligible vectors and has no result cap. Both apply same-row filters
    before truncation and keep business-table joins out of candidate scoring.
    """

    distance = "vec_distance_l2" if dialect == "sqlite" else "l2_distance"
    invalid_length = " OR LENGTH(embedding) <> :embedding_bytes" if dialect == "sqlite" else ""
    valid_length = " AND LENGTH(embedding) = :embedding_bytes" if dialect == "sqlite" else ""
    similarity = "1.0 - distance * distance / 2.0"
    clamped_similarity = (
        f"max(-1.0, min(1.0, {similarity}))" if dialect == "sqlite" else f"greatest(-1.0, least(1.0, {similarity}))"
    )
    threshold_sql = (
        " AND distance <= :max_distance" if threshold else f" AND {clamped_similarity} >= :min_semantic_similarity"
    )
    limit_sql = " LIMIT :result_limit" if bounded else ""
    if bounded and not threshold:
        return (
            "WITH scored AS (SELECT artifact_id, revision, state_version, kind, text, "  # noqa: S608
            f"{distance}(embedding, :query_vector) AS distance FROM pc_atomic_memory_current "
            f"WHERE scope_id = :scope_id AND ({eligibility}) "
            "AND embedding IS NOT NULL AND profile_fingerprint = :profile AND embedding_input_hash IS NOT NULL "
            f"AND projection_format = :projection_format{valid_length}) "
            "SELECT artifact_id, revision, state_version, kind, text, distance, 0 AS invalid_vectors "
            f"FROM scored WHERE {clamped_similarity} >= :min_semantic_similarity "
            "ORDER BY distance, artifact_id LIMIT :result_limit"
        )
    # eligibility is built by atomic_memory_filter_sql from fixed grammar.
    return (
        "WITH eligible AS (SELECT artifact_id, revision, state_version, kind, text, embedding, "  # noqa: S608
        "profile_fingerprint, embedding_input_hash, projection_format FROM pc_atomic_memory_current "
        f"WHERE scope_id = :scope_id AND ({eligibility})), "
        "readiness AS (SELECT COUNT(*) AS invalid_vectors FROM eligible WHERE embedding IS NULL "
        "OR profile_fingerprint IS NULL OR profile_fingerprint <> :profile OR embedding_input_hash IS NULL "
        f"OR projection_format <> :projection_format{invalid_length}), "
        "scored AS (SELECT artifact_id, revision, state_version, kind, text, "
        f"{distance}(embedding, :query_vector) AS distance FROM eligible "
        "WHERE embedding IS NOT NULL AND profile_fingerprint = :profile AND embedding_input_hash IS NOT NULL "
        f"AND projection_format = :projection_format{valid_length}), "
        "matched AS (SELECT artifact_id, revision, state_version, kind, text, distance, 0 AS invalid_vectors "
        f"FROM scored WHERE (SELECT invalid_vectors FROM readiness) = 0{threshold_sql} "
        f"ORDER BY distance, artifact_id{limit_sql}) "
        "SELECT artifact_id, revision, state_version, kind, text, distance, invalid_vectors FROM matched "
        "UNION ALL SELECT NULL, NULL, NULL, NULL, NULL, NULL, invalid_vectors FROM readiness WHERE invalid_vectors > 0 "
        "ORDER BY invalid_vectors DESC, distance, artifact_id"
    )


def atomic_memory_channel_hits(rows: Any, /, *, vector: bool = False) -> tuple[AtomicMemoryIndexHit, ...]:
    rows = tuple(rows)
    if vector and any(int(row["invalid_vectors"]) for row in rows):
        raise AtomicMemoryIndexError(
            "incomplete-vector", "Eligible Atomic Memory vectors are incomplete or use another profile"
        )
    hits = []
    for row in rows:
        distance = float(row["distance"]) if vector else None
        channel_scores = None
        if distance is not None:
            if not math.isfinite(distance) or distance < 0:
                raise InvalidSearchScore("Atomic vector distance must be finite and nonnegative")  # noqa: TRY003
            channel_scores = {"vector": ChannelScore(distance, "l2_distance", False)}
        elif "raw_score" in row:
            _, observation = lexical_search_score(row["raw_score"], row.get("score_metric"))
            channel_scores = {"text": observation}
        hits.append(
            AtomicMemoryIndexHit(
                artifact_ref=ArtifactRef(
                    family="atomic-memory", artifact_id=str(row["artifact_id"]), revision=int(row["revision"])
                ),
                state_version=int(row["state_version"]),
                kind=str(row["kind"]),
                text=str(row["text"]),
                score=-distance if distance is not None else float(row["score"]),
                distance=distance,
                channel_scores=channel_scores,
            )
        )
    return tuple(hits)


def combine_atomic_memory_channels(  # noqa: C901
    channels: AtomicMemorySearchChannels,
    /,
    *,
    fusion: RrfParameters | None = None,
    mode: str = "hybrid",
    channel_weights: RecallChannelWeights | None = None,
) -> tuple[AtomicMemoryIndexHit, ...]:
    """Return exact-ref union with the RRF score used for its stable ordering.

    Vector distance remains independent of the fused ranking score. Revision or
    state changes across channels require a new recall rather than mixed data.
    """

    versions: dict[str, tuple[int, int]] = {}
    hits: dict[str, AtomicMemoryIndexHit] = {}
    ranks: dict[str, float] = {}
    # Validate all retrieved identities, including evidence from a zero-weight channel.
    for channel in (channels.fts, channels.vector):
        for hit in channel:
            artifact_id = hit.artifact_ref.artifact_id
            version = (hit.artifact_ref.revision, hit.state_version)
            if artifact_id in versions and versions[artifact_id] != version:
                raise AtomicMemoryIndexError("stale-recall", "Atomic Memory changed between retrieval channels")
            versions[artifact_id] = version
    weights = (1.0, 1.0) if channel_weights is None else (channel_weights.fts, channel_weights.vector)
    for name, channel, weight in zip(("text", "vector"), (channels.fts, channels.vector), weights, strict=True):
        if fusion is None and weight == 0.0:
            continue
        for rank, hit in enumerate(channel, start=1):
            artifact_id = hit.artifact_ref.artifact_id
            previous = hits.setdefault(artifact_id, hit)
            if fusion is not None and (hit.channel_scores is None or name not in hit.channel_scores):
                raise InvalidSearchScore("Atomic search channel did not return its raw score")  # noqa: TRY003
            observations = dict(previous.channel_scores or {})
            observations.update(hit.channel_scores or {})
            if observations:
                hits[artifact_id] = replace(previous, channel_scores=observations)
                previous = hits[artifact_id]
            if previous.distance is None and hit.distance is not None:
                hits[artifact_id] = replace(previous, distance=hit.distance)
            ranks[artifact_id] = ranks.get(artifact_id, 0.0) + weight / (ATOMIC_MEMORY_RRF_CONSTANT + rank)
    if fusion is not None:
        enabled = ("text",) if mode == "text" else ("vector",) if mode == "vector" else ("text", "vector")
        fused = fuse_rrf(
            (
                FusionChannel(
                    name,
                    fusion.weights.get(name, 1.0),
                    tuple(
                        FusionCandidate(hit.artifact_ref.artifact_id, rank)
                        for rank, hit in enumerate(channels.fts if name == "text" else channels.vector, 1)
                    ),
                )
                for name in enabled
            ),
            fusion,
            tie_break=lambda identity: identity,
        )
        return tuple(replace(hits[item.key], score=float(item.raw_score), retrieval_score=item.score) for item in fused)
    return tuple(
        replace(hits[identity], score=ranks[identity])
        for identity in sorted(hits, key=lambda identity: (-ranks[identity], identity))
    )


def atomic_memory_channel_ranks(rows: Any, /, *, vector: bool = False) -> tuple[AtomicMemoryRelatedRank, ...]:
    """Decode lightweight channel ranks without reading projection or authority bodies."""

    ranks = []
    for row in rows:
        distance = float(row["distance"]) if vector else None
        channel_scores = None
        if distance is not None:
            if not math.isfinite(distance) or distance < 0:
                raise InvalidSearchScore("Atomic vector distance must be finite and nonnegative")  # noqa: TRY003
            channel_scores = {"vector": ChannelScore(distance, "l2_distance", False)}
            score = -distance
        else:
            _, observation = lexical_search_score(row["raw_score"], row.get("score_metric"))
            channel_scores = {"text": observation}
            score = float(row["score"])
        ranks.append(
            AtomicMemoryRelatedRank(
                artifact_ref=ArtifactRef(
                    family="atomic-memory", artifact_id=str(row["artifact_id"]), revision=int(row["revision"])
                ),
                state_version=int(row["state_version"]),
                kind=str(row["kind"]),
                score=score,
                distance=distance,
                channel_scores=channel_scores,
            )
        )
    return tuple(ranks)


def combine_atomic_memory_related_ranks(
    fts: tuple[AtomicMemoryRelatedRank, ...],
    vector: tuple[AtomicMemoryRelatedRank, ...],
) -> tuple[AtomicMemoryRelatedRank, ...]:
    """Fuse complete lightweight channel ranks with the RRF ordering used by related recall."""

    versions: dict[str, tuple[int, int]] = {}
    merged: dict[str, AtomicMemoryRelatedRank] = {}
    scores: dict[str, float] = {}
    for channel in (fts, vector):
        for rank in channel:
            artifact_id = rank.artifact_ref.artifact_id
            version = (rank.artifact_ref.revision, rank.state_version)
            if artifact_id in versions and versions[artifact_id] != version:
                raise AtomicMemoryIndexError("stale-recall", "Atomic Memory changed between retrieval channels")
            versions[artifact_id] = version
    for channel in (fts, vector):
        for position, rank in enumerate(channel, start=1):
            artifact_id = rank.artifact_ref.artifact_id
            previous = merged.setdefault(artifact_id, rank)
            observations = dict(previous.channel_scores or {})
            observations.update(rank.channel_scores or {})
            if observations:
                merged[artifact_id] = replace(previous, channel_scores=observations)
                previous = merged[artifact_id]
            if previous.distance is None and rank.distance is not None:
                merged[artifact_id] = replace(previous, distance=rank.distance)
            scores[artifact_id] = scores.get(artifact_id, 0.0) + 1.0 / (ATOMIC_MEMORY_RRF_CONSTANT + position)
    return tuple(
        replace(merged[artifact_id], score=scores[artifact_id])
        for artifact_id in sorted(merged, key=lambda identity: (-scores[identity], identity))
    )


class RelationalAtomicMemoryIndex:
    """Shared same-row publication and eligibility completeness checks."""

    def __init__(self, table: Table, profile: EmbeddingProfile | None) -> None:
        if profile is not None and (profile.dimension < 1 or profile.distance != "l2"):
            raise AtomicMemoryIndexError("embedding-profile", "Atomic Memory requires a positive L2 embedding profile")
        self.table = table
        self.tables: tuple[Table, ...] = (
            table,
            ATOMIC_MEMORY_EVIDENCE_PROJECTION_TABLE,
            *ATOMIC_MEMORY_EVIDENCE_TABLES,
        )
        self._evidence = AtomicMemoryEvidenceRepository()
        self.profile = profile
        self.capabilities = AtomicMemoryIndexCapabilities(
            vector=profile is not None, hybrid=profile is not None, embedding_profile=profile
        )

    async def save_evidence(
        self,
        connection: AsyncConnection,
        scope_id: str,
        artifact_ref: ArtifactRef,
        sources: Sequence[SourceEvidence],
        /,
    ) -> AtomicMemoryEvidenceAnnotation:
        return await self._evidence.save(connection, scope_id, artifact_ref, sources)

    async def read_evidence(
        self, connection: AsyncConnection, scope_id: str, artifact_ref: ArtifactRef, /
    ) -> AtomicMemoryEvidenceAnnotation | None:
        return await self._evidence.read(connection, scope_id, artifact_ref)

    async def project_evidence(
        self, connection: AsyncConnection, annotation: AtomicMemoryEvidenceAnnotation, /
    ) -> None:
        await self._evidence.replace_projection(connection, annotation)

    async def read_evidence_projection(
        self, connection: AsyncConnection, scope_id: str, artifact_ref: ArtifactRef, /
    ) -> AtomicMemoryEvidenceAnnotation | None:
        return await self._evidence.read_projection(connection, scope_id, artifact_ref)

    async def validate_current(self, connection: AsyncConnection, /) -> None:
        """Audit vector deployment readiness at startup, outside ordinary bounded search."""
        profile = self.capabilities.embedding_profile
        if profile is None:
            return
        table = self.table
        invalid = [
            table.c.embedding.is_(None),
            table.c.embedding_input_hash.is_(None),
            table.c.profile_fingerprint.is_(None),
            table.c.profile_fingerprint != atomic_memory_profile_fingerprint(profile),
            table.c.projection_format != ATOMIC_MEMORY_PROJECTION_FORMAT,
        ]
        if connection.dialect.name == "sqlite":
            invalid.append(func.length(table.c.embedding) != profile.dimension * 4)
        if await connection.scalar(select(table.c.artifact_id).where(or_(*invalid)).limit(1)) is not None:
            raise AtomicMemoryIndexError(
                "incomplete-vector",
                "Current Atomic Memory vectors are incomplete or use another profile. Stop writers and run "
                "powercontext server atomic-memory-rebuild-projection --maintenance-confirmed.",
            )

    def _encode_embedding(self, vector: tuple[float, ...]) -> object:
        return vector

    async def require_current_schema(self, connection: AsyncConnection) -> None:
        # Add only the new nullable projection metadata. Never read bodies or call inference at startup.
        columns = await _projection_columns(connection, self.table)
        if columns and "description" not in columns:
            await connection.exec_driver_sql(
                "ALTER TABLE pc_atomic_memory_current ADD COLUMN description VARCHAR(200) NULL"
            )
        if await _projection_columns(connection, self.table) & _OBSOLETE_PROJECTION_COLUMNS:
            raise AtomicMemoryIndexError(
                "current-schema",
                "Atomic Memory uses an obsolete development projection schema. Stop writers and run "
                "powercontext server atomic-memory-rebuild-projection --maintenance-confirmed.",
            )

    async def replace_many(
        self, connection: AsyncConnection, scope_id: str, projections: Sequence[AtomicMemoryProjection], /
    ) -> None:
        if not projections:
            return
        values = [self._projection_values(scope_id, projection) for projection in projections]
        if connection.dialect.name == "sqlite":
            statement = sqlite_insert(self.table)
            statement = statement.on_conflict_do_update(
                index_elements=("scope_id", "artifact_id"),
                set_={
                    name: getattr(statement.excluded, name)
                    for name in values[0]
                    if name not in {"scope_id", "artifact_id"}
                },
            )
        elif connection.dialect.name == "mysql":
            statement = mysql_insert(self.table)
            statement = statement.on_duplicate_key_update(**{
                name: getattr(statement.inserted, name) for name in values[0] if name not in {"scope_id", "artifact_id"}
            })
        else:
            raise AtomicMemoryIndexError("dialect", "Atomic Memory projection needs SQLite or MySQL")
        await connection.execute(statement, values)

    def _projection_values(self, scope_id: str, projection: AtomicMemoryProjection) -> dict[str, object]:
        if projection.artifact_ref.family != "atomic-memory":
            raise AtomicMemoryIndexError("family", "Atomic Memory index only accepts atomic-memory artifacts")
        prepared = projection.prepared
        embedding = None
        fingerprint = None
        input_hash = None
        if self.profile is not None:
            if (
                prepared.embedding_profile != self.profile
                or prepared.profile_fingerprint != atomic_memory_profile_fingerprint(self.profile)
                or prepared.embedding is None
            ):
                raise AtomicMemoryIndexError(
                    "embedding-profile", "Prepared projection does not cover the active profile"
                )
            input_hash = atomic_memory_embedding_input_hash(prepared.kind, prepared.text)
            if prepared.embedding_input_hash != input_hash:
                raise AtomicMemoryIndexError("embedding-input", "Prepared vector does not match the embedding input")
            embedding = self._encode_embedding(
                canonical_embedding(
                    prepared.embedding, dimension=self.profile.dimension, normalization=self.profile.normalization
                )
            )
            fingerprint = atomic_memory_profile_fingerprint(self.profile)
        return {
            "scope_id": scope_id,
            "artifact_id": projection.artifact_ref.artifact_id,
            "revision": projection.artifact_ref.revision,
            "state_version": projection.state_version,
            "content_hash": prepared.content_hash,
            "projection_format": ATOMIC_MEMORY_PROJECTION_FORMAT,
            "kind": prepared.kind,
            "text": prepared.text,
            "description": prepared.description,
            "searchable_text": prepared.searchable_text,
            "tag_keys": json.dumps(sorted(set(projection.tag_keys)), ensure_ascii=False),
            "embedding": embedding,
            "profile_fingerprint": fingerprint,
            "embedding_input_hash": input_hash,
        }

    async def delete(self, connection: AsyncConnection, scope_id: str, artifact_id: str, /) -> None:
        await connection.execute(
            delete(self.table).where(self.table.c.scope_id == scope_id, self.table.c.artifact_id == artifact_id)
        )

    async def refresh_tags(
        self, connection: AsyncConnection, scope_id: str, artifact_id: str, tag_keys: tuple[str, ...], /
    ) -> None:
        await connection.execute(
            update(self.table)
            .where(self.table.c.scope_id == scope_id, self.table.c.artifact_id == artifact_id)
            .values(tag_keys=json.dumps(sorted(set(tag_keys)), ensure_ascii=False))
        )

    async def probe_recoverable(
        self,
        connection: AsyncConnection,
        scope_id: str,
        request: AtomicMemorySearchRequest,
        floor: AdmissionFloor,
        /,
    ) -> bool:
        """Probe at most one eligible row gaining a channel under the lower floor.

        Qualification precedes LIMIT. This is an existence signal, not an invented
        pre-admission collection count. Gaining a second channel can change fusion
        order and surface a row outside the delivered pool's cap.
        The same current row carries its body, vectors and content filters.
        """

        dialect = "sqlite" if connection.dialect.name == "sqlite" else "mysql"
        eligibility, parameters = atomic_memory_filter_sql(request.filters, dialect)
        parameters["scope_id"] = scope_id
        current: list[str] = []
        recoverable: list[str] = []
        if request.mode in {"fts", "hybrid"}:
            terms, required = fts_query_requirements(request.query, floor=request.admission)
            _, lower_required = fts_query_requirements(request.query, floor=floor)
            if terms:
                if dialect == "sqlite":
                    lexical, coverage_parameters = sqlite_fts_coverage_sql(terms)
                else:
                    lexical, coverage_parameters = oceanbase_fts_coverage_sql(terms)
                parameters.update(coverage_parameters)
                parameters.update(probe_required=required, probe_lower_required=lower_required)
                current.append(f"(({lexical}) >= :probe_required)")
                recoverable.append(f"(({lexical}) >= :probe_lower_required)")
        if request.mode in {"vector", "hybrid"}:
            vector = self._require_vectors(request)
            profile = self.profile
            if profile is None:
                raise AtomicMemoryIndexError("embedding-profile", "Vector profile is unavailable")
            parameters.update(
                probe_vector=self._encode_embedding(vector),
                probe_similarity=(
                    DEFAULT_ADMISSION_FLOOR if request.admission is None else request.admission
                ).min_semantic_similarity,
                probe_lower_similarity=floor.min_semantic_similarity,
            )
            distance = "vec_distance_l2" if dialect == "sqlite" else "l2_distance"
            distance_sql = f"{distance}(embedding, :probe_vector)"
            squared = f"({distance_sql} * {distance_sql})" if dialect == "sqlite" else f"POWER({distance_sql}, 2)"
            similarity = f"(1.0 - {squared} / 2.0)"
            current.append(f"({similarity} >= :probe_similarity)")
            recoverable.append(f"({similarity} >= :probe_lower_similarity)")
        if not recoverable:
            return False
        new_channels = [f"({lower} AND NOT {admitted})" for admitted, lower in zip(current, recoverable, strict=True)]
        probe = (
            "SELECT 1 FROM pc_atomic_memory_current WHERE scope_id = :scope_id "  # noqa: S608
            f"AND ({eligibility}) AND ({' OR '.join(new_channels)}) LIMIT 1"
        )
        invalid = "0 = 1"
        profile = self.profile
        if request.mode in {"vector", "hybrid"} and profile is not None:
            parameters.update(
                profile=atomic_memory_profile_fingerprint(profile),
                projection_format=ATOMIC_MEMORY_PROJECTION_FORMAT,
                embedding_bytes=profile.dimension * 4,
            )
            length = " OR LENGTH(embedding) <> :embedding_bytes" if dialect == "sqlite" else ""
            invalid = (
                "EXISTS (SELECT 1 FROM pc_atomic_memory_current WHERE scope_id = :scope_id "  # noqa: S608
                f"AND ({eligibility}) AND (embedding IS NULL OR embedding_input_hash IS NULL "
                "OR profile_fingerprint IS NULL OR profile_fingerprint <> :profile "
                f"OR projection_format <> :projection_format{length}) LIMIT 1)"
            )
        statement = text(f"SELECT CASE WHEN {invalid} THEN -1 ELSE EXISTS ({probe}) END")
        if request.mode in {"vector", "hybrid"} and dialect == "mysql":
            statement = statement.bindparams(bindparam("probe_vector", type_=self.table.c.embedding.type))
        result = await connection.scalar(statement, parameters)
        if result == -1:
            raise AtomicMemoryIndexError(
                "incomplete-vector", "Eligible Atomic Memory vectors are incomplete or use another profile"
            )
        return bool(result)

    def _require_vectors(
        self,
        request: AtomicMemorySearchRequest | AtomicMemoryRelatedRequest,
    ) -> tuple[float, ...]:
        profile = self.profile
        if profile is None or request.embedding_profile != profile or request.query_vector is None:
            raise AtomicMemoryIndexError("embedding-profile", "Vector query requires the configured complete profile")
        if isinstance(request, AtomicMemorySearchRequest):
            if profile.normalization != "unit":
                raise AtomicMemoryIndexError(
                    "embedding-profile", "Cosine admission requires a unit-normalized L2 embedding profile"
                )
            floor = DEFAULT_ADMISSION_FLOOR if request.admission is None else request.admission
            if not math.isfinite(floor.min_semantic_similarity):
                raise AtomicMemoryIndexError("admission", "Semantic similarity admission must be finite")
        return canonical_embedding(
            request.query_vector, dimension=profile.dimension, normalization=profile.normalization
        )

    @staticmethod
    def validate_request(request: AtomicMemorySearchRequest | AtomicMemoryRelatedRequest) -> None:
        normalize_query(request.query)
        if request.mode not in {"fts", "vector", "hybrid"}:
            raise AtomicMemoryIndexError("mode", "Atomic Memory search mode must be fts, vector or hybrid")
        if isinstance(request, AtomicMemorySearchRequest):
            if isinstance(request.limit, bool) or request.limit < 1:
                raise AtomicMemoryIndexError("limit", "Search limit must be positive")
        elif request.mode in {"vector", "hybrid"} and (
            request.max_distance is None or not math.isfinite(request.max_distance) or request.max_distance < 0
        ):
            raise AtomicMemoryIndexError(
                "threshold", "Complete vector enumeration requires a finite nonnegative L2 threshold"
            )
        if isinstance(request, AtomicMemoryRelatedRequest):
            page_size = request.page_size
            if isinstance(page_size, bool) or not isinstance(page_size, int) or not 1 <= page_size <= 1000:
                raise AtomicMemoryIndexError("limit", "Related page size must be a positive integer up to 1000")


__all__ = [
    "ATOMIC_MEMORY_AUTHORITY_COLUMNS",
    "ATOMIC_MEMORY_RRF_CONSTANT",
    "DEFAULT_ATOMIC_MEMORY_RELATED_PAGE_SIZE",
    "AtomicMemoryIndex",
    "AtomicMemoryIndexCapabilities",
    "AtomicMemoryIndexError",
    "AtomicMemoryIndexFilter",
    "AtomicMemoryIndexHit",
    "AtomicMemoryProjection",
    "AtomicMemoryProjectionPublisher",
    "AtomicMemoryRelatedCursor",
    "AtomicMemoryRelatedPage",
    "AtomicMemoryRelatedRank",
    "AtomicMemoryRelatedRequest",
    "AtomicMemorySearchChannels",
    "AtomicMemorySearchRequest",
    "PreparedAtomicMemoryProjection",
    "RelationalAtomicMemoryIndex",
    "atomic_memory_bodies_from_rows",
    "atomic_memory_body_select",
    "atomic_memory_channel_hits",
    "atomic_memory_channel_ranks",
    "atomic_memory_embedding_input",
    "atomic_memory_embedding_input_hash",
    "atomic_memory_filter_sql",
    "atomic_memory_page_from_ranks",
    "atomic_memory_page_slice",
    "atomic_memory_profile_fingerprint",
    "atomic_memory_related_requirement",
    "atomic_memory_related_requirement_sql",
    "combine_atomic_memory_channels",
    "combine_atomic_memory_related_ranks",
    "load_atomic_memory_tags",
    "oceanbase_fts_coverage_sql",
    "sqlite_fts_coverage_sql",
]
